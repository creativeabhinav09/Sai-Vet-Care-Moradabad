import {
  SevaCard,
  PriorityCareItem,
  MedicalSurgicalDiscipline,
  MedicineItem,
  NetworkLocation,
  GaushalaPartnership,
  TeamMember,
  GalleryItem,
  StoryUpdate,
  TimelineMilestone,
} from '../types';

export const SATPATHY_JI_TIMELINE: TimelineMilestone[] = [
  {
    year: '2009',
    title: 'Establishment & Humble Genesis',
    description:
      'Established under the inspiration and initiative of Dr. Chandra Bhanu Satpathy Ji, whose deep love, compassion, and concern for animals led to the creation of a dedicated veterinary care facility operating from rented premises in Moradabad.',
    achievement: 'Initial emergency response and charitable treatment launched for distressed animals.',
  },
  {
    year: '2015',
    title: 'Dedicated Temple Premises Facility',
    description:
      'With the rising demand for animal healthcare, dedicated clinical facilities — including an OPD, examination room, and sterile operation theatre (OT) — were established within temple premises, enabling structured and reliable veterinary services.',
    achievement: 'Full-fledged surgical theatre and diagnostic examination room operationalized.',
  },
  {
    year: '2020',
    title: 'Expansion under Shri Sai Karuna Sansthan',
    description:
      'Operating under the aegis of Shri Shirdi Sai Global Foundation through Shri Sai Karuna Sansthan, expanding veterinary reach across rural hamlets, agrarian villages, and cattle sanctuaries.',
    achievement: 'Long-term healthcare partnerships established with major regional gaushalas.',
  },
  {
    year: 'Today',
    title: 'Recognized Moradabad Regional Institution',
    description:
      'Operating 5 active service centres in Moradabad, Bilari, and Ramganga Paar, while providing regular monthly health camps and follow-up care to over 2,000 animals across 7 partner gaushalas.',
    achievement: '1,670+ gaushala cattle under active care and 100% free treatment for needy animals.',
  },
];

export const VETERINARY_SEVA_CARDS: SevaCard[] = [
  {
    id: 'accident-injury',
    title: 'Treatment of Accident & Injury Cases',
    category: 'clinical',
    description:
      'Immediate emergency triage, wound debridement, fracture stabilization, and intensive trauma care for animals injured in vehicular or roadside accidents.',
    iconName: 'Ambulance',
    highlights: ['Immediate Triage', 'Emergency Fracture Care', 'Sterile Wound Debridement'],
  },
  {
    id: 'critically-ill',
    title: 'Treatment of Critically & Seriously Ill Animals',
    category: 'clinical',
    description:
      'Intensive inpatient and outpatient management for high-dependency cases, systemic infections, acute toxemia, and severe dehydration.',
    iconName: 'HeartPulse',
    highlights: ['Intensive Medical Care', 'Fluid Resuscitation', 'Continuous Vital Monitoring'],
  },
  {
    id: 'regular-examinations',
    title: 'Regular Veterinary Examinations & Check-ups',
    category: 'clinical',
    description:
      'Routine clinical health audits, diagnostic palpation, dermatological screening, and vital organ assessment to detect and treat disorders early.',
    iconName: 'Stethoscope',
    highlights: ['Comprehensive Physical Exams', 'Ear & Eye Check-ups', 'Diagnostic Assessment'],
  },
  {
    id: 'followup-postop',
    title: 'Follow-up Treatment & Post-Operative Care',
    category: 'clinical',
    description:
      'Continuous dressing renewals, suture removal, surgical wound healing oversight, and coordinated physiotherapy until full recovery is achieved.',
    iconName: 'ClipboardCheck',
    highlights: ['Scheduled Dressing Care', 'Post-Op Monitoring', 'Recovery Tracking'],
  },
  {
    id: 'free-treatment-needy',
    title: 'Free Treatment for Needy Animals',
    category: 'aid',
    description:
      'Complete medical and surgical interventions provided 100% free of cost to stray, abandoned, and economically disadvantaged animals.',
    iconName: 'ShieldCheck',
    highlights: ['Zero Financial Barrier', 'Unconditional Seva Ethos', 'Equal Dignity of Care'],
  },
  {
    id: 'free-medicines',
    title: 'Free Medicines Where Required',
    category: 'aid',
    description:
      'Direct dispensing of antibiotics, anti-inflammatory boluses, supplements, topical wound sprays, and tick treatments without charge.',
    iconName: 'Pill',
    highlights: ['Complete Drug Formulary', 'Free Bolus & Powders', 'Essential Injectables'],
  },
  {
    id: 'gaushala-camps',
    title: 'Regular Visits & Health Camps at Gaushalas',
    category: 'community',
    description:
      'Scheduled monthly clinical visits and health camps to 7 partner gaushalas and cow conservation centres housing over 2,000 bovine lives.',
    iconName: 'Warehouse',
    highlights: ['Monthly Health Camps', 'Herd De-worming Drives', 'Senior Bovine Hospice'],
  },
  {
    id: 'cattle-owner-support',
    title: 'Support & Advisory Services to Cattle Owners',
    category: 'community',
    description:
      'Dedicated counseling for rural dairy farmers and cattle keepers regarding scientific nutrition, milk yield enhancement, and disease prevention.',
    iconName: 'Users',
    highlights: ['Farmer Advisory Desk', 'Milk Enhancing Guidance', 'Husbandry Counseling'],
  },
  {
    id: 'preventive-care',
    title: 'Preventive & Supportive Veterinary Care',
    category: 'community',
    description:
      'Proactive ectoparasite eradication, mass vaccination, mineral supplementation, and digestive enzymes to maintain lasting herd vitality.',
    iconName: 'Syringe',
    highlights: ['Anti-Tick Treatments', 'Mineral Powder Support', 'Digestive Health Care'],
  },
];

export const PRIORITY_CARE_ITEMS: PriorityCareItem[] = [
  {
    id: 'priority-accidents',
    title: 'Accident & Critical Trauma',
    subtitle: 'Immediate Priority Triage',
    description:
      'Accidentally injured, road-hit, and very seriously ill animals receive instantaneous priority treatment upon arrival, followed by regular scheduled follow-up care.',
    responseProtocol: 'Zero waiting time. Emergency wound debridement, fracture stabilization, and shock therapy deployed immediately.',
    iconName: 'AlertCircle',
    urgency: 'critical',
  },
  {
    id: 'priority-gaushala',
    title: 'Gaushala & Rural Centre Care',
    subtitle: 'Monthly Dedicated Visits',
    description:
      'Priority is extended to animals housed in gaushalas and rural service centres, with dedicated follow-up visits conducted on a monthly basis to monitor health and administer treatments.',
    responseProtocol: 'Scheduled monthly health camps, herd diagnostics, anti-tick injections, and mass mineral supplementation.',
    iconName: 'Activity',
    urgency: 'high',
  },
  {
    id: 'priority-followup',
    title: 'Ongoing Follow-Up & Examinations',
    subtitle: 'Structured Post-Treatment Oversight',
    description:
      'Ensuring that critical cases receive prompt attention while ongoing care is diligently maintained across different service locations through scheduled visits.',
    responseProtocol: 'Periodic wound dressing, post-surgical evaluation, antibiotic course completion, and supportive nutrition.',
    iconName: 'Clock',
    urgency: 'scheduled',
  },
];

export const MEDICAL_SURGICAL_DATA: MedicalSurgicalDiscipline[] = [
  {
    id: 'medical-care',
    type: 'medical',
    title: 'OPD & Clinical Medical Care',
    eyebrow: 'Moradabad Central Facility — Comprehensive OPD',
    description:
      'Structured outpatient department and dedicated examination room within the temple premises, delivering reliable diagnosis and targeted therapeutics to distressed animals.',
    procedures: [
      'Clinical Health Audits & Vital Signs Examination',
      'Diagnostic Palpation & Parasite Screening',
      'Intravenous Fluid & Electrolyte Resuscitation',
      'Anti-Tick Injections & Ectoparasite Eradication',
      'Digestive Disorders & Rumen Function Restoration',
    ],
    equipment: [
      'Dedicated OPD Examination Room',
      'Large Animal Treatment Stanchion',
      'Digital Vitals & Temperature Diagnostics',
      'Cold-Chain Biological Storage',
    ],
  },
  {
    id: 'surgical-care',
    type: 'surgical',
    title: 'Operation Theatre & Surgical Care',
    eyebrow: 'Specialized Operative Suite',
    description:
      'A dedicated operation theatre led by a senior veterinarian skilled in surgical procedures, enabling Sai Vet Care to handle complex surgical and wound reconstruction cases.',
    procedures: [
      'Accident Trauma & Extensive Laceration Suturing',
      'Bone Fracture Immobilization & Splinting',
      'Surgical Abscess & Deep Maggot Wound Debridement',
      'Soft-Tissue Interventions & Hernia Repairs',
      'Post-Operative Recovery Oversight & Suture Care',
    ],
    equipment: [
      'Sterile Operating Suite & Surgical Table',
      'Autoclave Instrument Sterilization Unit',
      'Surgical Cautery & Soft-Tissue Repair Sets',
      'Post-Surgical Supervised Recovery Bays',
    ],
  },
];

export const MEDICINES_LIST: MedicineItem[] = [
  {
    id: 'med-antibiotic-bolus',
    name: 'Antibiotic Bolus',
    type: 'Broad-Spectrum Veterinary Antibacterial Formulation',
    usage: 'Treatment of systemic bacterial infections, pneumonia, wound sepsis, and post-surgical protection in livestock.',
    availability: '100% Free Dispensary',
  },
  {
    id: 'med-anti-inflammatory-bolus',
    name: 'Anti-inflammatory Bolus',
    type: 'Veterinary Analgesic & Antipyretic Agent',
    usage: 'Rapid relief from acute muscular pain, traumatic injuries, high fever, joint swelling, and arthritis.',
    availability: '100% Free Dispensary',
  },
  {
    id: 'med-rumifit-bolus',
    name: 'Rumifit Bolus',
    type: 'Rumen Ecbolic, Probiotic & Digestive Stimulant',
    usage: 'Restores healthy rumen motility, treats acute indigestion, loss of appetite, anorexia, and bloat in ruminants.',
    availability: '100% Free Dispensary',
  },
  {
    id: 'med-mineral-powder',
    name: 'Mineral Powder',
    type: 'Essential Macro & Chelated Trace Minerals',
    usage: 'Rectifies nutritional deficiencies, builds skeletal strength, enhances immune defense, and promotes general vigor.',
    availability: '100% Free Dispensary',
  },
  {
    id: 'med-dust-lite-powder',
    name: 'Dust Lite Powder',
    type: 'Antiseptic & Absorbent Topical Powder',
    usage: 'Drying and antiseptic dressing for open lacerations, foot sores, and moist dermatitis across companion and farm animals.',
    availability: '100% Free Dispensary',
  },
  {
    id: 'med-liquid-calcium',
    name: 'Liquid Calcium',
    type: 'High-Bioavailability Oral Calcium with Vitamin D3',
    usage: 'Prevents and treats postpartum hypocalcemia (milk fever), strengthens bones, and supports lactation demands.',
    availability: '100% Free Dispensary',
  },
  {
    id: 'med-topi-heal-spray',
    name: 'Topi Heal Spray',
    type: 'Topical Wound Care & Maggoticidal Aerosol',
    usage: 'Direct application for rapid wound healing, fly repellent, maggot eradication, and surgical site protection.',
    availability: '100% Free Dispensary',
  },
  {
    id: 'med-ivermectin-injection',
    name: 'Ivermectin Anti-Tick Injection',
    type: 'Potent Endectocide Injectable Formulation',
    usage: 'Eradicates stubborn ectoparasites (ticks, mites, lice) and internal gastrointestinal nematode infestations.',
    availability: '100% Free Dispensary',
  },
  {
    id: 'med-anti-tick-tablets',
    name: 'Anti-Tick Tablets',
    type: 'Oral Ectoparasite Control Tablets',
    usage: 'Systemic tick and flea elimination for canines, community strays, and recovering shelter animals.',
    availability: '100% Free Dispensary',
  },
  {
    id: 'med-antiseptic-medicines',
    name: 'Antiseptic Medicines',
    type: 'Hospital-Grade Wound Cleansers & Antiseptic Lotions',
    usage: 'Disinfection of contaminated wounds, surgical site prep, burn management, and sterile dressing care.',
    availability: '100% Free Dispensary',
  },
  {
    id: 'med-multivitamin-bolus',
    name: 'Multivitamin Bolus',
    type: 'Therapeutic Vitamins A, D3, E & B-Complex',
    usage: 'Restores vitality in convalescent, debilitated, malnourished, or recovering animals.',
    availability: '100% Free Dispensary',
  },
  {
    id: 'med-calcium-supplements',
    name: 'Calcium Supplements',
    type: 'Concentrated Fortified Bovine Calcium Bolus & Gel',
    usage: 'Ensures optimal maternal calcium balance and prevents muscular weakness in pregnant and lactating cows.',
    availability: '100% Free Dispensary',
  },
  {
    id: 'med-enzymes',
    name: 'Enzymes (Digestive & Metabolic)',
    type: 'Synergistic Multi-Enzyme Formulations',
    usage: 'Improves nutrient absorption, aids ruminal breakdown of coarse fodder, and prevents chronic wasting.',
    availability: '100% Free Dispensary',
  },
  {
    id: 'med-milk-enhancing-powder',
    name: 'Mineral & Milk Enhancing Powders',
    type: 'Galactagogue & Mineral Blend for Rural Dairy Cattle',
    usage: 'Supports impoverished rural cattle owners by safely boosting healthy milk production and udder wellness.',
    availability: '100% Free Dispensary',
  },
];

export const NETWORK_LOCATIONS: NetworkLocation[] = [
  {
    id: 'loc-mahal-kapoor',
    name: 'Sai Vet Care (Main Headquarters)',
    role: 'Central Clinic, OPD, Examination Room & Operation Theatre',
    address: 'Mahal Kapoor Gram, Moradabad, Uttar Pradesh',
    timing: 'Daily OPD & 24/7 Emergency Triage',
    contact: '8191921647',
    coordinates: { x: 42, y: 46 },
    facilities: ['Dedicated OPD', 'Examination Room', 'Operation Theatre', 'Free Dispensary'],
  },
  {
    id: 'loc-kafiyabad',
    name: 'Sai Vet Care — Kafiyabad Centre',
    role: 'Ramganga Paar Outreach Centre',
    address: 'Kafiyabad, Ramganga Paar, Moradabad, Uttar Pradesh',
    timing: 'Regular Examination & Health Support',
    contact: '9627169456',
    coordinates: { x: 55, y: 35 },
    facilities: ['Rural Clinical Outpost', 'Wound Dressing Bay', 'Free Medicines Distribution'],
  },
  {
    id: 'loc-darni-bilari',
    name: 'Sai Vet Care — Village Darni Centre',
    role: 'Bilari Tehsil Rural Service Centre',
    address: 'Village Darni, Bilari Tehsil, Moradabad District, Uttar Pradesh',
    timing: 'Rural Outreach & Gaushala Liaison',
    contact: '9675555247',
    coordinates: { x: 30, y: 68 },
    facilities: ['Livestock Health Hub', 'Cattle Examination Stanchion', 'Deworming Desk'],
  },
  {
    id: 'loc-naya-gaon',
    name: 'Sai Vet Care — Naya Gaon Centre',
    role: 'Harthala Industrial Area & Kanth Road Clinic',
    address: 'Naya Gaon, Harthala Industrial Area, Kanth Road, Moradabad, Uttar Pradesh',
    timing: 'Outpatient Triage & Emergency Response',
    contact: '9309330729',
    coordinates: { x: 38, y: 25 },
    facilities: ['Emergency Triage', 'Anti-Tick Treatment Station', 'Farmer Advisory Desk'],
  },
  {
    id: 'loc-mora-ki-milak',
    name: 'Sai Vet Care — Mora ki Milak Centre',
    role: 'Kanth Road Community Veterinary Centre',
    address: 'Mora ki Milak, Behind Vivekanand Hospital, Kanth Road, Moradabad, Uttar Pradesh',
    timing: 'Outpatient Care & Follow-up Dressings',
    contact: '8191921647',
    coordinates: { x: 48, y: 20 },
    facilities: ['Secondary Care Outpost', 'Post-Op Follow-up', 'Emergency Ambulance Liaison'],
  },
];

export const GAUSHALA_PARTNERSHIPS: GaushalaPartnership[] = [
  {
    id: 'gaushala-vrihad',
    name: 'Vrihad Cow Conservation Centre',
    location: 'Village Fazalpur, Ramganga Paar, Moradabad',
    animals: 160,
    contact: '9917438801 / 9917430001',
    notes: 'Regular monthly veterinary camps, deworming, and senior cow health audits.',
  },
  {
    id: 'gaushala-kanha-bhatawali',
    name: 'Kanha Gaushala',
    location: 'Bhatawali, Kashipur Bypass Road, Moradabad',
    animals: 155,
    contact: 'Naresh: 9410456643 | Guddu: 9719308292',
    notes: 'Prophylactic vaccination, hoof care, and mineral supplementation.',
  },
  {
    id: 'gaushala-maa-bhagwati',
    name: 'Maa Bhagwati Gau Rehabilitation Centre',
    location: 'Moradabad, Uttar Pradesh',
    animals: 156,
    contact: '98979688884 / 96979688884',
    notes: 'Rehabilitation of injured, blind, and abandoned elderly cows.',
  },
  {
    id: 'gaushala-kanha-mainather',
    name: 'Kanha Gaushala',
    location: 'Mainather Ki Pulia, Lakri Fazalpur, Moradabad',
    animals: 840,
    contact: 'D.K. Sharma: 9897214211',
    notes: 'Largest partner sanctuary; intensive routine care for 840 indigenous cattle.',
  },
  {
    id: 'gaushala-divya-lok',
    name: 'Divya Lok Gaushala',
    location: 'Ashiyana Phase 2, Moradabad',
    animals: 105,
    contact: 'Main Sai Vet Care Desk: 8191921647',
    notes: 'Urban-perimeter shelter with regular veterinary inspection and treatment.',
  },
  {
    id: 'gaushala-kanha-agwanpur',
    name: 'Kanha Gaushala',
    location: 'Agwanpur Gram, Moradabad',
    animals: 176,
    contact: 'Jaswinder Singh: 9639916123',
    notes: 'Rural cow conservation, mastitis prevention, and seasonal medical drives.',
  },
  {
    id: 'gaushala-kanha-milan-vihar',
    name: 'Kanha Gau Seva Centre',
    location: 'Milan Vihar, Delhi Road, Moradabad',
    animals: 78,
    contact: 'Pintu: 6396941517',
    notes: 'Delhi Road transit shelter; emergency stabilization and nutritional support.',
  },
];

export const TEAM_MEMBERS: TeamMember[] = [
  {
    id: 'team-senior-vet',
    name: 'Senior Veterinarian & Surgeon',
    role: 'Chief Veterinary Medical Officer & Head of Surgery',
    qualification: 'B.V.Sc & A.H., M.V.Sc (Veterinary Surgery)',
    experience: '18+ Years in Clinical & Operative Veterinary Practice',
    bio: 'Leads the clinic with exceptional skill in surgical interventions, emergency trauma reconstruction, and compassionate healthcare across Moradabad.',
    specialization: 'Soft-Tissue & Orthopaedic Surgery, Emergency Triage, Clinical Direction',
  },
  {
    id: 'team-specialist-vet',
    name: 'Veterinary Specialist Clinician',
    role: 'Veterinary Physician & OPD Specialist',
    qualification: 'B.V.Sc & A.H., Specialist in Internal Animal Medicine',
    experience: '12+ Years in Livestock Care & Infectious Diseases',
    bio: 'Oversees outpatient diagnosis, internal medicine, gaushala prophylactic protocols, and regular health check-ups across rural service centres.',
    specialization: 'Internal Medicine, Epidemic Control, Bovine Rumen Health & Diagnostics',
  },
  {
    id: 'team-ops-gaushala',
    name: 'Gaushala Outreach & Operations Coordinator',
    role: 'Field Care & Gaushala Camp Supervisor',
    qualification: 'Diploma in Veterinary Pharmacy & Animal Husbandry',
    experience: '15+ Years in Community Animal Welfare & Rural Logistics',
    bio: 'Coordinates regular monthly visits, deworming drives, and emergency dispatches across 7 partner gaushalas housing over 2,000 cattle.',
    specialization: 'Gaushala Health Management, Rural Farmer Liaison, Herd Vaccination',
  },
  {
    id: 'team-support-nursing',
    name: 'Veterinary Nursing & Volunteer Coordinator',
    role: 'Lead Veterinary Nursing Officer & Patient Care',
    qualification: 'Certified Veterinary Technician & Nursing Specialist',
    experience: '8+ Years in Charitable Animal Care & Hospital Administration',
    bio: 'Supervises daily operations within the temple premises facility, ensuring sterile instrument prep, wound dressings, and free medicine distribution.',
    specialization: 'Post-Op Nursing, Antiseptic Dressings, Free Formulary Inventory',
  },
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'OPD Examination & Treatment at Temple Premises',
    category: 'Clinical Care',
    caption: 'Veterinary doctor conducting clinical examination of an injured street dog at the dedicated temple premises facility in Moradabad.',
    date: 'March 2026',
    location: 'Mahal Kapoor Gram, Moradabad',
  },
  {
    id: 'gal-2',
    title: 'Monthly Health Camp at Kanha Gaushala',
    category: 'Gaushala Seva',
    caption: 'Administering preventive boluses, liquid calcium, and anti-tick injections to cattle at Lakri Fazalpur facility.',
    date: 'February 2026',
    location: 'Mainather Ki Pulia, Moradabad',
  },
  {
    id: 'gal-3',
    title: 'Operation Theatre Surgical Care',
    category: 'Surgical Intervention',
    caption: 'Senior veterinarian performing life-saving wound debridement and fracture immobilization inside the sterile OT.',
    date: 'January 2026',
    location: 'Sai Vet Care Central OT',
  },
  {
    id: 'gal-4',
    title: 'Rural Outreach Camp in Bilari Tehsil',
    category: 'Field Outreach',
    caption: 'Veterinary team providing free check-ups, mineral powders, and treatment to working bullocks in Village Darni.',
    date: 'January 2026',
    location: 'Village Darni (Bilari)',
  },
  {
    id: 'gal-5',
    title: 'Free Medicine Distribution to Cattle Keepers',
    category: 'Free Medicines',
    caption: 'Handing out free antibiotic boluses, enzymes, and milk enhancing powders to economically disadvantaged cattle owners.',
    date: 'December 2025',
    location: 'Ramganga Paar, Moradabad',
  },
  {
    id: 'gal-6',
    title: 'Bovine Recovery & Rehabilitation',
    category: 'Rehabilitation',
    caption: 'Rescued cow regaining vitality and mobility following intensive medical treatment and therapeutic nutrition at Maa Bhagwati Centre.',
    date: 'November 2025',
    location: 'Maa Bhagwati Gau Centre, Moradabad',
  },
];

export const STORY_UPDATES: StoryUpdate[] = [
  {
    id: 'story-1',
    title: 'Emergency Fracture Repair Restores Stride to Rescued Working Bullock',
    date: '28 Feb 2026',
    category: 'Recovery Story',
    summary:
      'Brought to our Mahal Kapoor Gram centre following a highway collision, an injured bullock underwent emergency soft-tissue reconstruction and splinting. Today, he walks pain-free.',
    readTime: '3 min read',
  },
  {
    id: 'story-2',
    title: 'Comprehensive Health Mission Across 7 Partner Gaushalas',
    date: '14 Feb 2026',
    category: 'Field Mission',
    summary:
      'Our monthly health camp reached 1,670+ cattle across Lakri Fazalpur, Bhatawali, and Agwanpur shelters, administering deworming, Ivermectin, and Rumifit boluses.',
    readTime: '4 min read',
  },
  {
    id: 'story-3',
    title: 'Free Medicine Dispensary Crosses Landmark Distribution in Moradabad',
    date: '02 Jan 2026',
    category: 'Seva Milestone',
    summary:
      'Over 14 essential veterinary medicines and nutritional supplements distributed completely free of cost to economically disadvantaged cattle keepers and shelter operators.',
    readTime: '2 min read',
  },
];
