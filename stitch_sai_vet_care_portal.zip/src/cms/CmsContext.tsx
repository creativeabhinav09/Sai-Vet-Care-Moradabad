import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { CmsData, PageContent, PageSection } from './types';
import { DEFAULT_CMS_DATA } from './defaultCmsData';

interface CmsContextType {
  data: CmsData;
  isLoading: boolean;
  isPreviewMode: boolean;
  hasUnpublishedChanges: boolean;
  lastPublishedAt: string;
  refreshContent: () => Promise<void>;
  getPage: (pageId: string) => PageContent | undefined;
  getSection: (pageId: string, sectionId: string) => PageSection | undefined;
  exitPreviewMode: () => void;
}

const CmsContext = createContext<CmsContextType | null>(null);

export const CmsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [data, setData] = useState<CmsData>(DEFAULT_CMS_DATA);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isPreviewMode, setIsPreviewMode] = useState<boolean>(false);
  const [hasUnpublishedChanges, setHasUnpublishedChanges] = useState<boolean>(false);
  const [lastPublishedAt, setLastPublishedAt] = useState<string>(new Date().toISOString());

  // Check URL params for preview mode: ?preview=true
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const searchParams = new URLSearchParams(window.location.search);
      const hashParams = window.location.hash.includes('?')
        ? new URLSearchParams(window.location.hash.split('?')[1])
        : null;

      const isPreview =
        searchParams.get('preview') === 'true' ||
        (hashParams && hashParams.get('preview') === 'true') ||
        sessionStorage.getItem('svcc_preview_mode') === 'true';

      setIsPreviewMode(Boolean(isPreview));
    }
  }, []);

  const fetchContent = useCallback(async () => {
    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem('svcc_admin_token') : null;
      const headers: Record<string, string> = {};
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const isPreview = sessionStorage.getItem('svcc_preview_mode') === 'true';
      const url = isPreview ? '/api/cms/content?preview=true' : '/api/cms/content';

      const res = await fetch(url, { headers });
      if (res.ok) {
        const json = await res.json();
        if (json.content && typeof json.content === 'object') {
          setData(json.content);
          setHasUnpublishedChanges(Boolean(json.hasUnpublishedChanges));
          if (json.lastPublishedAt) setLastPublishedAt(json.lastPublishedAt);
        }
      }
    } catch (err) {
      console.warn('Using baseline CMS fallback data:', err);
      // Fallback remains DEFAULT_CMS_DATA
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchContent();
  }, [fetchContent, isPreviewMode]);

  const getPage = useCallback(
    (pageId: string): PageContent | undefined => {
      return data.pages?.[pageId] || DEFAULT_CMS_DATA.pages?.[pageId];
    },
    [data]
  );

  const getSection = useCallback(
    (pageId: string, sectionId: string): PageSection | undefined => {
      const page = data.pages?.[pageId] || DEFAULT_CMS_DATA.pages?.[pageId];
      if (!page) return undefined;
      return (
        page.sections.find((s) => s.id === sectionId) ||
        DEFAULT_CMS_DATA.pages?.[pageId]?.sections.find((s) => s.id === sectionId)
      );
    },
    [data]
  );

  const exitPreviewMode = () => {
    sessionStorage.removeItem('svcc_preview_mode');
    setIsPreviewMode(false);
    window.location.href = window.location.pathname;
  };

  return (
    <CmsContext.Provider
      value={{
        data,
        isLoading,
        isPreviewMode,
        hasUnpublishedChanges,
        lastPublishedAt,
        refreshContent: fetchContent,
        getPage,
        getSection,
        exitPreviewMode,
      }}
    >
      {/* Top Banner when viewing unpublished draft changes in Preview Mode */}
      {isPreviewMode && (
        <div className="bg-[#1a3d1a] text-white py-2 px-4 sticky top-0 z-[9999] shadow-md border-b border-[#E86A10] flex items-center justify-between text-xs sm:text-sm">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#E86A10] animate-ping" />
            <span className="font-semibold text-[#EFFDF0]">CMS LIVE PREVIEW MODE</span>
            <span className="hidden sm:inline text-white/70">
              — Viewing unpublished draft content
            </span>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <a
              href="#/admin"
              className="bg-[#E86A10] hover:bg-[#d45e0d] text-white px-2.5 py-1 rounded-md font-medium transition-colors"
            >
              Back to Admin
            </a>
            <button
              onClick={exitPreviewMode}
              className="bg-white/10 hover:bg-white/20 text-white px-2.5 py-1 rounded-md transition-colors"
            >
              Exit Preview
            </button>
          </div>
        </div>
      )}
      {children}
    </CmsContext.Provider>
  );
};

export const useCms = (): CmsContextType => {
  const ctx = useContext(CmsContext);
  if (!ctx) {
    throw new Error('useCms must be used within a CmsProvider');
  }
  return ctx;
};
