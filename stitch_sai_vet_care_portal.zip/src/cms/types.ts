import type {
  SevaCard,
  PriorityCareItem,
  MedicalSurgicalDiscipline,
  MedicineItem,
  NetworkLocation,
  GaushalaPartnership,
  TeamMember,
  GalleryItem,
  StoryUpdate,
  TimelineMilestone,
} from '../types';

export type {
  SevaCard,
  PriorityCareItem,
  MedicalSurgicalDiscipline,
  MedicineItem,
  NetworkLocation,
  GaushalaPartnership,
  TeamMember,
  GalleryItem,
  StoryUpdate,
  TimelineMilestone,
};

export interface SeoSettings {
  metaTitle: string;
  metaDescription: string;
  canonicalUrl?: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  robots: 'index, follow' | 'noindex, nofollow' | 'noindex, follow';
}

export interface NavDropdownItem {
  id: string;
  label: string;
  path: string;
  description?: string;
}

export interface NavItem {
  id: string;
  label: string;
  path: string;
  isExternal?: boolean;
  openInNewTab?: boolean;
  children?: NavDropdownItem[];
}

export interface GlobalSettings {
  siteName: string;
  tagline: string;
  logoUrl: string;
  faviconUrl: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  fontFamily: 'serif' | 'sans' | 'system';
  contactPhone: string;
  emergencyPhone: string;
  contactEmail: string;
  address: string;
  socialLinks: {
    facebook: string;
    instagram: string;
    youtube: string;
    twitter: string;
    whatsapp: string;
  };
  globalSeo: SeoSettings;
}

export interface HeaderSettings {
  topBarEnabled: boolean;
  announcementText: string;
  announcementLink: string;
  showEmergencyButton: boolean;
  emergencyButtonText: string;
  emergencyButtonPhone: string;
  navItems: NavItem[];
}

export interface FooterColumn {
  title: string;
  links: Array<{
    label: string;
    path: string;
    isExternal?: boolean;
  }>;
}

export interface FooterSettings {
  aboutText: string;
  copyrightText: string;
  registrationNumber: string;
  emergencyCalloutTitle: string;
  emergencyCalloutText: string;
  columns: FooterColumn[];
}

export interface PageSectionItem {
  id: string;
  title: string;
  subtitle?: string;
  description?: string;
  icon?: string;
  badge?: string;
  link?: string;
  imageUrl?: string;
  features?: string[];
  [key: string]: any;
}

export interface PageSection {
  id: string;
  type: string;
  name: string;
  enabled: boolean;
  title?: string;
  eyebrow?: string;
  subtitle?: string;
  description?: string;
  content?: string; // Rich-text HTML
  imageUrl?: string;
  imageAlt?: string;
  ctaText?: string;
  ctaLink?: string;
  secondaryCtaText?: string;
  secondaryCtaLink?: string;
  items?: PageSectionItem[];
  customHtml?: string;
}

export interface PageContent {
  id: string;
  title: string;
  slug: string;
  seo: SeoSettings;
  sections: PageSection[];
}

export interface MediaItem {
  id: string;
  url: string;
  filename: string;
  title: string;
  alt: string;
  caption: string;
  size: number;
  width?: number;
  height?: number;
  uploadedAt: string;
}

export interface CmsCollections {
  stories: (StoryUpdate & { content?: string; status?: 'published' | 'draft'; author?: string; imageUrl?: string })[];
  gallery: GalleryItem[];
  team: TeamMember[];
  medicines: MedicineItem[];
  timeline: TimelineMilestone[];
  sevaCards: SevaCard[];
  priorityCare: PriorityCareItem[];
  networkLocations: NetworkLocation[];
  gaushalaPartners: GaushalaPartnership[];
  gaushalaPartnerships?: GaushalaPartnership[];
}

export interface CmsData {
  version: number;
  updatedAt: string;
  settings: GlobalSettings;
  header: HeaderSettings;
  footer: FooterSettings;
  pages: Record<string, PageContent>;
  collections: CmsCollections;
  media: MediaItem[];
}

export interface CmsStorageState {
  published: CmsData;
  draft: CmsData;
  hasUnpublishedChanges: boolean;
  lastPublishedAt: string;
}

export interface BackupMetadata {
  id: string;
  timestamp: string;
  label: string;
  size: number;
  version: number;
}
