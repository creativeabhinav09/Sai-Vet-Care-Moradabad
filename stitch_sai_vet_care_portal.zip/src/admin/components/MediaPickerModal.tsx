import React, { useState } from 'react';
import { X, Upload, Image as ImageIcon, Check, Search } from 'lucide-react';
import { MediaItem } from '../../cms/types';

interface MediaPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (url: string, mediaItem?: MediaItem) => void;
  mediaList: MediaItem[];
  onUpload: (item: MediaItem) => void;
}

export const MediaPickerModal: React.FC<MediaPickerModalProps> = ({
  isOpen,
  onClose,
  onSelect,
  mediaList,
  onUpload,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [customUrl, setCustomUrl] = useState('');
  const [uploadError, setUploadError] = useState('');

  if (!isOpen) return null;

  const filteredMedia = mediaList.filter(
    (item) =>
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.filename.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.alt.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setUploadError('Please select a valid image file (PNG, JPG, WebP, SVG).');
      return;
    }

    setUploadError('');
    setIsUploading(true);

    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = reader.result as string;
        const token = localStorage.getItem('svcc_admin_token');

        const res = await fetch('/api/cms/media/upload', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            filename: file.name,
            base64Data,
            title: file.name.replace(/\.[^/.]+$/, ''),
            alt: file.name.replace(/\.[^/.]+$/, ''),
          }),
        });

        if (res.ok) {
          const json = await res.json();
          if (json.mediaItem) {
            onUpload(json.mediaItem);
            onSelect(json.mediaItem.url, json.mediaItem);
            onClose();
          }
        } else {
          const errData = await res.json().catch(() => ({}));
          setUploadError(errData.error || 'Failed to upload image');
        }
        setIsUploading(false);
      };
      reader.readAsDataURL(file);
    } catch (err: any) {
      setUploadError('Upload failed: ' + err.message);
      setIsUploading(false);
    }
  };

  const handleSelectCustomUrl = () => {
    if (customUrl.trim()) {
      onSelect(customUrl.trim());
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-[10000] bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-gray-200 overflow-hidden animate-scale-in">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-gray-200 bg-gray-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#1a3d1a] text-white flex items-center justify-center">
              <ImageIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 text-base">Select or Upload Image</h3>
              <p className="text-xs text-gray-500">Pick from media library or upload a new photo</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action bar: Search + Upload + URL Input */}
        <div className="p-4 border-b border-gray-200 bg-white flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search images in media library..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-lg focus:outline-hidden focus:border-[#1a3d1a]"
            />
          </div>

          <label className="cursor-pointer inline-flex items-center gap-2 px-3.5 py-2 bg-[#1a3d1a] hover:bg-[#285e28] text-white rounded-lg text-xs sm:text-sm font-medium transition-colors shadow-2xs">
            <Upload className="w-4 h-4" />
            <span>{isUploading ? 'Uploading...' : 'Upload Image'}</span>
            <input
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              disabled={isUploading}
              className="hidden"
            />
          </label>
        </div>

        {uploadError && (
          <div className="mx-4 mt-3 p-2.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg">
            {uploadError}
          </div>
        )}

        {/* Media Grid */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {filteredMedia.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <ImageIcon className="w-12 h-12 mx-auto mb-2 text-gray-300" />
              <p className="text-sm font-medium">No images found</p>
              <p className="text-xs text-gray-400 mt-1">Upload a photo using the button above</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
              {filteredMedia.map((item) => (
                <div
                  key={item.id}
                  onClick={() => {
                    onSelect(item.url, item);
                    onClose();
                  }}
                  className="group relative rounded-xl border border-gray-200 overflow-hidden bg-gray-50 aspect-square cursor-pointer hover:border-[#1a3d1a] hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <img
                    src={item.url}
                    alt={item.alt}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-2 text-white">
                    <span className="bg-[#1a3d1a] text-white text-xs px-2.5 py-1 rounded-md font-medium flex items-center gap-1 shadow-sm">
                      <Check className="w-3.5 h-3.5" /> Select
                    </span>
                  </div>
                  <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/70 to-transparent p-2 text-white text-[11px] truncate">
                    {item.title}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Or enter custom web image link */}
        <div className="p-4 bg-gray-50 border-t border-gray-200 flex items-center gap-2">
          <input
            type="text"
            placeholder="Or paste external image web URL (https://...)"
            value={customUrl}
            onChange={(e) => setCustomUrl(e.target.value)}
            className="flex-1 px-3 py-1.5 text-xs border border-gray-300 rounded-lg focus:outline-hidden focus:border-[#1a3d1a]"
          />
          <button
            onClick={handleSelectCustomUrl}
            disabled={!customUrl.trim()}
            className="px-3 py-1.5 bg-gray-800 hover:bg-black disabled:opacity-40 text-white rounded-lg text-xs font-medium transition-colors"
          >
            Use Link
          </button>
        </div>
      </div>
    </div>
  );
};
