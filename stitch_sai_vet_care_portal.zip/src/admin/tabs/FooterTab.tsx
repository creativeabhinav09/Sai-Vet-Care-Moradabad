import React from 'react';
import {
  FileText,
  Plus,
  Trash2,
  PhoneCall,
  ShieldCheck,
} from 'lucide-react';
import { FooterSettings } from '../../cms/types';

interface FooterTabProps {
  footer: FooterSettings;
  onChange: (updatedFooter: FooterSettings) => void;
}

export const FooterTab: React.FC<FooterTabProps> = ({ footer, onChange }) => {
  const updateFooter = (field: keyof FooterSettings, value: any) => {
    onChange({
      ...footer,
      [field]: value,
    });
  };

  const handleAddLink = (colIndex: number) => {
    const newColumns = [...footer.columns];
    newColumns[colIndex].links.push({
      label: 'New Link',
      path: '/about',
    });
    updateFooter('columns', newColumns);
  };

  const handleUpdateLink = (colIndex: number, linkIndex: number, field: string, val: string) => {
    const newColumns = [...footer.columns];
    newColumns[colIndex].links[linkIndex] = {
      ...newColumns[colIndex].links[linkIndex],
      [field]: val,
    };
    updateFooter('columns', newColumns);
  };

  const handleDeleteLink = (colIndex: number, linkIndex: number) => {
    const newColumns = [...footer.columns];
    newColumns[colIndex].links.splice(linkIndex, 1);
    updateFooter('columns', newColumns);
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in max-w-4xl">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-gray-900">
          Global Website Footer Settings
        </h1>
        <p className="text-xs sm:text-sm text-gray-500 mt-1">
          Edit mission statements, statutory trust details, emergency callout, and footer links across all pages.
        </p>
      </div>

      {/* About & Trust Statement */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-900 pb-2 border-b border-gray-100">
          <FileText className="w-4 h-4 text-[#1a3d1a]" />
          <span>Footer Identity & Mission Statement</span>
        </div>

        <div>
          <label className="block text-xs font-semibold text-gray-700 mb-1">
            Footer Mission Statement / About Paragraph
          </label>
          <textarea
            rows={3}
            value={footer.aboutText || ''}
            onChange={(e) => updateFooter('aboutText', e.target.value)}
            className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl leading-relaxed focus:border-[#1a3d1a]"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Copyright Notice
            </label>
            <input
              type="text"
              value={footer.copyrightText || ''}
              onChange={(e) => updateFooter('copyrightText', e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Statutory Trust Registration Number
            </label>
            <input
              type="text"
              value={footer.registrationNumber || ''}
              onChange={(e) => updateFooter('registrationNumber', e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl"
            />
          </div>
        </div>
      </div>

      {/* Emergency Distress Callout */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-900 pb-2 border-b border-gray-100">
          <PhoneCall className="w-4 h-4 text-emerald-600" />
          <span>Footer Emergency Distress Banner</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Callout Headline
            </label>
            <input
              type="text"
              value={footer.emergencyCalloutTitle || ''}
              onChange={(e) => updateFooter('emergencyCalloutTitle', e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Callout Description
            </label>
            <input
              type="text"
              value={footer.emergencyCalloutText || ''}
              onChange={(e) => updateFooter('emergencyCalloutText', e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl"
            />
          </div>
        </div>
      </div>

      {/* Navigation Link Columns */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-gray-100">
          <div className="text-sm font-bold text-gray-900">Footer Link Columns</div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {footer.columns.map((col, cIdx) => (
            <div key={cIdx} className="bg-gray-50 p-4 rounded-xl border border-gray-200 space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-gray-700 mb-1">
                  Column Title
                </label>
                <input
                  type="text"
                  value={col.title}
                  onChange={(e) => {
                    const newColumns = [...footer.columns];
                    newColumns[cIdx].title = e.target.value;
                    updateFooter('columns', newColumns);
                  }}
                  className="w-full px-2.5 py-1 text-xs border border-gray-300 rounded-lg bg-white font-semibold"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-[11px] text-gray-500 font-semibold">
                  <span>Links ({col.links.length})</span>
                  <button
                    type="button"
                    onClick={() => handleAddLink(cIdx)}
                    className="text-[#1a3d1a] hover:underline flex items-center gap-0.5"
                  >
                    <Plus className="w-3 h-3" /> Add Link
                  </button>
                </div>

                {col.links.map((link, lIdx) => (
                  <div key={lIdx} className="p-2 bg-white rounded-lg border border-gray-200 space-y-1.5">
                    <div className="flex items-center justify-between gap-1">
                      <input
                        type="text"
                        value={link.label}
                        onChange={(e) => handleUpdateLink(cIdx, lIdx, 'label', e.target.value)}
                        placeholder="Label"
                        className="flex-1 px-2 py-0.5 text-xs border border-gray-300 rounded"
                      />
                      <button
                        type="button"
                        onClick={() => handleDeleteLink(cIdx, lIdx)}
                        className="text-red-400 hover:text-red-600 p-0.5"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <input
                      type="text"
                      value={link.path}
                      onChange={(e) => handleUpdateLink(cIdx, lIdx, 'path', e.target.value)}
                      placeholder="/link"
                      className="w-full px-2 py-0.5 text-[11px] border border-gray-300 rounded font-mono"
                    />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
