import React, { useState } from 'react';
import {
  BookOpen,
  Plus,
  Edit,
  Trash2,
  Calendar,
  Check,
  X,
  Image as ImageIcon,
  Clock,
  Sparkles,
} from 'lucide-react';
import { CmsCollections, MediaItem } from '../../cms/types';
import { RichTextEditor } from '../components/RichTextEditor';
import { MediaPickerModal } from '../components/MediaPickerModal';

interface StoriesTabProps {
  stories: CmsCollections['stories'];
  mediaList: MediaItem[];
  onChange: (updatedStories: CmsCollections['stories']) => void;
  onUploadMedia: (item: MediaItem) => void;
}

export const StoriesTab: React.FC<StoriesTabProps> = ({
  stories,
  mediaList,
  onChange,
  onUploadMedia,
}) => {
  const [editingStory, setEditingStory] = useState<any | null>(null);
  const [isMediaPickerOpen, setIsMediaPickerOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredStories = stories.filter(
    (s) =>
      s.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.summary.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddNew = () => {
    const newStory = {
      id: `story-${Date.now()}`,
      title: 'New Healing Story',
      category: 'Orthopedic Rehabilitation',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      readTime: '3 min read',
      author: 'SVCC Medical Team',
      status: 'published' as const,
      summary: 'A short compelling summary of the animal rescue or recovery...',
      content: '<p>Detailed description of the clinical intervention and post-operative recovery.</p>',
      imageUrl: 'https://polo-pecan-73837341.figma.site/_assets/v11/96745c4e72ad5c5208e53a885df797fd82cd854a.png',
    };
    setEditingStory(newStory);
  };

  const handleSave = () => {
    if (!editingStory) return;
    const exists = stories.some((s) => s.id === editingStory.id);
    let updated;
    if (exists) {
      updated = stories.map((s) => (s.id === editingStory.id ? editingStory : s));
    } else {
      updated = [editingStory, ...stories];
    }
    onChange(updated);
    setEditingStory(null);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this healing story?')) {
      onChange(stories.filter((s) => s.id !== id));
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in max-w-5xl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900">
            Healing Stories & Field Reports Manager
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 mt-1">
            Create, edit, or remove documentary recovery stories of rescued animals.
          </p>
        </div>

        <button
          type="button"
          onClick={handleAddNew}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#1a3d1a] hover:bg-[#285e28] text-white rounded-xl text-xs sm:text-sm font-semibold transition-colors shadow-2xs cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Story</span>
        </button>
      </div>

      {/* Stories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredStories.map((story) => (
          <div
            key={story.id}
            className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-2xs hover:border-[#1a3d1a] hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div className="p-4 sm:p-5">
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200/60">
                  {story.category}
                </span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    story.status === 'draft'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-green-100 text-green-800'
                  }`}
                >
                  {story.status || 'published'}
                </span>
              </div>

              <h3 className="font-bold text-gray-900 text-base leading-snug mb-1">
                {story.title}
              </h3>
              <p className="text-xs text-gray-600 line-clamp-2 leading-relaxed mb-3">
                {story.summary}
              </p>

              <div className="flex items-center gap-3 text-[11px] text-gray-400">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5" />
                  {story.date}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  {story.readTime}
                </span>
              </div>
            </div>

            <div className="p-3 bg-gray-50 border-t border-gray-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingStory({ ...story })}
                className="px-3 py-1.5 text-xs font-semibold text-[#1a3d1a] hover:bg-white rounded-lg border border-transparent hover:border-gray-200 flex items-center gap-1 transition-all"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
              <button
                type="button"
                onClick={() => handleDelete(story.id)}
                className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                title="Delete Story"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Story Modal */}
      {editingStory && (
        <div className="fixed inset-0 z-[10000] bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-gray-200 overflow-hidden animate-scale-in">
            <div className="flex items-center justify-between p-4 sm:p-5 border-b border-gray-200 bg-gray-50">
              <h3 className="font-bold text-gray-900 text-base">
                {editingStory.id.startsWith('story-') && !stories.some((s) => s.id === editingStory.id)
                  ? 'Add New Healing Story'
                  : 'Edit Story'}
              </h3>
              <button
                onClick={() => setEditingStory(null)}
                className="p-1 text-gray-400 hover:text-gray-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Story Title
                </label>
                <input
                  type="text"
                  value={editingStory.title || ''}
                  onChange={(e) => setEditingStory({ ...editingStory, title: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Category Discipline
                  </label>
                  <input
                    type="text"
                    value={editingStory.category || ''}
                    onChange={(e) => setEditingStory({ ...editingStory, category: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Publish Date
                  </label>
                  <input
                    type="text"
                    value={editingStory.date || ''}
                    onChange={(e) => setEditingStory({ ...editingStory, date: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Publication Status
                  </label>
                  <select
                    value={editingStory.status || 'published'}
                    onChange={(e) => setEditingStory({ ...editingStory, status: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg bg-white"
                  >
                    <option value="published">Published</option>
                    <option value="draft">Draft</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Card Summary / Excerpt
                </label>
                <textarea
                  rows={2}
                  value={editingStory.summary || ''}
                  onChange={(e) => setEditingStory({ ...editingStory, summary: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs sm:text-sm border border-gray-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Story Image URL
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={editingStory.imageUrl || ''}
                    onChange={(e) => setEditingStory({ ...editingStory, imageUrl: e.target.value })}
                    className="flex-1 px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={() => setIsMediaPickerOpen(true)}
                    className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-xs rounded-lg flex items-center gap-1 font-semibold"
                  >
                    <ImageIcon className="w-3.5 h-3.5" /> Pick
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Full Story Content (Rich-Text Editor)
                </label>
                <RichTextEditor
                  value={editingStory.content || ''}
                  onChange={(content) => setEditingStory({ ...editingStory, content })}
                />
              </div>
            </div>

            <div className="p-4 bg-gray-50 border-t border-gray-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingStory(null)}
                className="px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-200 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-5 py-2 bg-[#1a3d1a] hover:bg-[#285e28] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 shadow-2xs"
              >
                <Check className="w-4 h-4" /> Save Story
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Media Picker */}
      <MediaPickerModal
        isOpen={isMediaPickerOpen}
        onClose={() => setIsMediaPickerOpen(false)}
        mediaList={mediaList}
        onUpload={onUploadMedia}
        onSelect={(url) => {
          if (editingStory) setEditingStory({ ...editingStory, imageUrl: url });
        }}
      />
    </div>
  );
};
