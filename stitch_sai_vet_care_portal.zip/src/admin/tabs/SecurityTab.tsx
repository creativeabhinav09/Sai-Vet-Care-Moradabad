import React, { useState } from 'react';
import {
  Lock,
  KeyRound,
  ShieldAlert,
  ShieldCheck,
  Check,
  User,
  Server,
  HelpCircle,
} from 'lucide-react';

export const SecurityTab: React.FC = () => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    if (!currentPassword) {
      setStatusMessage({ text: 'Please enter your current password.', type: 'error' });
      return;
    }

    if (newPassword && newPassword !== confirmPassword) {
      setStatusMessage({ text: 'New password and confirmation do not match.', type: 'error' });
      return;
    }

    if (newPassword && newPassword.length < 6) {
      setStatusMessage({ text: 'New password must be at least 6 characters.', type: 'error' });
      return;
    }

    setIsSubmitting(true);
    const token = localStorage.getItem('svcc_admin_token');

    try {
      const res = await fetch('/api/auth/change-credentials', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          currentPassword,
          newUsername: newUsername.trim() || undefined,
          newPassword: newPassword || undefined,
        }),
      });

      const json = await res.json();
      if (res.ok) {
        setStatusMessage({ text: 'Admin security credentials updated successfully!', type: 'success' });
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        setStatusMessage({ text: json.error || 'Failed to update credentials', type: 'error' });
      }
    } catch (err: any) {
      setStatusMessage({ text: 'Network error: ' + err.message, type: 'error' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in max-w-3xl">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-gray-900">
          Admin Security & Password Settings
        </h1>
        <p className="text-xs sm:text-sm text-gray-500 mt-1">
          Manage your login credentials, password hashing, and session authentication.
        </p>
      </div>

      {statusMessage && (
        <div
          className={`p-4 rounded-xl text-xs sm:text-sm font-medium ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          {statusMessage.text}
        </div>
      )}

      {/* Password Change Form */}
      <form onSubmit={handleSubmit} className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-900 pb-2 border-b border-gray-100">
          <KeyRound className="w-4 h-4 text-[#1a3d1a]" />
          <span>Update Admin Credentials</span>
        </div>

        <div>
          <label className="block text-xs font-semibold text-gray-700 mb-1">
            Current Admin Password <span className="text-red-500">*</span>
          </label>
          <input
            type="password"
            required
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
            placeholder="Enter current password to authorize changes"
          />
        </div>

        <div className="pt-2 border-t border-gray-100">
          <label className="block text-xs font-semibold text-gray-700 mb-1">
            New Username (Optional)
          </label>
          <input
            type="text"
            value={newUsername}
            onChange={(e) => setNewUsername(e.target.value)}
            className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
            placeholder="Leave blank to keep current username"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              New Password (Optional)
            </label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
              placeholder="Minimum 6 characters"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Confirm New Password
            </label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
              placeholder="Re-type new password"
            />
          </div>
        </div>

        <div className="pt-3">
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-5 py-2.5 bg-[#1a3d1a] hover:bg-[#285e28] text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{isSubmitting ? 'Updating...' : 'Save New Credentials'}</span>
          </button>
        </div>
      </form>

      {/* Security Architecture Info */}
      <div className="bg-[#F7F3EA] p-5 sm:p-6 rounded-2xl border border-[#294936]/15 text-[#1a3d1a] space-y-3">
        <div className="flex items-center gap-2 font-bold text-sm sm:text-base">
          <Server className="w-4 h-4 text-[#6F8F72]" />
          <span>Security & Hostinger Deployment Specifications</span>
        </div>
        <p className="text-xs sm:text-sm leading-relaxed text-[#26332B]/85">
          The CMS backend is powered by Node.js and Express with flat-file JSON persistence:
        </p>
        <ul className="space-y-1.5 text-xs text-gray-700 list-disc list-inside">
          <li><strong>Cryptographic Password Hashing:</strong> Passwords are hashed using <code>scrypt</code> with a unique cryptographic 16-byte salt. Raw passwords are never stored.</li>
          <li><strong>Session Bearer Tokens:</strong> Authenticated requests use 64-character random tokens validated by the server on every write action.</li>
          <li><strong>Zero Client Credentials:</strong> Admin credentials are stored strictly in <code>data/admin_auth.json</code> on the server and are never bundled in client code.</li>
          <li><strong>Hostinger Compatibility:</strong> Works on standard Hostinger Node.js hosting, VPS, or cloud instances with zero external database dependencies.</li>
        </ul>
      </div>
    </div>
  );
};
