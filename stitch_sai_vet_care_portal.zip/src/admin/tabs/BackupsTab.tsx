import React, { useState, useEffect } from 'react';
import {
  Download,
  Upload,
  History,
  RotateCcw,
  Plus,
  ShieldCheck,
  Clock,
  AlertTriangle,
  Check,
} from 'lucide-react';
import { BackupMetadata } from '../../cms/types';

interface BackupsTabProps {
  onRestoreComplete: () => void;
}

export const BackupsTab: React.FC<BackupsTabProps> = ({ onRestoreComplete }) => {
  const [backups, setBackups] = useState<BackupMetadata[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [newBackupLabel, setNewBackupLabel] = useState('');

  const fetchBackups = async () => {
    setIsLoading(true);
    const token = localStorage.getItem('svcc_admin_token');
    try {
      const res = await fetch('/api/cms/backups', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const json = await res.json();
        setBackups(json.backups || []);
      }
    } catch (err) {
      console.error('Error fetching backups:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchBackups();
  }, []);

  const handleCreateBackup = async () => {
    const token = localStorage.getItem('svcc_admin_token');
    setIsLoading(true);
    try {
      const res = await fetch('/api/cms/backups/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ label: newBackupLabel || `Manual Backup ${new Date().toLocaleString()}` }),
      });
      if (res.ok) {
        setMessage({ text: 'Manual backup snapshot created successfully!', type: 'success' });
        setNewBackupLabel('');
        fetchBackups();
      }
    } catch (err: any) {
      setMessage({ text: 'Failed to create backup: ' + err.message, type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRestore = async (backupId: string) => {
    if (!confirm('Are you sure you want to restore this backup? This will replace your current draft and published website content with this snapshot.')) {
      return;
    }

    const token = localStorage.getItem('svcc_admin_token');
    setIsLoading(true);
    try {
      const res = await fetch(`/api/cms/backups/restore/${backupId}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setMessage({ text: 'Website content restored successfully from backup!', type: 'success' });
        onRestoreComplete();
        fetchBackups();
      } else {
        const err = await res.json();
        setMessage({ text: err.error || 'Failed to restore backup', type: 'error' });
      }
    } catch (err: any) {
      setMessage({ text: 'Failed to restore backup: ' + err.message, type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadBackup = () => {
    const token = localStorage.getItem('svcc_admin_token');
    window.location.href = `/api/cms/backup/download?token=${token}`;
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const json = JSON.parse(reader.result as string);
        const payload = json.content || json;

        if (!confirm('Import this backup file? Your website content will be updated to match the file.')) {
          return;
        }

        const token = localStorage.getItem('svcc_admin_token');
        setIsLoading(true);

        const res = await fetch('/api/cms/backup/import', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ content: payload }),
        });

        if (res.ok) {
          setMessage({ text: 'Backup file imported and applied successfully!', type: 'success' });
          onRestoreComplete();
          fetchBackups();
        } else {
          const err = await res.json();
          setMessage({ text: err.error || 'Failed to import backup file', type: 'error' });
        }
      } catch (err: any) {
        setMessage({ text: 'Invalid JSON file: ' + err.message, type: 'error' });
      } finally {
        setIsLoading(false);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in max-w-4xl">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-gray-900">
          Backup, Version History & Content Recovery
        </h1>
        <p className="text-xs sm:text-sm text-gray-500 mt-1">
          Every time you publish, an automatic snapshot is saved. You can also download complete JSON backups or restore past versions safely.
        </p>
      </div>

      {message && (
        <div
          className={`p-3.5 rounded-xl text-xs sm:text-sm font-medium flex items-center justify-between ${
            message.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <span>{message.text}</span>
          <button onClick={() => setMessage(null)} className="font-bold ml-2">
            ×
          </button>
        </div>
      )}

      {/* Action Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Create Manual Backup */}
        <div className="p-5 bg-white rounded-2xl border border-gray-200 shadow-2xs space-y-3">
          <div className="text-sm font-bold text-gray-900 flex items-center gap-2">
            <Plus className="w-4 h-4 text-[#1a3d1a]" />
            <span>Create Immediate Snapshot</span>
          </div>
          <p className="text-xs text-gray-500 leading-relaxed">
            Take a manual backup snapshot right now before making major text or section changes.
          </p>
          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="Backup label (e.g. Before Summer Overhaul)"
              value={newBackupLabel}
              onChange={(e) => setNewBackupLabel(e.target.value)}
              className="flex-1 px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
            />
            <button
              onClick={handleCreateBackup}
              disabled={isLoading}
              className="px-3.5 py-1.5 bg-[#1a3d1a] hover:bg-[#285e28] text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Snapshot
            </button>
          </div>
        </div>

        {/* Download & Import JSON Files */}
        <div className="p-5 bg-white rounded-2xl border border-gray-200 shadow-2xs space-y-3">
          <div className="text-sm font-bold text-gray-900 flex items-center gap-2">
            <Download className="w-4 h-4 text-blue-600" />
            <span>Export & Import JSON Backup</span>
          </div>
          <p className="text-xs text-gray-500 leading-relaxed">
            Download your website content as a file to keep on your computer or import to another server.
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadBackup}
              className="flex-1 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold rounded-lg border border-blue-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download JSON</span>
            </button>

            <label className="flex-1 cursor-pointer px-3 py-1.5 bg-gray-50 hover:bg-gray-100 text-gray-700 text-xs font-semibold rounded-lg border border-gray-300 transition-colors flex items-center justify-center gap-1.5">
              <Upload className="w-3.5 h-3.5" />
              <span>Import File</span>
              <input
                type="file"
                accept=".json"
                onChange={handleImportBackup}
                disabled={isLoading}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </div>

      {/* Snapshot History Table */}
      <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-2xs">
        <div className="p-4 sm:p-5 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-bold text-gray-900">
            <History className="w-4 h-4 text-[#1a3d1a]" />
            <span>Saved Backup Snapshots ({backups.length})</span>
          </div>
          <button
            onClick={fetchBackups}
            className="text-xs text-gray-500 hover:text-gray-900 underline"
          >
            Refresh List
          </button>
        </div>

        {backups.length === 0 ? (
          <div className="p-8 text-center text-gray-400 text-xs">
            No backups recorded yet. Snapshots will appear automatically when you publish.
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {backups.map((b) => (
              <div
                key={b.id}
                className="p-3.5 sm:p-4 flex flex-wrap items-center justify-between gap-3 hover:bg-gray-50 transition-colors"
              >
                <div>
                  <div className="text-xs sm:text-sm font-bold text-gray-900">{b.label}</div>
                  <div className="text-[11px] text-gray-400 flex items-center gap-2 mt-0.5">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {new Date(b.timestamp).toLocaleString()}
                    </span>
                    <span>· Version v{b.version}</span>
                    <span>· {(b.size / 1024).toFixed(1)} KB</span>
                  </div>
                </div>

                <button
                  onClick={() => handleRestore(b.id)}
                  className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-semibold rounded-lg border border-amber-200 flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restore Snapshot</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
