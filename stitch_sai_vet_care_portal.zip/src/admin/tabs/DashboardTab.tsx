import React from 'react';
import {
  FileText,
  Layers,
  Image as ImageIcon,
  BookOpen,
  Users,
  CheckCircle2,
  Clock,
  Sparkles,
  ArrowUpRight,
  Shield,
  HelpCircle,
} from 'lucide-react';
import { CmsData } from '../../cms/types';

interface DashboardTabProps {
  cmsData: CmsData;
  hasUnpublishedChanges: boolean;
  lastPublishedAt: string;
  setActiveTab: (tab: string) => void;
  onPreview: () => void;
  onPublish: () => void;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({
  cmsData,
  hasUnpublishedChanges,
  lastPublishedAt,
  setActiveTab,
  onPreview,
  onPublish,
}) => {
  const totalPages = Object.keys(cmsData.pages || {}).length;
  const totalSections = Object.values(cmsData.pages || {}).reduce(
    (acc, page) => acc + (page.sections?.length || 0),
    0
  );
  const totalMedia = cmsData.media?.length || 0;
  const totalStories = cmsData.collections?.stories?.length || 0;
  const totalTeam = cmsData.collections?.team?.length || 0;
  const totalGallery = cmsData.collections?.gallery?.length || 0;

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in">
      {/* Welcome Banner */}
      <div className="rounded-2xl sm:rounded-3xl bg-gradient-to-br from-[#1a3d1a] to-[#2d5a2d] text-white p-6 sm:p-8 shadow-lg border border-[#6F8F72]/30 relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-[#EDE4D3] text-xs font-medium mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#E86A10]" />
            <span>Sai Vet Care Clinic CMS Control Center</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#EFFDF0] tracking-tight">
            Welcome to Your Website Admin Panel
          </h1>
          <p className="mt-2 text-sm sm:text-base text-white/85 leading-relaxed">
            Manage your entire website visually without touching code. Edit text, headings, images, navigation, SEO, and sections, preview your changes safely, and publish them to the live website with one click.
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              onClick={onPreview}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white text-[#1a3d1a] hover:bg-gray-100 rounded-xl text-xs sm:text-sm font-semibold transition-all shadow-xs cursor-pointer"
            >
              <span>Live Website Preview</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
            {hasUnpublishedChanges && (
              <button
                onClick={onPublish}
                className="inline-flex items-center gap-2 px-4 py-2 bg-[#E86A10] hover:bg-[#d45e0d] text-white rounded-xl text-xs sm:text-sm font-semibold transition-all shadow-md cursor-pointer animate-pulse"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Publish Pending Changes</span>
              </button>
            )}
          </div>
        </div>

        {/* Decorative background shape */}
        <div className="absolute right-0 bottom-0 translate-x-12 translate-y-12 w-64 h-64 rounded-full bg-white/5 pointer-events-none" />
      </div>

      {/* Status Bar */}
      <div className="p-4 sm:p-5 rounded-2xl bg-white border border-gray-200 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div
            className={`w-4 h-4 rounded-full ${
              hasUnpublishedChanges ? 'bg-amber-500 animate-ping' : 'bg-emerald-500'
            }`}
          />
          <div>
            <div className="text-sm font-semibold text-gray-900">
              {hasUnpublishedChanges
                ? 'You have draft changes waiting to be published'
                : 'All changes are currently live on the public website'}
            </div>
            <div className="text-xs text-gray-500 flex items-center gap-1.5 mt-0.5">
              <Clock className="w-3.5 h-3.5" />
              <span>Last published: {new Date(lastPublishedAt).toLocaleString()}</span>
            </div>
          </div>
        </div>

        <div className="text-xs text-gray-500 font-mono">
          CMS Version: v{cmsData.version || 1} · Flat-file Node Storage
        </div>
      </div>

      {/* Quick Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        <div
          onClick={() => setActiveTab('pages')}
          className="p-4 bg-white rounded-2xl border border-gray-200 shadow-2xs hover:border-[#1a3d1a] hover:shadow-xs transition-all cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
            <FileText className="w-4.5 h-4.5" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-gray-900">{totalPages}</div>
          <div className="text-xs font-medium text-gray-500">Live Pages</div>
        </div>

        <div
          onClick={() => setActiveTab('pages')}
          className="p-4 bg-white rounded-2xl border border-gray-200 shadow-2xs hover:border-[#1a3d1a] hover:shadow-xs transition-all cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
            <Layers className="w-4.5 h-4.5" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-gray-900">{totalSections}</div>
          <div className="text-xs font-medium text-gray-500">Page Sections</div>
        </div>

        <div
          onClick={() => setActiveTab('media')}
          className="p-4 bg-white rounded-2xl border border-gray-200 shadow-2xs hover:border-[#1a3d1a] hover:shadow-xs transition-all cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
            <ImageIcon className="w-4.5 h-4.5" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-gray-900">{totalMedia}</div>
          <div className="text-xs font-medium text-gray-500">Media Items</div>
        </div>

        <div
          onClick={() => setActiveTab('stories')}
          className="p-4 bg-white rounded-2xl border border-gray-200 shadow-2xs hover:border-[#1a3d1a] hover:shadow-xs transition-all cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
            <BookOpen className="w-4.5 h-4.5" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-gray-900">{totalStories}</div>
          <div className="text-xs font-medium text-gray-500">Healing Stories</div>
        </div>

        <div
          onClick={() => setActiveTab('team')}
          className="p-4 bg-white rounded-2xl border border-gray-200 shadow-2xs hover:border-[#1a3d1a] hover:shadow-xs transition-all cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
            <Users className="w-4.5 h-4.5" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-gray-900">{totalTeam}</div>
          <div className="text-xs font-medium text-gray-500">Doctors & Staff</div>
        </div>

        <div
          onClick={() => setActiveTab('gallery')}
          className="p-4 bg-white rounded-2xl border border-gray-200 shadow-2xs hover:border-[#1a3d1a] hover:shadow-xs transition-all cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
            <ImageIcon className="w-4.5 h-4.5" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-gray-900">{totalGallery}</div>
          <div className="text-xs font-medium text-gray-500">Gallery Photos</div>
        </div>
      </div>

      {/* Quick Launch Cards */}
      <div>
        <h2 className="text-base sm:text-lg font-bold text-gray-900 mb-3 sm:mb-4">
          Quick Editing Tasks
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div
            onClick={() => setActiveTab('header')}
            className="p-5 rounded-2xl bg-white border border-gray-200 hover:border-[#1a3d1a] hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="text-sm font-bold text-gray-900 group-hover:text-[#1a3d1a] mb-1">
              Top Announcement & Menu
            </div>
            <p className="text-xs text-gray-500 leading-relaxed mb-3">
              Change the emergency hotline bar, header logo, menu items, or phone number.
            </p>
            <span className="text-xs font-semibold text-[#1a3d1a] inline-flex items-center gap-1">
              Edit Header →
            </span>
          </div>

          <div
            onClick={() => setActiveTab('pages')}
            className="p-5 rounded-2xl bg-white border border-gray-200 hover:border-[#1a3d1a] hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="text-sm font-bold text-gray-900 group-hover:text-[#1a3d1a] mb-1">
              Page Content & Sections
            </div>
            <p className="text-xs text-gray-500 leading-relaxed mb-3">
              Edit headlines, paragraphs, images, button links, or section order for any page.
            </p>
            <span className="text-xs font-semibold text-[#1a3d1a] inline-flex items-center gap-1">
              Manage Sections →
            </span>
          </div>

          <div
            onClick={() => setActiveTab('media')}
            className="p-5 rounded-2xl bg-white border border-gray-200 hover:border-[#1a3d1a] hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="text-sm font-bold text-gray-900 group-hover:text-[#1a3d1a] mb-1">
              Media & Image Library
            </div>
            <p className="text-xs text-gray-500 leading-relaxed mb-3">
              Upload photos, replace images, adjust alt text, or browse stored clinic assets.
            </p>
            <span className="text-xs font-semibold text-[#1a3d1a] inline-flex items-center gap-1">
              Upload Images →
            </span>
          </div>

          <div
            onClick={() => setActiveTab('global')}
            className="p-5 rounded-2xl bg-white border border-gray-200 hover:border-[#1a3d1a] hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="text-sm font-bold text-gray-900 group-hover:text-[#1a3d1a] mb-1">
              Contact & Social Info
            </div>
            <p className="text-xs text-gray-500 leading-relaxed mb-3">
              Update phone numbers, WhatsApp, clinic address, email, and social media handles.
            </p>
            <span className="text-xs font-semibold text-[#1a3d1a] inline-flex items-center gap-1">
              Update Contact →
            </span>
          </div>
        </div>
      </div>

      {/* How it works guidance card for non-technical owner */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#F7F3EA] border border-[#294936]/15 text-[#1a3d1a]">
        <div className="flex items-center gap-2 mb-2 font-bold text-sm sm:text-base">
          <HelpCircle className="w-5 h-5 text-[#6F8F72]" />
          <span>Non-Coder Guide: How the Safe Publish Workflow Works</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs sm:text-sm mt-3">
          <div className="bg-white/80 p-3.5 rounded-xl border border-[#294936]/10">
            <div className="font-semibold text-[#294936] mb-1">1. Make Edits Safely</div>
            <p className="text-gray-600">
              When you change text or images, click <strong>Save Draft</strong>. Nothing changes for public visitors yet.
            </p>
          </div>
          <div className="bg-white/80 p-3.5 rounded-xl border border-[#294936]/10">
            <div className="font-semibold text-[#294936] mb-1">2. Preview Live</div>
            <p className="text-gray-600">
              Click <strong>Preview</strong> at any time to see exactly how your draft will look on mobile, tablet, and desktop.
            </p>
          </div>
          <div className="bg-white/80 p-3.5 rounded-xl border border-[#294936]/10">
            <div className="font-semibold text-[#294936] mb-1">3. Publish with 1 Click</div>
            <p className="text-gray-600">
              When satisfied, click <strong>Publish to Live</strong>. Your changes instantly go live, and an automatic backup is saved!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
