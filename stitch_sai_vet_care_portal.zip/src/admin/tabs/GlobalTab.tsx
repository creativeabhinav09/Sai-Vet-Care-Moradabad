import React, { useState } from 'react';
import {
  Globe,
  Palette,
  Phone,
  Share2,
  Search,
  Upload,
  Check,
  Image as ImageIcon,
} from 'lucide-react';
import { GlobalSettings, MediaItem } from '../../cms/types';
import { MediaPickerModal } from '../components/MediaPickerModal';

interface GlobalTabProps {
  settings: GlobalSettings;
  mediaList: MediaItem[];
  onChange: (updated: GlobalSettings) => void;
  onUploadMedia: (item: MediaItem) => void;
}

export const GlobalTab: React.FC<GlobalTabProps> = ({
  settings,
  mediaList,
  onChange,
  onUploadMedia,
}) => {
  const [activeMediaTarget, setActiveMediaTarget] = useState<'logo' | 'favicon' | 'ogImage' | null>(null);

  const updateField = (field: keyof GlobalSettings, value: any) => {
    onChange({
      ...settings,
      [field]: value,
    });
  };

  const updateSocial = (network: keyof GlobalSettings['socialLinks'], value: string) => {
    onChange({
      ...settings,
      socialLinks: {
        ...settings.socialLinks,
        [network]: value,
      },
    });
  };

  const updateGlobalSeo = (field: keyof GlobalSettings['globalSeo'], value: string) => {
    onChange({
      ...settings,
      globalSeo: {
        ...settings.globalSeo,
        [field]: value,
      },
    });
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in max-w-4xl">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-gray-900">
          Global Website & Branding Settings
        </h1>
        <p className="text-xs sm:text-sm text-gray-500 mt-1">
          Configure site-wide identity, brand styling, contact hotlines, social channels, and global SEO.
        </p>
      </div>

      {/* Basic Identity */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-900 pb-2 border-b border-gray-100">
          <Globe className="w-4 h-4 text-[#1a3d1a]" />
          <span>Website Identity & Logos</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Website Name
            </label>
            <input
              type="text"
              value={settings.siteName || ''}
              onChange={(e) => updateField('siteName', e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:ring-1 focus:ring-[#1a3d1a] focus:outline-hidden"
              placeholder="e.g. Sai Vet Care Clinic — SVCC"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Brand Tagline
            </label>
            <input
              type="text"
              value={settings.tagline || ''}
              onChange={(e) => updateField('tagline', e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:ring-1 focus:ring-[#1a3d1a] focus:outline-hidden"
              placeholder="e.g. Compassionate Veterinary Seva & Pet Care"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          {/* Logo */}
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Website Logo URL
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={settings.logoUrl || ''}
                onChange={(e) => updateField('logoUrl', e.target.value)}
                className="flex-1 px-3 py-2 text-xs border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
                placeholder="/favicon.ico or image URL"
              />
              <button
                type="button"
                onClick={() => setActiveMediaTarget('logo')}
                className="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-medium rounded-xl flex items-center gap-1 transition-colors"
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>Pick</span>
              </button>
            </div>
            {settings.logoUrl && (
              <div className="mt-2 p-2 bg-gray-50 rounded-lg inline-block border border-gray-200">
                <img src={settings.logoUrl} alt="Logo Preview" className="h-8 max-w-[120px] object-contain" />
              </div>
            )}
          </div>

          {/* Favicon */}
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Browser Favicon URL
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={settings.faviconUrl || ''}
                onChange={(e) => updateField('faviconUrl', e.target.value)}
                className="flex-1 px-3 py-2 text-xs border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
                placeholder="/favicon.ico or icon URL"
              />
              <button
                type="button"
                onClick={() => setActiveMediaTarget('favicon')}
                className="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-medium rounded-xl flex items-center gap-1 transition-colors"
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>Pick</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Colors & Visual Themes */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-900 pb-2 border-b border-gray-100">
          <Palette className="w-4 h-4 text-[#E86A10]" />
          <span>Brand Palette & Colors</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Primary Brand Color (Forest Green)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={settings.primaryColor || '#1a3d1a'}
                onChange={(e) => updateField('primaryColor', e.target.value)}
                className="w-10 h-10 rounded-lg cursor-pointer border border-gray-300 p-0.5"
              />
              <input
                type="text"
                value={settings.primaryColor || '#1a3d1a'}
                onChange={(e) => updateField('primaryColor', e.target.value)}
                className="flex-1 px-3 py-2 text-xs font-mono border border-gray-300 rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Secondary Accent Color (Terracotta Orange)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={settings.secondaryColor || '#E86A10'}
                onChange={(e) => updateField('secondaryColor', e.target.value)}
                className="w-10 h-10 rounded-lg cursor-pointer border border-gray-300 p-0.5"
              />
              <input
                type="text"
                value={settings.secondaryColor || '#E86A10'}
                onChange={(e) => updateField('secondaryColor', e.target.value)}
                className="flex-1 px-3 py-2 text-xs font-mono border border-gray-300 rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Tertiary Soft Accent (Sage Green)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={settings.accentColor || '#6F8F72'}
                onChange={(e) => updateField('accentColor', e.target.value)}
                className="w-10 h-10 rounded-lg cursor-pointer border border-gray-300 p-0.5"
              />
              <input
                type="text"
                value={settings.accentColor || '#6F8F72'}
                onChange={(e) => updateField('accentColor', e.target.value)}
                className="flex-1 px-3 py-2 text-xs font-mono border border-gray-300 rounded-xl"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Contact & Emergency Details */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-900 pb-2 border-b border-gray-100">
          <Phone className="w-4 h-4 text-emerald-600" />
          <span>Contact Information & Helplines</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              General Contact Phone
            </label>
            <input
              type="text"
              value={settings.contactPhone || ''}
              onChange={(e) => updateField('contactPhone', e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
              placeholder="+91 94122 45678"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              24/7 Emergency Animal Distress Hotline
            </label>
            <input
              type="text"
              value={settings.emergencyPhone || ''}
              onChange={(e) => updateField('emergencyPhone', e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden text-red-600 font-medium"
              placeholder="+91 94122 45678"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Official Email Address
            </label>
            <input
              type="email"
              value={settings.contactEmail || ''}
              onChange={(e) => updateField('contactEmail', e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
              placeholder="seva@saivetcare.org"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Physical Clinic / Trust Address
            </label>
            <input
              type="text"
              value={settings.address || ''}
              onChange={(e) => updateField('address', e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
              placeholder="Temple Premises, Delhi Road, Moradabad"
            />
          </div>
        </div>
      </div>

      {/* Social Media Links */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-900 pb-2 border-b border-gray-100">
          <Share2 className="w-4 h-4 text-blue-600" />
          <span>Social Media Channels</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              WhatsApp Chat Link / Number
            </label>
            <input
              type="text"
              value={settings.socialLinks?.whatsapp || ''}
              onChange={(e) => updateSocial('whatsapp', e.target.value)}
              className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
              placeholder="https://wa.me/919412245678"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Instagram Profile URL
            </label>
            <input
              type="text"
              value={settings.socialLinks?.instagram || ''}
              onChange={(e) => updateSocial('instagram', e.target.value)}
              className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
              placeholder="https://instagram.com/saivetcare"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              YouTube Channel URL
            </label>
            <input
              type="text"
              value={settings.socialLinks?.youtube || ''}
              onChange={(e) => updateSocial('youtube', e.target.value)}
              className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
              placeholder="https://youtube.com/@saivetcare"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Facebook Page URL
            </label>
            <input
              type="text"
              value={settings.socialLinks?.facebook || ''}
              onChange={(e) => updateSocial('facebook', e.target.value)}
              className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
              placeholder="https://facebook.com/saivetcare"
            />
          </div>
        </div>
      </div>

      {/* Global SEO Settings */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-900 pb-2 border-b border-gray-100">
          <Search className="w-4 h-4 text-purple-600" />
          <span>Global Search Engine Optimization (SEO)</span>
        </div>

        <div>
          <label className="block text-xs font-semibold text-gray-700 mb-1">
            Default Meta Title (Browser & Google)
          </label>
          <input
            type="text"
            value={settings.globalSeo?.metaTitle || ''}
            onChange={(e) => updateGlobalSeo('metaTitle', e.target.value)}
            className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-gray-700 mb-1">
            Default Meta Description
          </label>
          <textarea
            rows={2}
            value={settings.globalSeo?.metaDescription || ''}
            onChange={(e) => updateGlobalSeo('metaDescription', e.target.value)}
            className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden leading-relaxed"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Open Graph Social Share Image URL
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={settings.globalSeo?.ogImage || ''}
                onChange={(e) => updateGlobalSeo('ogImage', e.target.value)}
                className="flex-1 px-3 py-2 text-xs border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
              />
              <button
                type="button"
                onClick={() => setActiveMediaTarget('ogImage')}
                className="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-medium rounded-xl flex items-center gap-1 transition-colors"
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>Pick</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Search Robots Indexing
            </label>
            <select
              value={settings.globalSeo?.robots || 'index, follow'}
              onChange={(e) => updateGlobalSeo('robots', e.target.value as any)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden bg-white"
            >
              <option value="index, follow">Index, Follow (Recommended for Google Search)</option>
              <option value="noindex, nofollow">Noindex, Nofollow (Hide from Search Engines)</option>
              <option value="noindex, follow">Noindex, Follow</option>
            </select>
          </div>
        </div>
      </div>

      {/* Media Picker Modal */}
      <MediaPickerModal
        isOpen={Boolean(activeMediaTarget)}
        onClose={() => setActiveMediaTarget(null)}
        mediaList={mediaList}
        onUpload={onUploadMedia}
        onSelect={(url) => {
          if (activeMediaTarget === 'logo') updateField('logoUrl', url);
          else if (activeMediaTarget === 'favicon') updateField('faviconUrl', url);
          else if (activeMediaTarget === 'ogImage') updateGlobalSeo('ogImage', url);
        }}
      />
    </div>
  );
};
