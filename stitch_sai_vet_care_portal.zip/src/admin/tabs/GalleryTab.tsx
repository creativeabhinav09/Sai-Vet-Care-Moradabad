import React, { useState } from 'react';
import {
  Image as ImageIcon,
  Plus,
  Edit,
  Trash2,
  Check,
  X,
  MapPin,
  Calendar,
} from 'lucide-react';
import { GalleryItem, MediaItem } from '../../cms/types';
import { MediaPickerModal } from '../components/MediaPickerModal';

interface GalleryTabProps {
  gallery: GalleryItem[];
  mediaList: MediaItem[];
  onChange: (updatedGallery: GalleryItem[]) => void;
  onUploadMedia: (item: MediaItem) => void;
}

export const GalleryTab: React.FC<GalleryTabProps> = ({
  gallery,
  mediaList,
  onChange,
  onUploadMedia,
}) => {
  const [editingItem, setEditingItem] = useState<any | null>(null);
  const [isMediaPickerOpen, setIsMediaPickerOpen] = useState(false);

  const handleAddNew = () => {
    setEditingItem({
      id: `gal-${Date.now()}`,
      title: 'New Clinic Photo',
      category: 'Clinical OPD',
      caption: 'Detailed caption explaining the medical or rescue moment.',
      date: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      location: 'Moradabad Main Hospital',
      imageUrl: 'https://polo-pecan-73837341.figma.site/_assets/v11/96745c4e72ad5c5208e53a885df797fd82cd854a.png',
    });
  };

  const handleSave = () => {
    if (!editingItem) return;
    const exists = gallery.some((g) => g.id === editingItem.id);
    let updated;
    if (exists) {
      updated = gallery.map((g) => (g.id === editingItem.id ? editingItem : g));
    } else {
      updated = [editingItem, ...gallery];
    }
    onChange(updated);
    setEditingItem(null);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this gallery item?')) {
      onChange(gallery.filter((g) => g.id !== id));
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in max-w-5xl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900">
            Documentary Photo Gallery Manager
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 mt-1">
            Manage photographic records of daily veterinary treatments, surgery, and field rescues.
          </p>
        </div>

        <button
          type="button"
          onClick={handleAddNew}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#1a3d1a] hover:bg-[#285e28] text-white rounded-xl text-xs sm:text-sm font-semibold transition-colors shadow-2xs cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Photo</span>
        </button>
      </div>

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {gallery.map((item: any) => (
          <div
            key={item.id}
            className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-2xs hover:border-[#1a3d1a] hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div className="aspect-4/3 bg-gray-100 relative overflow-hidden">
              <img
                src={item.imageUrl || 'https://polo-pecan-73837341.figma.site/_assets/v11/96745c4e72ad5c5208e53a885df797fd82cd854a.png'}
                alt={item.title}
                className="w-full h-full object-cover"
              />
              <span className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-black/60 text-white backdrop-blur-xs">
                {item.category}
              </span>
            </div>

            <div className="p-4 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-gray-900 text-sm leading-snug mb-1">
                  {item.title}
                </h3>
                <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed mb-3">
                  {item.caption}
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between text-[11px] text-gray-400 pb-3 border-b border-gray-100">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" /> {item.location}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" /> {item.date}
                  </span>
                </div>

                <div className="flex items-center justify-end gap-1.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingItem({ ...item })}
                    className="p-1.5 text-xs text-[#1a3d1a] hover:bg-gray-100 rounded-lg flex items-center gap-1 font-semibold"
                  >
                    <Edit className="w-3.5 h-3.5" /> Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(item.id)}
                    className="p-1.5 text-xs text-red-500 hover:bg-red-50 rounded-lg"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Photo Modal */}
      {editingItem && (
        <div className="fixed inset-0 z-[10000] bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-gray-200 overflow-hidden animate-scale-in">
            <div className="flex items-center justify-between p-4 sm:p-5 border-b border-gray-200 bg-gray-50">
              <h3 className="font-bold text-gray-900 text-base">Photo Information</h3>
              <button
                onClick={() => setEditingItem(null)}
                className="p-1 text-gray-400 hover:text-gray-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Photo Title
                </label>
                <input
                  type="text"
                  value={editingItem.title || ''}
                  onChange={(e) => setEditingItem({ ...editingItem, title: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs sm:text-sm border border-gray-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Category Tag
                  </label>
                  <input
                    type="text"
                    value={editingItem.category || ''}
                    onChange={(e) => setEditingItem({ ...editingItem, category: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Date Recorded
                  </label>
                  <input
                    type="text"
                    value={editingItem.date || ''}
                    onChange={(e) => setEditingItem({ ...editingItem, date: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Location / Centre
                </label>
                <input
                  type="text"
                  value={editingItem.location || ''}
                  onChange={(e) => setEditingItem({ ...editingItem, location: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Caption Description
                </label>
                <textarea
                  rows={2}
                  value={editingItem.caption || ''}
                  onChange={(e) => setEditingItem({ ...editingItem, caption: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Photo URL
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={editingItem.imageUrl || ''}
                    onChange={(e) => setEditingItem({ ...editingItem, imageUrl: e.target.value })}
                    className="flex-1 px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={() => setIsMediaPickerOpen(true)}
                    className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-xs font-semibold rounded-lg flex items-center gap-1"
                  >
                    <ImageIcon className="w-3.5 h-3.5" /> Pick
                  </button>
                </div>
              </div>
            </div>

            <div className="p-4 bg-gray-50 border-t border-gray-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingItem(null)}
                className="px-3 py-1.5 text-xs font-semibold text-gray-700 hover:bg-gray-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-4 py-1.5 bg-[#1a3d1a] hover:bg-[#285e28] text-white text-xs font-semibold rounded-lg shadow-xs flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" /> Save Photo
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Media Picker */}
      <MediaPickerModal
        isOpen={isMediaPickerOpen}
        onClose={() => setIsMediaPickerOpen(false)}
        mediaList={mediaList}
        onUpload={onUploadMedia}
        onSelect={(url) => {
          if (editingItem) setEditingItem({ ...editingItem, imageUrl: url });
        }}
      />
    </div>
  );
};
