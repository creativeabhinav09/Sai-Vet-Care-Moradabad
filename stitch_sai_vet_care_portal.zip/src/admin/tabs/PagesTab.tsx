import React, { useState } from 'react';
import {
  FileText,
  Layers,
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
  Edit,
  Trash2,
  Copy,
  Plus,
  Search,
  Check,
  X,
  Image as ImageIcon,
  ExternalLink,
  Sparkles,
} from 'lucide-react';
import { PageContent, PageSection, MediaItem } from '../../cms/types';
import { RichTextEditor } from '../components/RichTextEditor';
import { MediaPickerModal } from '../components/MediaPickerModal';

interface PagesTabProps {
  pages: Record<string, PageContent>;
  mediaList: MediaItem[];
  onChange: (updatedPages: Record<string, PageContent>) => void;
  onUploadMedia: (item: MediaItem) => void;
}

export const PagesTab: React.FC<PagesTabProps> = ({
  pages,
  mediaList,
  onChange,
  onUploadMedia,
}) => {
  const pageKeys = Object.keys(pages);
  const [selectedPageKey, setSelectedPageKey] = useState<string>(pageKeys[0] || 'home');
  const [editingSection, setEditingSection] = useState<PageSection | null>(null);
  const [isEditingSeo, setIsEditingSeo] = useState<boolean>(false);
  const [mediaPickerTarget, setMediaPickerTarget] = useState<'section-image' | 'seo-image' | null>(null);

  const currentPage = pages[selectedPageKey] || {
    id: selectedPageKey,
    title: selectedPageKey,
    slug: `/${selectedPageKey}`,
    seo: {
      metaTitle: '',
      metaDescription: '',
      ogTitle: '',
      ogDescription: '',
      ogImage: '',
      robots: 'index, follow',
    },
    sections: [],
  };

  const updateCurrentPage = (updated: PageContent) => {
    onChange({
      ...pages,
      [selectedPageKey]: updated,
    });
  };

  // Section Ordering & Visibility
  const handleToggleSectionVisibility = (sectionId: string) => {
    const updatedSections = currentPage.sections.map((s) =>
      s.id === sectionId ? { ...s, enabled: !s.enabled } : s
    );
    updateCurrentPage({ ...currentPage, sections: updatedSections });
  };

  const handleMoveSection = (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= currentPage.sections.length) return;
    const updatedSections = [...currentPage.sections];
    const [moved] = updatedSections.splice(index, 1);
    updatedSections.splice(newIndex, 0, moved);
    updateCurrentPage({ ...currentPage, sections: updatedSections });
  };

  const handleDuplicateSection = (section: PageSection) => {
    const duplicated: PageSection = {
      ...JSON.parse(JSON.stringify(section)),
      id: `${section.type}-${Date.now()}`,
      name: `${section.name} (Copy)`,
    };
    const updatedSections = [...currentPage.sections, duplicated];
    updateCurrentPage({ ...currentPage, sections: updatedSections });
  };

  const handleDeleteSection = (sectionId: string) => {
    if (confirm('Are you sure you want to delete this section from the page?')) {
      const updatedSections = currentPage.sections.filter((s) => s.id !== sectionId);
      updateCurrentPage({ ...currentPage, sections: updatedSections });
    }
  };

  const handleAddCustomSection = () => {
    const newSection: PageSection = {
      id: `custom-${Date.now()}`,
      type: 'custom-rich-text',
      name: 'New Custom Content Section',
      enabled: true,
      eyebrow: 'Special Feature',
      title: 'New Section Headline',
      subtitle: 'Optional subtitle description',
      description: 'Enter your section description here...',
      content: '<p>You can write custom rich-text paragraphs, add lists, links and formatted content here.</p>',
    };
    updateCurrentPage({ ...currentPage, sections: [...currentPage.sections, newSection] });
    setEditingSection(newSection);
  };

  const handleSaveEditingSection = () => {
    if (!editingSection) return;
    const updatedSections = currentPage.sections.map((s) =>
      s.id === editingSection.id ? editingSection : s
    );
    updateCurrentPage({ ...currentPage, sections: updatedSections });
    setEditingSection(null);
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in max-w-5xl">
      {/* Top Header & Page Selector */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900">
            Page & Section Content Builder
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 mt-1">
            Choose any page to edit headings, paragraphs, images, buttons, and reorder sections.
          </p>
        </div>

        {/* Page Switcher */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-gray-600">Select Page:</span>
          <select
            value={selectedPageKey}
            onChange={(e) => {
              setSelectedPageKey(e.target.value);
              setEditingSection(null);
              setIsEditingSeo(false);
            }}
            className="px-3 py-2 text-xs sm:text-sm font-semibold text-[#1a3d1a] bg-white border border-[#1a3d1a]/30 rounded-xl focus:outline-hidden shadow-2xs cursor-pointer"
          >
            {pageKeys.map((key) => (
              <option key={key} value={key}>
                {pages[key]?.title || key.toUpperCase()} ({pages[key]?.slug})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Page Overview Card */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-gray-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-base font-bold text-gray-900">{currentPage.title}</span>
            <span className="text-xs font-mono bg-gray-100 text-gray-600 px-2 py-0.5 rounded-md">
              {currentPage.slug}
            </span>
          </div>
          <p className="text-xs text-gray-500 mt-0.5">
            {currentPage.sections?.length || 0} active sections on this page
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsEditingSeo(!isEditingSeo)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl border transition-colors flex items-center gap-1.5 cursor-pointer ${
              isEditingSeo
                ? 'bg-purple-50 text-purple-700 border-purple-200'
                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span>Page SEO Settings</span>
          </button>

          <button
            type="button"
            onClick={handleAddCustomSection}
            className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[#1a3d1a] hover:bg-[#285e28] text-white shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Custom Section</span>
          </button>
        </div>
      </div>

      {/* SEO Settings Drawer */}
      {isEditingSeo && (
        <div className="p-5 bg-purple-50/60 border border-purple-200 rounded-2xl space-y-4 animate-scale-in">
          <div className="flex items-center justify-between pb-2 border-b border-purple-100">
            <div className="flex items-center gap-2 text-sm font-bold text-purple-900">
              <Search className="w-4 h-4 text-purple-700" />
              <span>SEO & Social Sharing for: {currentPage.title}</span>
            </div>
            <button
              onClick={() => setIsEditingSeo(false)}
              className="text-gray-400 hover:text-gray-700 p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Meta Page Title (Search Result Title)
              </label>
              <input
                type="text"
                value={currentPage.seo?.metaTitle || ''}
                onChange={(e) =>
                  updateCurrentPage({
                    ...currentPage,
                    seo: { ...currentPage.seo, metaTitle: e.target.value },
                  })
                }
                className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg bg-white"
                placeholder="e.g. About Us — Sai Vet Care Clinic"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                URL Slug
              </label>
              <input
                type="text"
                value={currentPage.slug || ''}
                onChange={(e) => updateCurrentPage({ ...currentPage, slug: e.target.value })}
                className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg bg-white font-mono"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Meta Description (Search Snippet)
              </label>
              <textarea
                rows={2}
                value={currentPage.seo?.metaDescription || ''}
                onChange={(e) =>
                  updateCurrentPage({
                    ...currentPage,
                    seo: { ...currentPage.seo, metaDescription: e.target.value },
                  })
                }
                className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Social Share Image (OG Image)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={currentPage.seo?.ogImage || ''}
                  onChange={(e) =>
                    updateCurrentPage({
                      ...currentPage,
                      seo: { ...currentPage.seo, ogImage: e.target.value },
                    })
                  }
                  className="flex-1 px-3 py-1.5 text-xs border border-gray-300 rounded-lg bg-white"
                />
                <button
                  type="button"
                  onClick={() => setMediaPickerTarget('seo-image')}
                  className="px-2.5 py-1.5 bg-gray-100 hover:bg-gray-200 text-xs rounded-lg flex items-center gap-1"
                >
                  <ImageIcon className="w-3.5 h-3.5" /> Pick
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Search Engine Indexing
              </label>
              <select
                value={currentPage.seo?.robots || 'index, follow'}
                onChange={(e) =>
                  updateCurrentPage({
                    ...currentPage,
                    seo: { ...currentPage.seo, robots: e.target.value as any },
                  })
                }
                className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg bg-white"
              >
                <option value="index, follow">Index, Follow</option>
                <option value="noindex, nofollow">Noindex, Nofollow</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* Sections List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs font-semibold text-gray-500 uppercase tracking-wider px-1">
          <span>Page Sections (Visual Layout Order)</span>
          <span>{currentPage.sections?.length || 0} Sections Total</span>
        </div>

        {currentPage.sections?.map((section, index) => {
          const isEnabled = section.enabled !== false;

          return (
            <div
              key={section.id}
              className={`rounded-2xl border transition-all ${
                isEnabled
                  ? 'bg-white border-gray-200 shadow-2xs hover:border-[#1a3d1a]/50'
                  : 'bg-gray-100/70 border-dashed border-gray-300 opacity-60'
              }`}
            >
              <div className="p-3.5 sm:p-4 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-7 h-7 rounded-lg bg-gray-100 text-gray-700 flex items-center justify-center text-xs font-mono font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <div className="text-xs sm:text-sm font-bold text-gray-900 flex items-center gap-2">
                      <span>{section.name || section.title || section.type}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">
                        {section.type}
                      </span>
                    </div>
                    {section.title && (
                      <div className="text-xs text-gray-500 truncate max-w-md mt-0.5">
                        Headline: &ldquo;{section.title}&rdquo;
                      </div>
                    )}
                  </div>
                </div>

                {/* Section Action Controls */}
                <div className="flex items-center gap-1 sm:gap-1.5">
                  {/* Visibility Toggle */}
                  <button
                    type="button"
                    onClick={() => handleToggleSectionVisibility(section.id)}
                    className={`p-2 rounded-lg text-xs font-medium transition-colors ${
                      isEnabled
                        ? 'text-emerald-700 hover:bg-emerald-50'
                        : 'text-gray-400 hover:bg-gray-200'
                    }`}
                    title={isEnabled ? 'Section is Visible' : 'Section is Hidden'}
                  >
                    {isEnabled ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>

                  {/* Move Up/Down */}
                  <button
                    type="button"
                    onClick={() => handleMoveSection(index, 'up')}
                    disabled={index === 0}
                    className="p-1.5 hover:bg-gray-100 disabled:opacity-20 rounded text-gray-600 transition-colors"
                    title="Move Section Up"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleMoveSection(index, 'down')}
                    disabled={index === currentPage.sections.length - 1}
                    className="p-1.5 hover:bg-gray-100 disabled:opacity-20 rounded text-gray-600 transition-colors"
                    title="Move Section Down"
                  >
                    <ArrowDown className="w-4 h-4" />
                  </button>

                  {/* Duplicate */}
                  <button
                    type="button"
                    onClick={() => handleDuplicateSection(section)}
                    className="p-1.5 hover:bg-gray-100 text-gray-600 rounded transition-colors"
                    title="Duplicate Section"
                  >
                    <Copy className="w-4 h-4" />
                  </button>

                  {/* Edit Content */}
                  <button
                    type="button"
                    onClick={() => setEditingSection(JSON.parse(JSON.stringify(section)))}
                    className="px-3 py-1.5 bg-[#1a3d1a] hover:bg-[#285e28] text-white text-xs font-semibold rounded-lg flex items-center gap-1 transition-colors shadow-2xs ml-1"
                  >
                    <Edit className="w-3.5 h-3.5" />
                    <span>Edit Content</span>
                  </button>

                  {/* Delete */}
                  <button
                    type="button"
                    onClick={() => handleDeleteSection(section.id)}
                    className="p-1.5 text-red-500 hover:bg-red-50 rounded transition-colors ml-1"
                    title="Delete Section"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Section Content Edit Modal / Drawer */}
      {editingSection && (
        <div className="fixed inset-0 z-[10000] bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-gray-200 overflow-hidden animate-scale-in">
            {/* Header */}
            <div className="flex items-center justify-between p-4 sm:p-5 border-b border-gray-200 bg-gray-50">
              <div>
                <h3 className="font-bold text-gray-900 text-base">
                  Editing Section: {editingSection.name || editingSection.title}
                </h3>
                <p className="text-xs text-gray-500">
                  Update text, headings, images, and action buttons without touching code
                </p>
              </div>
              <button
                onClick={() => setEditingSection(null)}
                className="p-1.5 text-gray-400 hover:text-gray-700 rounded-lg hover:bg-gray-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form Fields */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Section Admin Name
                </label>
                <input
                  type="text"
                  value={editingSection.name || ''}
                  onChange={(e) => setEditingSection({ ...editingSection, name: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Eyebrow / Small Category Label
                  </label>
                  <input
                    type="text"
                    value={editingSection.eyebrow || ''}
                    onChange={(e) => setEditingSection({ ...editingSection, eyebrow: e.target.value })}
                    className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a]"
                    placeholder="e.g. Humanitarian Relief"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Subtitle
                  </label>
                  <input
                    type="text"
                    value={editingSection.subtitle || ''}
                    onChange={(e) => setEditingSection({ ...editingSection, subtitle: e.target.value })}
                    className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a]"
                    placeholder="e.g. Care for Every Life"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Main Section Headline / Title
                </label>
                <input
                  type="text"
                  value={editingSection.title || ''}
                  onChange={(e) => setEditingSection({ ...editingSection, title: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] font-medium"
                  placeholder="e.g. A Journey of Compassionate Veterinary Seva"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Lead Description Paragraph
                </label>
                <textarea
                  rows={3}
                  value={editingSection.description || ''}
                  onChange={(e) => setEditingSection({ ...editingSection, description: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] leading-relaxed"
                  placeholder="Enter introductory paragraph text..."
                />
              </div>

              {/* Rich-Text Content (Optional) */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Extended Body Content (Rich Text Editor)
                </label>
                <RichTextEditor
                  value={editingSection.content || ''}
                  onChange={(content) => setEditingSection({ ...editingSection, content })}
                  placeholder="Add formatted paragraphs, lists, bold text, or quotes here..."
                />
              </div>

              {/* Section Image */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Section Image / Artwork
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={editingSection.imageUrl || ''}
                    onChange={(e) => setEditingSection({ ...editingSection, imageUrl: e.target.value })}
                    className="flex-1 px-3 py-2 text-xs border border-gray-300 rounded-xl"
                    placeholder="Select or enter image URL..."
                  />
                  <button
                    type="button"
                    onClick={() => setMediaPickerTarget('section-image')}
                    className="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-xs font-semibold rounded-xl flex items-center gap-1"
                  >
                    <ImageIcon className="w-3.5 h-3.5" /> Pick Image
                  </button>
                </div>
                {editingSection.imageUrl && (
                  <div className="mt-2 p-2 bg-gray-50 rounded-lg inline-block border border-gray-200">
                    <img
                      src={editingSection.imageUrl}
                      alt="Preview"
                      className="h-20 max-w-[200px] object-cover rounded-md"
                    />
                  </div>
                )}
              </div>

              {/* CTA Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-gray-100">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Primary Button Text
                  </label>
                  <input
                    type="text"
                    value={editingSection.ctaText || ''}
                    onChange={(e) => setEditingSection({ ...editingSection, ctaText: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
                    placeholder="e.g. Explore Seva"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Primary Button Link
                  </label>
                  <input
                    type="text"
                    value={editingSection.ctaLink || ''}
                    onChange={(e) => setEditingSection({ ...editingSection, ctaLink: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg font-mono"
                    placeholder="/seva or https://..."
                  />
                </div>
              </div>
            </div>

            {/* Footer Actions */}
            <div className="p-4 bg-gray-50 border-t border-gray-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingSection(null)}
                className="px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-200 rounded-xl transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveEditingSection}
                className="px-5 py-2 bg-[#1a3d1a] hover:bg-[#285e28] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Save Section Changes</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Media Picker Modal */}
      <MediaPickerModal
        isOpen={Boolean(mediaPickerTarget)}
        onClose={() => setMediaPickerTarget(null)}
        mediaList={mediaList}
        onUpload={onUploadMedia}
        onSelect={(url) => {
          if (mediaPickerTarget === 'section-image' && editingSection) {
            setEditingSection({ ...editingSection, imageUrl: url });
          } else if (mediaPickerTarget === 'seo-image') {
            updateCurrentPage({
              ...currentPage,
              seo: { ...currentPage.seo, ogImage: url },
            });
          }
        }}
      />
    </div>
  );
};
