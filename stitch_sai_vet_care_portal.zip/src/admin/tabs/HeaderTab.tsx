import React, { useState } from 'react';
import {
  Menu,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  Bell,
  PhoneCall,
  Link as LinkIcon,
} from 'lucide-react';
import { HeaderSettings, NavItem } from '../../cms/types';

interface HeaderTabProps {
  header: HeaderSettings;
  onChange: (updated: HeaderSettings) => void;
}

export const HeaderTab: React.FC<HeaderTabProps> = ({ header, onChange }) => {
  const [expandedItemId, setExpandedItemId] = useState<string | null>(null);

  const updateHeader = (field: keyof HeaderSettings, value: any) => {
    onChange({
      ...header,
      [field]: value,
    });
  };

  const handleAddNavItem = () => {
    const newItem: NavItem = {
      id: `nav-${Date.now()}`,
      label: 'New Link',
      path: '/new-page',
      children: [],
    };
    updateHeader('navItems', [...header.navItems, newItem]);
    setExpandedItemId(newItem.id);
  };

  const handleUpdateNavItem = (index: number, updatedItem: NavItem) => {
    const newItems = [...header.navItems];
    newItems[index] = updatedItem;
    updateHeader('navItems', newItems);
  };

  const handleDeleteNavItem = (index: number) => {
    if (confirm('Are you sure you want to remove this navigation item?')) {
      const newItems = header.navItems.filter((_, i) => i !== index);
      updateHeader('navItems', newItems);
    }
  };

  const handleMoveNavItem = (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= header.navItems.length) return;
    const newItems = [...header.navItems];
    const [moved] = newItems.splice(index, 1);
    newItems.splice(newIndex, 0, moved);
    updateHeader('navItems', newItems);
  };

  const handleAddChildItem = (parentIndex: number) => {
    const parent = header.navItems[parentIndex];
    const newChild = {
      id: `child-${Date.now()}`,
      label: 'Submenu Item',
      path: parent.path || '/',
      description: 'Quick description',
    };
    const updatedParent: NavItem = {
      ...parent,
      children: [...(parent.children || []), newChild],
    };
    handleUpdateNavItem(parentIndex, updatedParent);
  };

  const handleDeleteChildItem = (parentIndex: number, childIndex: number) => {
    const parent = header.navItems[parentIndex];
    const updatedChildren = (parent.children || []).filter((_, i) => i !== childIndex);
    handleUpdateNavItem(parentIndex, { ...parent, children: updatedChildren });
  };

  const handleUpdateChildItem = (parentIndex: number, childIndex: number, field: string, val: string) => {
    const parent = header.navItems[parentIndex];
    const updatedChildren = [...(parent.children || [])];
    updatedChildren[childIndex] = { ...updatedChildren[childIndex], [field]: val };
    handleUpdateNavItem(parentIndex, { ...parent, children: updatedChildren });
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in max-w-4xl">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-gray-900">
          Header & Navigation Bar Manager
        </h1>
        <p className="text-xs sm:text-sm text-gray-500 mt-1">
          Customize the top information bar, emergency button, menu links, and dropdowns.
        </p>
      </div>

      {/* Top Announcement Bar */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-gray-100">
          <div className="flex items-center gap-2 text-sm font-bold text-gray-900">
            <Bell className="w-4 h-4 text-[#E86A10]" />
            <span>Top Announcement & Emergency Bar</span>
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={header.topBarEnabled}
              onChange={(e) => updateHeader('topBarEnabled', e.target.checked)}
              className="w-4 h-4 accent-[#1a3d1a] rounded cursor-pointer"
            />
            <span className="text-xs font-semibold text-gray-700">Enable Announcement Bar</span>
          </label>
        </div>

        {header.topBarEnabled && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Announcement Text
              </label>
              <input
                type="text"
                value={header.announcementText || ''}
                onChange={(e) => updateHeader('announcementText', e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
                placeholder="e.g. 24/7 Mobile Veterinary Rescue Hotline & Emergency Ambulance Dispatch"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Announcement Link (Optional)
              </label>
              <input
                type="text"
                value={header.announcementLink || ''}
                onChange={(e) => updateHeader('announcementLink', e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
                placeholder="/contact"
              />
            </div>
          </div>
        )}
      </div>

      {/* Emergency Hotline Button */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-gray-100">
          <div className="flex items-center gap-2 text-sm font-bold text-gray-900">
            <PhoneCall className="w-4 h-4 text-emerald-600" />
            <span>Emergency Action Button (Right Header)</span>
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={header.showEmergencyButton}
              onChange={(e) => updateHeader('showEmergencyButton', e.target.checked)}
              className="w-4 h-4 accent-[#1a3d1a] rounded cursor-pointer"
            />
            <span className="text-xs font-semibold text-gray-700">Show Button</span>
          </label>
        </div>

        {header.showEmergencyButton && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Button Label
              </label>
              <input
                type="text"
                value={header.emergencyButtonText || ''}
                onChange={(e) => updateHeader('emergencyButtonText', e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
                placeholder="24/7 Emergency Dispatch"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Emergency Dialing Number
              </label>
              <input
                type="text"
                value={header.emergencyButtonPhone || ''}
                onChange={(e) => updateHeader('emergencyButtonPhone', e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:outline-hidden"
                placeholder="+91 94122 45678"
              />
            </div>
          </div>
        )}
      </div>

      {/* Navigation Menu Builder */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-gray-100">
          <div className="flex items-center gap-2 text-sm font-bold text-gray-900">
            <Menu className="w-4 h-4 text-[#1a3d1a]" />
            <span>Website Navigation Menu Items</span>
          </div>
          <button
            type="button"
            onClick={handleAddNavItem}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#1a3d1a] hover:bg-[#285e28] text-white rounded-lg text-xs font-semibold transition-colors shadow-2xs cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Menu Item</span>
          </button>
        </div>

        {/* List of Menu Items */}
        <div className="space-y-3">
          {header.navItems.map((item, index) => {
            const isExpanded = expandedItemId === item.id;
            const hasChildren = (item.children?.length || 0) > 0;

            return (
              <div
                key={item.id}
                className="rounded-xl border border-gray-200 bg-gray-50/70 overflow-hidden transition-all"
              >
                {/* Main Row */}
                <div className="p-3 sm:p-4 flex flex-wrap items-center justify-between gap-3 bg-white">
                  <div className="flex items-center gap-2.5">
                    <button
                      type="button"
                      onClick={() => setExpandedItemId(isExpanded ? null : item.id)}
                      className="p-1 hover:bg-gray-100 rounded text-gray-500"
                    >
                      {isExpanded ? (
                        <ChevronDown className="w-4 h-4" />
                      ) : (
                        <ChevronRight className="w-4 h-4" />
                      )}
                    </button>
                    <div>
                      <div className="text-xs sm:text-sm font-bold text-gray-900 flex items-center gap-2">
                        <span>{item.label}</span>
                        {hasChildren && (
                          <span className="px-2 py-0.5 bg-blue-50 text-blue-700 text-[10px] rounded-full font-semibold">
                            {item.children?.length} Dropdowns
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] font-mono text-gray-500">{item.path}</div>
                    </div>
                  </div>

                  {/* Move Up/Down + Delete Actions */}
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleMoveNavItem(index, 'up')}
                      disabled={index === 0}
                      className="p-1.5 hover:bg-gray-100 disabled:opacity-30 rounded text-gray-600 transition-colors"
                      title="Move Up"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleMoveNavItem(index, 'down')}
                      disabled={index === header.navItems.length - 1}
                      className="p-1.5 hover:bg-gray-100 disabled:opacity-30 rounded text-gray-600 transition-colors"
                      title="Move Down"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteNavItem(index)}
                      className="p-1.5 hover:bg-red-50 text-red-600 rounded transition-colors ml-1"
                      title="Delete Item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Edit Form Drawer */}
                {isExpanded && (
                  <div className="p-4 bg-gray-50 border-t border-gray-200 space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-semibold text-gray-700 mb-1">
                          Menu Label Text
                        </label>
                        <input
                          type="text"
                          value={item.label}
                          onChange={(e) =>
                            handleUpdateNavItem(index, { ...item, label: e.target.value })
                          }
                          className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg focus:border-[#1a3d1a] bg-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-gray-700 mb-1">
                          Destination URL / Path
                        </label>
                        <input
                          type="text"
                          value={item.path}
                          onChange={(e) =>
                            handleUpdateNavItem(index, { ...item, path: e.target.value })
                          }
                          className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg focus:border-[#1a3d1a] bg-white font-mono"
                          placeholder="/about or https://..."
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <label className="flex items-center gap-1.5 text-xs text-gray-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={Boolean(item.openInNewTab)}
                          onChange={(e) =>
                            handleUpdateNavItem(index, { ...item, openInNewTab: e.target.checked })
                          }
                          className="rounded text-[#1a3d1a]"
                        />
                        <span>Open in New Browser Tab</span>
                      </label>
                    </div>

                    {/* Submenu / Dropdown Items Manager */}
                    <div className="pt-3 border-t border-gray-200 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-gray-800">
                          Dropdown Submenu Links ({item.children?.length || 0})
                        </span>
                        <button
                          type="button"
                          onClick={() => handleAddChildItem(index)}
                          className="text-xs text-[#1a3d1a] hover:underline font-semibold flex items-center gap-1"
                        >
                          <Plus className="w-3 h-3" /> Add Dropdown Link
                        </button>
                      </div>

                      {(item.children || []).map((child, cIdx) => (
                        <div
                          key={child.id}
                          className="p-3 bg-white rounded-xl border border-gray-200 grid grid-cols-1 sm:grid-cols-12 gap-2 items-center"
                        >
                          <div className="sm:col-span-4">
                            <input
                              type="text"
                              value={child.label}
                              onChange={(e) =>
                                handleUpdateChildItem(index, cIdx, 'label', e.target.value)
                              }
                              placeholder="Title"
                              className="w-full px-2.5 py-1 text-xs border border-gray-300 rounded-lg"
                            />
                          </div>
                          <div className="sm:col-span-4">
                            <input
                              type="text"
                              value={child.path}
                              onChange={(e) =>
                                handleUpdateChildItem(index, cIdx, 'path', e.target.value)
                              }
                              placeholder="Link URL"
                              className="w-full px-2.5 py-1 text-xs border border-gray-300 rounded-lg font-mono"
                            />
                          </div>
                          <div className="sm:col-span-3">
                            <input
                              type="text"
                              value={child.description || ''}
                              onChange={(e) =>
                                handleUpdateChildItem(index, cIdx, 'description', e.target.value)
                              }
                              placeholder="Description"
                              className="w-full px-2.5 py-1 text-xs border border-gray-300 rounded-lg"
                            />
                          </div>
                          <div className="sm:col-span-1 text-right">
                            <button
                              type="button"
                              onClick={() => handleDeleteChildItem(index, cIdx)}
                              className="p-1 text-red-500 hover:bg-red-50 rounded"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
