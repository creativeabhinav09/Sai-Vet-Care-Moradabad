import React, { useState } from 'react';
import {
  Users,
  Plus,
  Edit,
  Trash2,
  Check,
  X,
  GraduationCap,
  Award,
  Stethoscope,
} from 'lucide-react';
import { TeamMember } from '../../cms/types';

interface TeamTabProps {
  team: TeamMember[];
  onChange: (updatedTeam: TeamMember[]) => void;
}

export const TeamTab: React.FC<TeamTabProps> = ({ team, onChange }) => {
  const [editingMember, setEditingMember] = useState<TeamMember | null>(null);

  const handleAddNew = () => {
    setEditingMember({
      id: `team-${Date.now()}`,
      name: 'Dr. New Veterinary Doctor',
      role: 'Veterinary Surgeon / Clinician',
      qualification: 'B.V.Sc. & A.H.',
      experience: '5+ Years Clinical Practice',
      specialization: 'Small Animal Surgery & Emergency Care',
      bio: 'Dedicated veterinary practitioner committing rigorous clinical knowledge to animal relief.',
    });
  };

  const handleSave = () => {
    if (!editingMember) return;
    const exists = team.some((t) => t.id === editingMember.id);
    let updated;
    if (exists) {
      updated = team.map((t) => (t.id === editingMember.id ? editingMember : t));
    } else {
      updated = [...team, editingMember];
    }
    onChange(updated);
    setEditingMember(null);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to remove this veterinary team member?')) {
      onChange(team.filter((t) => t.id !== id));
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in max-w-5xl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900">
            Veterinary Doctors & Seva Staff Manager
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 mt-1">
            Manage profiles, surgical specializations, qualifications, and bios for clinic doctors.
          </p>
        </div>

        <button
          type="button"
          onClick={handleAddNew}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#1a3d1a] hover:bg-[#285e28] text-white rounded-xl text-xs sm:text-sm font-semibold transition-colors shadow-2xs cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Doctor / Staff</span>
        </button>
      </div>

      {/* Team Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {team.map((member) => (
          <div
            key={member.id}
            className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-2xs hover:border-[#1a3d1a] hover:shadow-md transition-all flex flex-col justify-between p-5"
          >
            <div>
              <div className="w-12 h-12 rounded-full bg-[#1a3d1a] text-white flex items-center justify-center mb-3">
                <Stethoscope className="w-6 h-6" />
              </div>

              <h3 className="font-bold text-gray-900 text-base leading-snug">
                {member.name}
              </h3>
              <div className="text-xs font-semibold text-[#E86A10] mb-2">{member.role}</div>

              <div className="space-y-1.5 text-xs text-gray-600 mb-3 bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                <div className="flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5 text-[#6F8F72] shrink-0" />
                  <span>{member.qualification}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5 text-[#6F8F72] shrink-0" />
                  <span>{member.specialization}</span>
                </div>
              </div>

              <p className="text-xs text-gray-500 line-clamp-3 leading-relaxed">
                {member.bio}
              </p>
            </div>

            <div className="flex items-center justify-end gap-1.5 pt-4 mt-4 border-t border-gray-100">
              <button
                type="button"
                onClick={() => setEditingMember({ ...member })}
                className="p-1.5 text-xs text-[#1a3d1a] hover:bg-gray-100 rounded-lg flex items-center gap-1 font-semibold"
              >
                <Edit className="w-3.5 h-3.5" /> Edit
              </button>
              <button
                type="button"
                onClick={() => handleDelete(member.id)}
                className="p-1.5 text-xs text-red-500 hover:bg-red-50 rounded-lg"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Member Modal */}
      {editingMember && (
        <div className="fixed inset-0 z-[10000] bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-gray-200 overflow-hidden animate-scale-in">
            <div className="flex items-center justify-between p-4 sm:p-5 border-b border-gray-200 bg-gray-50">
              <h3 className="font-bold text-gray-900 text-base">Doctor Profile Information</h3>
              <button
                onClick={() => setEditingMember(null)}
                className="p-1 text-gray-400 hover:text-gray-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Full Name & Title
                </label>
                <input
                  type="text"
                  value={editingMember.name || ''}
                  onChange={(e) => setEditingMember({ ...editingMember, name: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs sm:text-sm border border-gray-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Role / Clinical Designation
                </label>
                <input
                  type="text"
                  value={editingMember.role || ''}
                  onChange={(e) => setEditingMember({ ...editingMember, role: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Qualifications
                  </label>
                  <input
                    type="text"
                    value={editingMember.qualification || ''}
                    onChange={(e) => setEditingMember({ ...editingMember, qualification: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Experience
                  </label>
                  <input
                    type="text"
                    value={editingMember.experience || ''}
                    onChange={(e) => setEditingMember({ ...editingMember, experience: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Specialization Discipline
                </label>
                <input
                  type="text"
                  value={editingMember.specialization || ''}
                  onChange={(e) => setEditingMember({ ...editingMember, specialization: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Biographical Overview
                </label>
                <textarea
                  rows={3}
                  value={editingMember.bio || ''}
                  onChange={(e) => setEditingMember({ ...editingMember, bio: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs border border-gray-300 rounded-lg"
                />
              </div>
            </div>

            <div className="p-4 bg-gray-50 border-t border-gray-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingMember(null)}
                className="px-3 py-1.5 text-xs font-semibold text-gray-700 hover:bg-gray-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-4 py-1.5 bg-[#1a3d1a] hover:bg-[#285e28] text-white text-xs font-semibold rounded-lg shadow-xs flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" /> Save Profile
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
