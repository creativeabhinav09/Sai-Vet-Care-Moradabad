import React, { useState } from 'react';
import {
  Upload,
  Image as ImageIcon,
  Search,
  Trash2,
  Edit,
  Copy,
  Check,
  ExternalLink,
  X,
  FileImage,
} from 'lucide-react';
import { MediaItem } from '../../cms/types';

interface MediaTabProps {
  mediaList: MediaItem[];
  onChange: (updatedMedia: MediaItem[]) => void;
  onUpload: (item: MediaItem) => void;
}

export const MediaTab: React.FC<MediaTabProps> = ({
  mediaList,
  onChange,
  onUpload,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [selectedItem, setSelectedItem] = useState<MediaItem | null>(null);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);

  const filteredMedia = mediaList.filter(
    (item) =>
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.filename.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.alt.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setUploadError('Please select a valid image file (PNG, JPG, WebP, SVG).');
      return;
    }

    setUploadError('');
    setIsUploading(true);

    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = reader.result as string;
        const token = localStorage.getItem('svcc_admin_token');

        const res = await fetch('/api/cms/media/upload', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            filename: file.name,
            base64Data,
            title: file.name.replace(/\.[^/.]+$/, ''),
            alt: file.name.replace(/\.[^/.]+$/, ''),
          }),
        });

        if (res.ok) {
          const json = await res.json();
          if (json.mediaItem) {
            onUpload(json.mediaItem);
          }
        } else {
          const errData = await res.json().catch(() => ({}));
          setUploadError(errData.error || 'Failed to upload image');
        }
        setIsUploading(false);
      };
      reader.readAsDataURL(file);
    } catch (err: any) {
      setUploadError('Upload failed: ' + err.message);
      setIsUploading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to permanently delete this media item?')) return;

    const token = localStorage.getItem('svcc_admin_token');
    try {
      await fetch(`/api/cms/media/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      onChange(mediaList.filter((m) => m.id !== id));
      if (selectedItem?.id === id) setSelectedItem(null);
    } catch (err) {
      console.error('Delete error:', err);
    }
  };

  const handleSaveMetadata = () => {
    if (!selectedItem) return;
    const updated = mediaList.map((m) => (m.id === selectedItem.id ? selectedItem : m));
    onChange(updated);
    setSelectedItem(null);
  };

  const handleCopyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedUrl(url);
    setTimeout(() => setCopiedUrl(null), 2000);
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return 'Unknown size';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in max-w-6xl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900">
            Image & Media Manager
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 mt-1">
            Upload clinic photos, replace images, adjust alt text and captions without coding.
          </p>
        </div>

        {/* Upload Button */}
        <label className="cursor-pointer inline-flex items-center gap-2 px-4 py-2 bg-[#1a3d1a] hover:bg-[#285e28] text-white rounded-xl text-xs sm:text-sm font-semibold transition-colors shadow-2xs">
          <Upload className="w-4 h-4" />
          <span>{isUploading ? 'Uploading Image...' : 'Upload New Photo'}</span>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            disabled={isUploading}
            className="hidden"
          />
        </label>
      </div>

      {uploadError && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl">
          {uploadError}
        </div>
      )}

      {/* Search & Stats Bar */}
      <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search media by title or filename..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs sm:text-sm border border-gray-300 rounded-lg focus:border-[#1a3d1a] focus:outline-hidden"
          />
        </div>

        <div className="text-xs font-semibold text-gray-500">
          Showing {filteredMedia.length} of {mediaList.length} total items
        </div>
      </div>

      {/* Media Grid */}
      {filteredMedia.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center text-gray-400">
          <FileImage className="w-12 h-12 mx-auto mb-2 text-gray-300" />
          <p className="text-sm font-medium">No media items found</p>
          <p className="text-xs text-gray-400 mt-1">Upload a photo using the button above</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {filteredMedia.map((item) => (
            <div
              key={item.id}
              className="group bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-2xs hover:border-[#1a3d1a] hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div
                onClick={() => setSelectedItem(item)}
                className="aspect-square bg-gray-50 relative overflow-hidden cursor-pointer"
              >
                <img
                  src={item.url}
                  alt={item.alt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-2 text-white">
                  <span className="text-xs font-semibold bg-white/20 backdrop-blur-md px-2.5 py-1 rounded-md">
                    View Details
                  </span>
                </div>
              </div>

              <div className="p-3">
                <div className="text-xs font-bold text-gray-900 truncate" title={item.title}>
                  {item.title}
                </div>
                <div className="text-[10px] text-gray-400 truncate mt-0.5">
                  {formatFileSize(item.size)}
                </div>

                <div className="flex items-center justify-between pt-2 mt-2 border-t border-gray-100">
                  <button
                    type="button"
                    onClick={() => handleCopyUrl(item.url)}
                    className="p-1 text-gray-500 hover:text-gray-900 text-[11px] flex items-center gap-1"
                    title="Copy Image URL"
                  >
                    {copiedUrl === item.url ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>{copiedUrl === item.url ? 'Copied' : 'Copy'}</span>
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setSelectedItem(item)}
                      className="p-1 text-gray-500 hover:text-[#1a3d1a]"
                      title="Edit Metadata"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(item.id)}
                      className="p-1 text-red-400 hover:text-red-600"
                      title="Delete Image"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Media Details & Metadata Editor Modal */}
      {selectedItem && (
        <div className="fixed inset-0 z-[10000] bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-gray-200 overflow-hidden animate-scale-in">
            <div className="flex items-center justify-between p-4 sm:p-5 border-b border-gray-200 bg-gray-50">
              <h3 className="font-bold text-gray-900 text-base">Image Details & Alt Text</h3>
              <button
                onClick={() => setSelectedItem(null)}
                className="p-1 text-gray-400 hover:text-gray-700 rounded-lg hover:bg-gray-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
              <div className="aspect-16/9 max-h-[220px] bg-gray-100 rounded-xl overflow-hidden flex items-center justify-center border border-gray-200">
                <img
                  src={selectedItem.url}
                  alt={selectedItem.alt}
                  className="max-h-full max-w-full object-contain"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Image Title
                </label>
                <input
                  type="text"
                  value={selectedItem.title || ''}
                  onChange={(e) => setSelectedItem({ ...selectedItem, title: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs sm:text-sm border border-gray-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Alt Text (Crucial for Accessibility & SEO)
                </label>
                <input
                  type="text"
                  value={selectedItem.alt || ''}
                  onChange={(e) => setSelectedItem({ ...selectedItem, alt: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs sm:text-sm border border-gray-300 rounded-lg"
                  placeholder="Describe what is in the picture for visually impaired users"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Caption (Optional)
                </label>
                <textarea
                  rows={2}
                  value={selectedItem.caption || ''}
                  onChange={(e) => setSelectedItem({ ...selectedItem, caption: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs sm:text-sm border border-gray-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Direct Image Link URL
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={selectedItem.url}
                    className="flex-1 px-3 py-1.5 text-xs border border-gray-200 bg-gray-50 rounded-lg font-mono text-gray-600 select-all"
                  />
                  <button
                    type="button"
                    onClick={() => handleCopyUrl(selectedItem.url)}
                    className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-xs font-semibold rounded-lg flex items-center gap-1"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="p-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
              <button
                type="button"
                onClick={() => handleDelete(selectedItem.id)}
                className="text-xs text-red-600 hover:underline flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" /> Delete from Library
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedItem(null)}
                  className="px-3 py-1.5 text-xs font-semibold text-gray-700 hover:bg-gray-200 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveMetadata}
                  className="px-4 py-1.5 bg-[#1a3d1a] hover:bg-[#285e28] text-white text-xs font-semibold rounded-lg shadow-xs"
                >
                  Save Image Info
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
