import React, { useState, useEffect, useCallback } from 'react';
import {
  LayoutDashboard,
  Globe,
  Menu,
  FileText,
  Image as ImageIcon,
  BookOpen,
  Camera,
  Users,
  Layers,
  History,
  Lock,
  LogOut,
  ExternalLink,
  Save,
  Send,
  Eye,
  CheckCircle2,
  AlertCircle,
  X,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { CmsData } from '../cms/types';
import { DEFAULT_CMS_DATA } from '../cms/defaultCmsData';
import { AdminLogin } from './AdminLogin';

import { DashboardTab } from './tabs/DashboardTab';
import { GlobalTab } from './tabs/GlobalTab';
import { HeaderTab } from './tabs/HeaderTab';
import { PagesTab } from './tabs/PagesTab';
import { MediaTab } from './tabs/MediaTab';
import { StoriesTab } from './tabs/StoriesTab';
import { GalleryTab } from './tabs/GalleryTab';
import { TeamTab } from './tabs/TeamTab';
import { FooterTab } from './tabs/FooterTab';
import { BackupsTab } from './tabs/BackupsTab';
import { SecurityTab } from './tabs/SecurityTab';

export const AdminLayout: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [adminUser, setAdminUser] = useState<string>('admin');
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  const [cmsDraft, setCmsDraft] = useState<CmsData>(DEFAULT_CMS_DATA);
  const [hasUnpublishedChanges, setHasUnpublishedChanges] = useState<boolean>(false);
  const [lastPublishedAt, setLastPublishedAt] = useState<string>(new Date().toISOString());

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isPublishing, setIsPublishing] = useState<boolean>(false);
  const [showPublishModal, setShowPublishModal] = useState<boolean>(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Verify Auth on mount
  useEffect(() => {
    const token = localStorage.getItem('svcc_admin_token');
    const storedUser = localStorage.getItem('svcc_admin_user');
    if (!token) {
      setIsAuthenticated(false);
      setIsLoading(false);
      return;
    }

    fetch('/api/auth/me', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => {
        if (res.ok) {
          setIsAuthenticated(true);
          if (storedUser) setAdminUser(storedUser);
          fetchDraft();
        } else {
          localStorage.removeItem('svcc_admin_token');
          setIsAuthenticated(false);
          setIsLoading(false);
        }
      })
      .catch(() => {
        setIsAuthenticated(false);
        setIsLoading(false);
      });
  }, []);

  const fetchDraft = async () => {
    setIsLoading(true);
    const token = localStorage.getItem('svcc_admin_token');
    try {
      const res = await fetch('/api/cms/draft', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const json = await res.json();
        if (json.draft) {
          setCmsDraft(json.draft);
          setHasUnpublishedChanges(Boolean(json.hasUnpublishedChanges));
          if (json.lastPublishedAt) setLastPublishedAt(json.lastPublishedAt);
        }
      }
    } catch (err) {
      console.error('Failed to load draft:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveDraft = async (updatedData?: CmsData) => {
    const dataToSave = updatedData || cmsDraft;
    setIsSaving(true);
    const token = localStorage.getItem('svcc_admin_token');

    try {
      const res = await fetch('/api/cms/draft', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(dataToSave),
      });

      if (res.ok) {
        setHasUnpublishedChanges(true);
        showToast('Draft changes saved successfully! Ready to preview or publish.', 'success');
      } else {
        showToast('Failed to save draft changes.', 'error');
      }
    } catch (err: any) {
      showToast('Save error: ' + err.message, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handlePublish = async () => {
    setIsPublishing(true);
    const token = localStorage.getItem('svcc_admin_token');

    try {
      // First save current draft to ensure all in-memory changes are stored
      await fetch('/api/cms/draft', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(cmsDraft),
      });

      // Now call publish
      const res = await fetch('/api/cms/publish', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });

      const json = await res.json();
      if (res.ok) {
        setHasUnpublishedChanges(false);
        if (json.lastPublishedAt) setLastPublishedAt(json.lastPublishedAt);
        setShowPublishModal(false);
        showToast('🎉 Published! Your updates are now live on the public website.', 'success');
      } else {
        showToast(json.error || 'Failed to publish changes.', 'error');
      }
    } catch (err: any) {
      showToast('Publish error: ' + err.message, 'error');
    } finally {
      setIsPublishing(false);
    }
  };

  const handleDiscardDraft = async () => {
    if (!confirm('Discard all unpublished changes and revert to the live published version?')) {
      return;
    }

    const token = localStorage.getItem('svcc_admin_token');
    try {
      const res = await fetch('/api/cms/discard-draft', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        showToast('Unpublished changes discarded. Reverted to live content.', 'info');
        fetchDraft();
      }
    } catch (err: any) {
      showToast('Discard error: ' + err.message, 'error');
    }
  };

  const handlePreview = () => {
    sessionStorage.setItem('svcc_preview_mode', 'true');
    window.location.href = '/?preview=true';
  };

  const handleLogout = async () => {
    const token = localStorage.getItem('svcc_admin_token');
    await fetch('/api/auth/logout', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    }).catch(() => {});
    localStorage.removeItem('svcc_admin_token');
    localStorage.removeItem('svcc_admin_user');
    setIsAuthenticated(false);
  };

  if (!isAuthenticated) {
    return (
      <AdminLogin
        onLoginSuccess={(token, user) => {
          setIsAuthenticated(true);
          setAdminUser(user);
          fetchDraft();
        }}
      />
    );
  }

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'global', label: 'Global & Branding', icon: Globe },
    { id: 'header', label: 'Header & Navigation', icon: Menu },
    { id: 'pages', label: 'Pages & Sections', icon: Layers },
    { id: 'media', label: 'Media Library', icon: ImageIcon },
    { id: 'stories', label: 'Healing Stories', icon: BookOpen },
    { id: 'gallery', label: 'Documentary Gallery', icon: Camera },
    { id: 'team', label: 'Veterinary Team', icon: Users },
    { id: 'footer', label: 'Footer Settings', icon: FileText },
    { id: 'backups', label: 'Backups & Recovery', icon: History },
    { id: 'security', label: 'Security & Access', icon: Lock },
  ];

  return (
    <div className="min-h-screen bg-[#F8FAF9] text-gray-900 flex flex-col font-sans">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-4 right-4 z-[99999] animate-scale-in">
          <div
            className={`px-4 py-3 rounded-2xl shadow-xl border flex items-center gap-2.5 text-xs sm:text-sm font-semibold ${
              toast.type === 'success'
                ? 'bg-emerald-800 text-white border-emerald-700'
                : toast.type === 'error'
                ? 'bg-red-800 text-white border-red-700'
                : 'bg-gray-800 text-white border-gray-700'
            }`}
          >
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-300" />
            ) : (
              <AlertCircle className="w-4 h-4 text-amber-300" />
            )}
            <span>{toast.message}</span>
            <button onClick={() => setToast(null)} className="ml-2 text-white/60 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Persistent Top Navigation Bar */}
      <header className="sticky top-0 z-50 bg-[#1a3d1a] text-white border-b border-[#285e28] px-4 sm:px-6 py-2.5 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-1.5 rounded-lg hover:bg-white/10 text-white"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#E86A10]" />
            <span className="font-serif font-bold text-sm sm:text-base tracking-wide text-[#EFFDF0]">
              SVCC CMS Control Center
            </span>
          </div>

          {/* Status Badge */}
          <div className="hidden sm:flex items-center ml-4">
            {hasUnpublishedChanges ? (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                <span>Draft Changes Ready</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>All Live & Synced</span>
              </span>
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => handleSaveDraft()}
            disabled={isSaving}
            className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Save Draft"
          >
            <Save className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isSaving ? 'Saving...' : 'Save Draft'}</span>
          </button>

          <button
            onClick={handlePreview}
            className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Preview Live Site"
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Live Preview</span>
          </button>

          <button
            onClick={() => setShowPublishModal(true)}
            className="px-4 py-1.5 rounded-xl bg-[#E86A10] hover:bg-[#d45e0d] text-white text-xs sm:text-sm font-semibold transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Publish to Live</span>
          </button>

          <a
            href="#/"
            className="hidden md:inline-flex items-center gap-1 text-xs text-white/70 hover:text-white px-2 py-1"
            title="Go to website"
          >
            <span>View Site</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </header>

      {/* Main CMS Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar */}
        <aside
          className={`fixed lg:static inset-y-0 left-0 z-40 w-64 bg-white border-r border-gray-200 flex flex-col justify-between transition-transform duration-300 ${
            isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
          }`}
        >
          <div className="p-4 overflow-y-auto">
            <div className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-2 px-3">
              CMS Navigation
            </div>
            <nav className="space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all text-left cursor-pointer ${
                      isActive
                        ? 'bg-[#1a3d1a] text-white shadow-xs'
                        : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* User info & Logout */}
          <div className="p-4 border-t border-gray-100 bg-gray-50/70">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs font-bold text-gray-800 truncate">
                Admin: {adminUser}
              </div>
              <button
                onClick={handleLogout}
                className="text-xs text-red-600 hover:text-red-700 font-semibold flex items-center gap-1"
                title="Log out of CMS"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Exit</span>
              </button>
            </div>
            <div className="text-[10px] text-gray-400">
              Sai Vet Care Clinic CMS v{cmsDraft.version || 1}
            </div>
          </div>
        </aside>

        {/* Mobile Backdrop */}
        {isMobileMenuOpen && (
          <div
            onClick={() => setIsMobileMenuOpen(false)}
            className="fixed inset-0 bg-black/40 z-30 lg:hidden"
          />
        )}

        {/* Content Viewport */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          {activeTab === 'dashboard' && (
            <DashboardTab
              cmsData={cmsDraft}
              hasUnpublishedChanges={hasUnpublishedChanges}
              lastPublishedAt={lastPublishedAt}
              setActiveTab={setActiveTab}
              onPreview={handlePreview}
              onPublish={() => setShowPublishModal(true)}
            />
          )}

          {activeTab === 'global' && (
            <GlobalTab
              settings={cmsDraft.settings}
              mediaList={cmsDraft.media || []}
              onChange={(updated) => {
                setCmsDraft({ ...cmsDraft, settings: updated });
                setHasUnpublishedChanges(true);
              }}
              onUploadMedia={(item) => {
                const updatedMedia = [item, ...(cmsDraft.media || [])];
                setCmsDraft({ ...cmsDraft, media: updatedMedia });
                setHasUnpublishedChanges(true);
              }}
            />
          )}

          {activeTab === 'header' && (
            <HeaderTab
              header={cmsDraft.header}
              onChange={(updated) => {
                setCmsDraft({ ...cmsDraft, header: updated });
                setHasUnpublishedChanges(true);
              }}
            />
          )}

          {activeTab === 'pages' && (
            <PagesTab
              pages={cmsDraft.pages}
              mediaList={cmsDraft.media || []}
              onChange={(updated) => {
                setCmsDraft({ ...cmsDraft, pages: updated });
                setHasUnpublishedChanges(true);
              }}
              onUploadMedia={(item) => {
                const updatedMedia = [item, ...(cmsDraft.media || [])];
                setCmsDraft({ ...cmsDraft, media: updatedMedia });
                setHasUnpublishedChanges(true);
              }}
            />
          )}

          {activeTab === 'media' && (
            <MediaTab
              mediaList={cmsDraft.media || []}
              onChange={(updated) => {
                setCmsDraft({ ...cmsDraft, media: updated });
                setHasUnpublishedChanges(true);
              }}
              onUpload={(item) => {
                const updatedMedia = [item, ...(cmsDraft.media || [])];
                setCmsDraft({ ...cmsDraft, media: updatedMedia });
                setHasUnpublishedChanges(true);
              }}
            />
          )}

          {activeTab === 'stories' && (
            <StoriesTab
              stories={cmsDraft.collections?.stories || []}
              mediaList={cmsDraft.media || []}
              onChange={(updated) => {
                setCmsDraft({
                  ...cmsDraft,
                  collections: { ...cmsDraft.collections, stories: updated },
                });
                setHasUnpublishedChanges(true);
              }}
              onUploadMedia={(item) => {
                const updatedMedia = [item, ...(cmsDraft.media || [])];
                setCmsDraft({ ...cmsDraft, media: updatedMedia });
                setHasUnpublishedChanges(true);
              }}
            />
          )}

          {activeTab === 'gallery' && (
            <GalleryTab
              gallery={cmsDraft.collections?.gallery || []}
              mediaList={cmsDraft.media || []}
              onChange={(updated) => {
                setCmsDraft({
                  ...cmsDraft,
                  collections: { ...cmsDraft.collections, gallery: updated },
                });
                setHasUnpublishedChanges(true);
              }}
              onUploadMedia={(item) => {
                const updatedMedia = [item, ...(cmsDraft.media || [])];
                setCmsDraft({ ...cmsDraft, media: updatedMedia });
                setHasUnpublishedChanges(true);
              }}
            />
          )}

          {activeTab === 'team' && (
            <TeamTab
              team={cmsDraft.collections?.team || []}
              onChange={(updated) => {
                setCmsDraft({
                  ...cmsDraft,
                  collections: { ...cmsDraft.collections, team: updated },
                });
                setHasUnpublishedChanges(true);
              }}
            />
          )}

          {activeTab === 'footer' && (
            <FooterTab
              footer={cmsDraft.footer}
              onChange={(updated) => {
                setCmsDraft({ ...cmsDraft, footer: updated });
                setHasUnpublishedChanges(true);
              }}
            />
          )}

          {activeTab === 'backups' && (
            <BackupsTab
              onRestoreComplete={() => {
                fetchDraft();
                showToast('Content successfully restored from backup!', 'success');
              }}
            />
          )}

          {activeTab === 'security' && <SecurityTab />}
        </main>
      </div>

      {/* Publish Confirmation Modal */}
      {showPublishModal && (
        <div className="fixed inset-0 z-[10000] bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-gray-200 animate-scale-in">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-[#E86A10] flex items-center justify-center mb-4">
              <Send className="w-6 h-6" />
            </div>

            <h3 className="text-lg font-bold text-gray-900 mb-1">
              Publish Draft to Live Website?
            </h3>
            <p className="text-xs sm:text-sm text-gray-600 leading-relaxed mb-4">
              This action will publish all your pending draft edits so they are immediately visible to all visitors on the public website. A recovery snapshot backup is created automatically before publishing.
            </p>

            <div className="bg-gray-50 p-3.5 rounded-xl border border-gray-200 text-xs space-y-1.5 mb-6 text-gray-700">
              <div className="flex items-center justify-between">
                <span>Total Live Pages:</span>
                <span className="font-semibold">{Object.keys(cmsDraft.pages).length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Media Items:</span>
                <span className="font-semibold">{cmsDraft.media?.length || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Backup Protection:</span>
                <span className="font-semibold text-emerald-700">Automatic Snapshot Enabled</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowPublishModal(false)}
                className="px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-100 rounded-xl cursor-pointer"
              >
                Keep as Draft
              </button>
              <button
                type="button"
                onClick={handlePublish}
                disabled={isPublishing}
                className="px-5 py-2.5 bg-[#E86A10] hover:bg-[#d45e0d] text-white text-xs sm:text-sm font-semibold rounded-xl shadow-md transition-colors flex items-center gap-2 cursor-pointer"
              >
                {isPublishing ? (
                  <span>Publishing...</span>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Confirm & Publish Now</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
