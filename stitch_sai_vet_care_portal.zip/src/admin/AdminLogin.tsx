import React, { useState } from 'react';
import { Lock, User, Eye, EyeOff, ShieldCheck, Heart, ArrowRight } from 'lucide-react';

interface AdminLoginProps {
  onLoginSuccess: (token: string, username: string) => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim(), password }),
      });

      const json = await res.json();
      if (res.ok && json.token) {
        localStorage.setItem('svcc_admin_token', json.token);
        localStorage.setItem('svcc_admin_user', json.user?.username || 'admin');
        onLoginSuccess(json.token, json.user?.username || 'admin');
      } else {
        setError(json.error || 'Invalid credentials. Please check your username and password.');
      }
    } catch (err: any) {
      setError('Connection failed: ' + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#EFFDF0] flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-xl border border-[#1a3d1a]/15 relative overflow-hidden">
        {/* Clinic Branding Header */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-[#1a3d1a] text-[#EFFDF0] flex items-center justify-center mx-auto mb-3 shadow-md">
            <Heart className="w-7 h-7 text-[#E86A10]" />
          </div>
          <h1 className="text-xl sm:text-2xl font-serif font-bold text-[#1a3d1a] tracking-tight">
            Sai Vet Care Clinic
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 font-medium mt-1">
            Visual Website Content Management System (CMS)
          </p>
        </div>

        {error && (
          <div className="mb-5 p-3.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
            <span>{error}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1.5">
              Admin Username
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full pl-10 pr-3 py-2.5 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:ring-1 focus:ring-[#1a3d1a] focus:outline-hidden transition-all"
                placeholder="Username"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1.5">
              Admin Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-10 py-2.5 text-xs sm:text-sm border border-gray-300 rounded-xl focus:border-[#1a3d1a] focus:ring-1 focus:ring-[#1a3d1a] focus:outline-hidden transition-all"
                placeholder="Password"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

        {/* Quick Credential Helper & Auto-Fill */}
        <div className="bg-[#EFFDF0] border border-[#1a3d1a]/25 rounded-2xl p-3.5">
          <div className="flex items-center justify-between gap-2">
            <div className="text-xs text-[#1a3d1a]">
              <div className="font-bold flex items-center gap-1.5 text-[#1a3d1a]">
                <ShieldCheck className="w-4 h-4 text-[#E86A10]" />
                <span>Admin Login Credentials:</span>
              </div>
              <div className="mt-1 font-mono text-[11.5px] text-gray-700 space-y-0.5">
                <div>User: <span className="font-bold text-[#1a3d1a] bg-white px-1.5 py-0.5 rounded border border-[#1a3d1a]/15">admin</span></div>
                <div className="pt-0.5">Pass: <span className="font-bold text-[#1a3d1a] bg-white px-1.5 py-0.5 rounded border border-[#1a3d1a]/15">AdminPassword2026!</span> or <span className="font-bold text-[#1a3d1a] bg-white px-1.5 py-0.5 rounded border border-[#1a3d1a]/15">admin</span></div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                setUsername('admin');
                setPassword('AdminPassword2026!');
                setError('');
              }}
              className="px-3 py-2 bg-[#1a3d1a] hover:bg-[#285e28] text-white text-xs font-semibold rounded-xl cursor-pointer shadow-xs transition-colors shrink-0"
              title="Click to automatically fill credentials into the form"
            >
              Auto-Fill
            </button>
          </div>
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full mt-2 py-3 bg-[#1a3d1a] hover:bg-[#285e28] text-white font-semibold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          {isLoading ? (
            <span>Authenticating...</span>
          ) : (
            <>
              <span>Enter Admin Panel</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </form>

      {/* Security Notice */}
      <div className="mt-6 pt-5 border-t border-gray-100 text-center">
        <p className="text-[11px] text-gray-500">
          Tip: You can customize your username and password anytime inside the <strong>Security & Access</strong> tab.
        </p>
      </div>

        {/* Link back to public site */}
        <div className="mt-4 text-center">
          <a
            href="#/"
            className="text-xs text-gray-500 hover:text-[#1a3d1a] font-medium hover:underline"
          >
            ← Return to Public Website
          </a>
        </div>
      </div>
    </div>
  );
};
