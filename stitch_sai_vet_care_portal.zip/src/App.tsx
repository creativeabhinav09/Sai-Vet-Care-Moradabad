/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { ScrollToTop } from './components/ScrollToTop';

import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { SevaPage } from './pages/SevaPage';
import { ClinicalPage } from './pages/ClinicalPage';
import { NetworkPage } from './pages/NetworkPage';
import { TeamPage } from './pages/TeamPage';
import { GalleryPage } from './pages/GalleryPage';
import { StoriesPage } from './pages/StoriesPage';
import { ContactPage } from './pages/ContactPage';

import { CmsProvider } from './cms/CmsContext';
import { AdminLayout } from './admin/AdminLayout';

function AnimatedAppContent({
  reducedMotion,
  onToggleReducedMotion,
}: {
  reducedMotion: boolean;
  onToggleReducedMotion: () => void;
}) {
  const location = useLocation();
  const isAdminRoute = location.pathname.startsWith('/admin');

  // If inside Admin panel, render AdminLayout in full screen without public website header/footer
  if (isAdminRoute) {
    return <AdminLayout />;
  }

  return (
    <div
      className={`min-h-screen flex flex-col bg-[#EFFDF0] text-[#1a3d1a] ${
        reducedMotion ? 'reduced-motion-active' : ''
      }`}
    >
      <ScrollToTop />

      {/* Persistent Multi-Page Navigation Header with Menu & Submenus */}
      <Header
        reducedMotion={reducedMotion}
        onToggleReducedMotion={onToggleReducedMotion}
      />

      {/* Main Content Area with Route Keyed Animation */}
      <main
        key={location.pathname}
        className="flex-1 animate-fade-in"
      >
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/seva" element={<SevaPage />} />
          <Route path="/clinical" element={<ClinicalPage />} />
          <Route path="/network" element={<NetworkPage />} />
          <Route path="/team" element={<TeamPage />} />
          <Route path="/gallery" element={<GalleryPage />} />
          <Route path="/stories" element={<StoriesPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/admin/*" element={<AdminLayout />} />
          <Route path="*" element={<HomePage />} />
        </Routes>
      </main>

      {/* Comprehensive Multi-Page Footer */}
      <Footer />
    </div>
  );
}

export default function App() {
  const [reducedMotion, setReducedMotion] = useState<boolean>(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
      if (mediaQuery.matches) {
        setReducedMotion(true);
      }

      const handleChange = (e: MediaQueryListEvent) => {
        setReducedMotion(e.matches);
      };

      mediaQuery.addEventListener('change', handleChange);
      return () => mediaQuery.removeEventListener('change', handleChange);
    }
  }, []);

  return (
    <CmsProvider>
      <Router>
        <AnimatedAppContent
          reducedMotion={reducedMotion}
          onToggleReducedMotion={() => setReducedMotion((prev) => !prev)}
        />
      </Router>
    </CmsProvider>
  );
}
