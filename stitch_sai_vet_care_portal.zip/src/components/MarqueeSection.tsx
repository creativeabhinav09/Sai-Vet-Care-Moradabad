import React, { useEffect, useRef, useState } from 'react';
import { Sparkles, Heart, Activity, Ambulance, Stethoscope, ShieldCheck, Pill, Warehouse, Scissors } from 'lucide-react';
import { SvccArtwork } from './SvccArtwork';

interface MarqueeCardData {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  metric: string;
  artworkVariant: 'hero' | 'satpathy' | 'medical' | 'surgical' | 'gaushala' | 'rehab' | 'emergency';
  accentColor: string;
  badge: string;
}

const ROW_1_CARDS: MarqueeCardData[] = [
  {
    id: 'm1',
    title: 'Rapid Ambulance Rescue Unit',
    subtitle: 'Ahmednagar District Highway Corridor',
    category: 'Emergency Dispatch',
    metric: '15-Min Response',
    artworkVariant: 'emergency',
    accentColor: '#E86A10',
    badge: 'Live Dispatch',
  },
  {
    id: 'm2',
    title: 'Aseptic Fracture Pinning',
    subtitle: 'Orthopaedic Surgical Theater 01',
    category: 'Advanced Surgery',
    metric: '96% Bone Healing',
    artworkVariant: 'surgical',
    accentColor: '#6F8F72',
    badge: 'Sterile Suite',
  },
  {
    id: 'm3',
    title: 'Gaushala Bovine Sanctuary',
    subtitle: '48 Adopted Sacred Cattle Centers',
    category: 'Herd Welfare',
    metric: '12,000+ Native Cows',
    artworkVariant: 'gaushala',
    accentColor: '#EDE4D3',
    badge: 'Prophylaxis',
  },
  {
    id: 'm4',
    title: 'Digital Radiography & Imaging',
    subtitle: 'High-Resolution Diagnostic Suite',
    category: 'Diagnostics',
    metric: 'Instant X-Ray',
    artworkVariant: 'medical',
    accentColor: '#6F8F72',
    badge: 'Pathology Lab',
  },
  {
    id: 'm5',
    title: 'Free Pharmaceutical Dispensary',
    subtitle: 'Zero Commercial Charges for Strays',
    category: 'Free Medicine',
    metric: '100% Free Drugs',
    artworkVariant: 'rehab',
    accentColor: '#E86A10',
    badge: 'Zero Billing',
  },
  {
    id: 'm6',
    title: 'Pediatric Stray Rehabilitation',
    subtitle: 'Climate-Controlled Recovery Paddock',
    category: 'Post-Op Nursing',
    metric: '24/7 Monitored',
    artworkVariant: 'hero',
    accentColor: '#EDE4D3',
    badge: 'Special Care',
  },
  {
    id: 'm7',
    title: 'Dr. Satpathy Ji Inspiration Wing',
    subtitle: 'Spiritual Sanctuary & Healing Center',
    category: 'Guiding Light',
    metric: 'Founded 2009',
    artworkVariant: 'satpathy',
    accentColor: '#E86A10',
    badge: 'Seva Charter',
  },
  {
    id: 'm8',
    title: 'Working Bullock Rest & Splinting',
    subtitle: 'Agrarian Rural Healthcare Camp',
    category: 'Farm Animals',
    metric: 'Free Hoof Trimming',
    artworkVariant: 'gaushala',
    accentColor: '#6F8F72',
    badge: 'Rural Outreach',
  },
];

const ROW_2_CARDS: MarqueeCardData[] = [
  {
    id: 'm9',
    title: 'Elderly Blind Cow Sanctuary',
    subtitle: 'Padded Soft-Bedding Paddock',
    category: 'Geriatric Care',
    metric: 'Lifetime Support',
    artworkVariant: 'gaushala',
    accentColor: '#EDE4D3',
    badge: 'Permanent Home',
  },
  {
    id: 'm10',
    title: 'Emergency Oxygen Resuscitation',
    subtitle: 'ICU Critical Trauma Unit',
    category: 'Trauma Triage',
    metric: 'Continuous Vitals',
    artworkVariant: 'emergency',
    accentColor: '#E86A10',
    badge: 'Priority 1',
  },
  {
    id: 'm11',
    title: 'Sterile Soft Tissue Operative',
    subtitle: 'Laparotomy & Wound Debridement',
    category: 'Clinical Surgery',
    metric: 'Isoflurane Gas',
    artworkVariant: 'surgical',
    accentColor: '#6F8F72',
    badge: 'Aseptic Field',
  },
  {
    id: 'm12',
    title: 'Humane Animal Birth Control (ABC)',
    subtitle: 'Rabies-Free Community Vaccination',
    category: 'Community Seva',
    metric: '8,200+ Protected',
    artworkVariant: 'medical',
    accentColor: '#E86A10',
    badge: 'AWBI Certified',
  },
  {
    id: 'm13',
    title: 'Mobility Sling Rehabilitation',
    subtitle: 'Hydrotherapy & Nerve Stimulation',
    category: 'Physiotherapy',
    metric: 'Daily Therapy',
    artworkVariant: 'rehab',
    accentColor: '#6F8F72',
    badge: 'Recovery Ward',
  },
  {
    id: 'm14',
    title: 'Avian & Wildlife Relief Wing',
    subtitle: 'Sacred Neem Tree Enclosures',
    category: 'Fauna Care',
    metric: 'Peacocks & Birds',
    artworkVariant: 'hero',
    accentColor: '#EDE4D3',
    badge: 'Shrine Belt',
  },
  {
    id: 'm15',
    title: '24/7 Emergency Dispatch Helpline',
    subtitle: 'Statewide Call-In Center',
    category: 'Helpline',
    metric: '+91 94220 89108',
    artworkVariant: 'emergency',
    accentColor: '#E86A10',
    badge: 'Always Awake',
  },
  {
    id: 'm16',
    title: 'Pastoral Village Health Camps',
    subtitle: 'Doorstep Vaccination & Mineral Licks',
    category: 'Field Outreach',
    metric: '45+ Hamlets',
    artworkVariant: 'gaushala',
    accentColor: '#6F8F72',
    badge: 'Community Seva',
  },
];

// Tripled lists for seamless visual looping
const ROW_1_TRIPLED = [...ROW_1_CARDS, ...ROW_1_CARDS, ...ROW_1_CARDS];
const ROW_2_TRIPLED = [...ROW_2_CARDS, ...ROW_2_CARDS, ...ROW_2_CARDS];

export const MarqueeSection: React.FC = () => {
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const idleOffsetRef = useRef<number>(0);
  const [, setTick] = useState<number>(0);

  useEffect(() => {
    let animId: number;
    // Gentle continuous base drift without reading window.scrollY or triggering scroll jumps
    const loop = () => {
      if (!isHovered) {
        idleOffsetRef.current = (idleOffsetRef.current + 0.4) % 1800;
        setTick((t) => (t + 1) % 60);
      }
      animId = requestAnimationFrame(loop);
    };
    animId = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [isHovered]);

  const row1Transform = `translate3d(${-idleOffsetRef.current}px, 0, 0)`;
  const row2Transform = `translate3d(${idleOffsetRef.current - 1200}px, 0, 0)`;

  return (
    <section
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="relative w-full py-8 sm:py-10 bg-[#142618] text-[#EFFDF0] overflow-hidden select-none border-y border-[#6F8F72]/20"
    >
      {/* Background radial gradients */}
      <div className="absolute top-0 left-1/4 w-[400px] h-[200px] bg-[#6F8F72]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-[400px] h-[200px] bg-[#E86A10]/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Info */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-6 sm:mb-7 text-center relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1a3d1a] border border-[#6F8F72]/30 text-[11px] font-semibold text-[#EDE4D3] mb-2 shadow-2xs">
          <Sparkles className="w-3 h-3 text-[#E86A10] animate-pulse" />
          <span>SVCC Live Seva In Action</span>
        </div>

        <h2 className="text-2xl sm:text-3xl md:text-4xl font-serif-display font-bold text-[#EFFDF0] tracking-tight">
          Every Ward, Every Roadside, Every Sanctuary
        </h2>
        <p className="mt-1.5 text-xs sm:text-sm text-[#EDE4D3]/80 max-w-xl mx-auto leading-relaxed">
          Clinical surgical teams, 24/7 ambulances, and gaushala doctors working in seamless synchrony across Moradabad.
        </p>
      </div>

      {/* Marquee Rows Container */}
      <div className="space-y-3 sm:space-y-4">
        
        {/* ROW 1 */}
        <div className="w-full overflow-hidden">
          <div
            style={{
              transform: row1Transform,
              willChange: 'transform',
            }}
            className="flex gap-3 sm:gap-4 w-max"
          >
            {ROW_1_TRIPLED.map((card, idx) => (
              <div
                key={`r1-${card.id}-${idx}`}
                className="w-[260px] sm:w-[300px] md:w-[320px] h-[160px] sm:h-[175px] rounded-2xl bg-[#1c3522] border border-[#6F8F72]/30 p-3.5 sm:p-4 flex flex-col justify-between shadow-md hover:border-[#E86A10] transition-all duration-300 group shrink-0 relative overflow-hidden"
              >
                {/* Visual Artwork Background */}
                <div className="absolute inset-0 opacity-20 group-hover:opacity-30 transition-opacity pointer-events-none">
                  <SvccArtwork variant={card.artworkVariant} className="w-full h-full object-contain" />
                </div>

                {/* Top Badge & Metric */}
                <div className="relative z-10 flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#142618]/90 text-[#EDE4D3] border border-white/10 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#E86A10] animate-ping" />
                    {card.badge}
                  </span>
                  <span className="text-[11px] font-mono font-semibold text-[#EDE4D3] bg-[#142618]/80 px-1.5 py-0.5 rounded-md border border-white/10">
                    {card.metric}
                  </span>
                </div>

                {/* Bottom Content */}
                <div className="relative z-10">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-[#6F8F72] mb-0.5">
                    {card.category}
                  </div>
                  <h3 className="text-base sm:text-lg font-serif-display font-bold text-[#EFFDF0] leading-snug group-hover:text-[#E86A10] transition-colors">
                    {card.title}
                  </h3>
                  <p className="text-[11px] text-[#EDE4D3]/75 mt-0.5 truncate">
                    {card.subtitle}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ROW 2 */}
        <div className="w-full overflow-hidden">
          <div
            style={{
              transform: row2Transform,
              willChange: 'transform',
            }}
            className="flex gap-3 sm:gap-4 w-max"
          >
            {ROW_2_TRIPLED.map((card, idx) => (
              <div
                key={`r2-${card.id}-${idx}`}
                className="w-[260px] sm:w-[300px] md:w-[320px] h-[160px] sm:h-[175px] rounded-2xl bg-[#1c3522] border border-[#6F8F72]/30 p-3.5 sm:p-4 flex flex-col justify-between shadow-md hover:border-[#6F8F72] transition-all duration-300 group shrink-0 relative overflow-hidden"
              >
                {/* Visual Artwork Background */}
                <div className="absolute inset-0 opacity-20 group-hover:opacity-30 transition-opacity pointer-events-none">
                  <SvccArtwork variant={card.artworkVariant} className="w-full h-full object-contain" />
                </div>

                {/* Top Badge & Metric */}
                <div className="relative z-10 flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#142618]/90 text-[#EDE4D3] border border-white/10 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#6F8F72]" />
                    {card.badge}
                  </span>
                  <span className="text-[11px] font-mono font-semibold text-[#EDE4D3] bg-[#142618]/80 px-1.5 py-0.5 rounded-md border border-white/10">
                    {card.metric}
                  </span>
                </div>

                {/* Bottom Content */}
                <div className="relative z-10">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-[#E86A10] mb-0.5">
                    {card.category}
                  </div>
                  <h3 className="text-base sm:text-lg font-serif-display font-bold text-[#EFFDF0] leading-snug group-hover:text-[#EDE4D3] transition-colors">
                    {card.title}
                  </h3>
                  <p className="text-[11px] text-[#EDE4D3]/75 mt-0.5 truncate">
                    {card.subtitle}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Subtle edge vignette overlays for smooth infinite blend */}
      <div className="absolute top-0 bottom-0 left-0 w-16 sm:w-24 bg-gradient-to-r from-[#142618] to-transparent pointer-events-none z-20" />
      <div className="absolute top-0 bottom-0 right-0 w-16 sm:w-24 bg-gradient-to-l from-[#142618] to-transparent pointer-events-none z-20" />
    </section>
  );
};
