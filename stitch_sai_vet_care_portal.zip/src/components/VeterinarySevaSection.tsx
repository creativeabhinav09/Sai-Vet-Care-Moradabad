import React, { useState } from 'react';
import {
  Ambulance,
  HeartPulse,
  Stethoscope,
  ClipboardCheck,
  ShieldCheck,
  Pill,
  Warehouse,
  Users,
  Syringe,
  ArrowRight,
} from 'lucide-react';
import { VETERINARY_SEVA_CARDS } from '../data/svccData';
import { ScrollReveal } from './ScrollReveal';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from './SectionContainer';
import { useCms } from '../cms/CmsContext';

interface SevaSectionProps {
  onSelectSeva?: (id: string) => void;
}

export const VeterinarySevaSection: React.FC<SevaSectionProps> = ({ onSelectSeva }) => {
  const { data } = useCms();
  const allCards = data?.collections?.sevaCards?.length ? data.collections.sevaCards : VETERINARY_SEVA_CARDS;

  const { ref: sectionRef, isIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  const [selectedCategory, setSelectedCategory] = useState<'all' | 'clinical' | 'aid' | 'community'>('all');

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Ambulance':
        return <Ambulance className="w-5 h-5" />;
      case 'HeartPulse':
        return <HeartPulse className="w-5 h-5" />;
      case 'Stethoscope':
        return <Stethoscope className="w-5 h-5" />;
      case 'ClipboardCheck':
        return <ClipboardCheck className="w-5 h-5" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-5 h-5" />;
      case 'Pill':
        return <Pill className="w-5 h-5" />;
      case 'Warehouse':
        return <Warehouse className="w-5 h-5" />;
      case 'Users':
        return <Users className="w-5 h-5" />;
      case 'Syringe':
        return <Syringe className="w-5 h-5" />;
      default:
        return <Stethoscope className="w-5 h-5" />;
    }
  };

  const categories = [
    { id: 'all', label: 'All Seva (9)' },
    { id: 'clinical', label: 'Clinical & Surgery' },
    { id: 'aid', label: 'Free Aid & Medicines' },
    { id: 'community', label: 'Gaushala & Field' },
  ] as const;

  const filteredCards = selectedCategory === 'all'
    ? allCards
    : allCards.filter((c) => c.category === selectedCategory);

  return (
    <section
      id="seva"
      ref={sectionRef}
      style={{
        paddingTop: 'clamp(28px, 3.5vw, 44px)',
        paddingBottom: 'clamp(28px, 3.5vw, 44px)',
      }}
      className="w-full bg-[#EFFDF0] relative"
    >
      <SectionContainer>
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-6 sm:mb-7">
          <ScrollReveal animation="fade-in" delay={80} reverseOnScrollUp={false}>
            <span className="label-eyebrow text-[#6F8F72]">
              Comprehensive Clinical & Humanitarian Care
            </span>
          </ScrollReveal>

          <ScrollReveal animation="text-reveal" delay={140} reverseOnScrollUp={false}>
            <h2 className="section-h2 text-[#1a3d1a] mt-1.5">
              Veterinary Seva Disciplines
            </h2>
          </ScrollReveal>

          <ScrollReveal animation="fade-up" delay={200} reverseOnScrollUp={false}>
            <p className="body-lead mt-2 text-[#1a3d1a]/85 mx-auto text-sm sm:text-base">
              Delivering holistic treatment across hospital wards, mobile clinics, and pastoral cattle shelters with zero financial barriers for animals in need.
            </p>
          </ScrollReveal>

          {/* Interactive Category Filter Pills */}
          <ScrollReveal animation="fade-up" delay={260} reverseOnScrollUp={false}>
            <div className="mt-4 flex flex-wrap items-center justify-center gap-1.5 p-1 bg-white/90 backdrop-blur-md rounded-xl max-w-lg mx-auto border border-[#1a3d1a]/15 shadow-2xs">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3.5 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all duration-200 cursor-pointer min-h-[34px] ${
                    selectedCategory === cat.id
                      ? 'bg-[#1a3d1a] text-white shadow-xs'
                      : 'text-gray-700 hover:text-[#1a3d1a] hover:bg-[#EFFDF0]'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </ScrollReveal>
        </div>

        {/* 9 Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 items-stretch">
          {filteredCards.map((card, idx) => (
            <ScrollReveal
              key={card.id}
              animation="fade-up"
              delay={80 + (idx % 3) * 60}
              reverseOnScrollUp={false}
              className="h-full"
            >
              <div
                onClick={() => onSelectSeva && onSelectSeva(card.id)}
                className="svcc-card group relative bg-white rounded-2xl p-4.5 sm:p-5 border border-[#1a3d1a]/15 shadow-2xs hover:border-[#6F8F72] cursor-pointer overflow-hidden h-full flex flex-col justify-between"
              >
                {/* Expandable Accent Line on Hover */}
                <div className="card-accent-line" />

                <div>
                  {/* Card Icon Header */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="card-icon-float w-10 h-10 rounded-xl bg-[#EFFDF0] text-[#1a3d1a] border border-[#1a3d1a]/10 flex items-center justify-center transition-colors duration-300 group-hover:bg-[#1a3d1a] group-hover:text-white shadow-2xs">
                      {getIcon(card.iconName)}
                    </div>
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-[#6F8F72] bg-[#EFFDF0] px-2 py-0.5 rounded-md border border-[#6F8F72]/20">
                      Seva #{idx + 1}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="sub-h3 text-[#1a3d1a] mb-1.5 transition-colors group-hover:text-[#2a5a2a] text-base sm:text-lg">
                    {card.title}
                  </h3>

                  {/* Description conforming to card body standard */}
                  <p className="card-body-text text-[#1a3d1a]/85 mb-3 text-xs sm:text-sm">
                    {card.description}
                  </p>

                  {/* Highlights List */}
                  <div className="space-y-1.5 pt-2.5 border-t border-gray-100 mb-3.5">
                    {card.highlights.map((item, hIdx) => (
                      <div key={hIdx} className="text-sm text-[#1a3d1a]/90 flex items-center gap-2 font-medium">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#E86A10] shrink-0" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Link */}
                <div className="pt-2 flex items-center gap-1.5 text-sm font-semibold text-[#1a3d1a] group-hover:text-[#E86A10] transition-colors">
                  <span>View Treatment Protocols</span>
                  <ArrowRight className="w-4 h-4 card-arrow-move" />
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </SectionContainer>
    </section>
  );
};
