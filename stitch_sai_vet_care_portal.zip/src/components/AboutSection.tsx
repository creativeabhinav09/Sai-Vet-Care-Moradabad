import React from 'react';
import { ArrowRight, CheckCircle2, Heart, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { SvccArtwork } from './SvccArtwork';
import { ScrollReveal } from './ScrollReveal';
import { SectionContainer } from './SectionContainer';
import { useCms } from '../cms/CmsContext';

interface AboutSectionProps {
  onLearnMore?: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ onLearnMore }) => {
  const navigate = useNavigate();
  const { getSection } = useCms();
  const aboutConfig = getSection('home', 'about');

  if (aboutConfig?.enabled === false) {
    return null;
  }

  const handleLearnMore = () => {
    if (onLearnMore) {
      onLearnMore();
    } else {
      navigate('/about');
    }
  };

  return (
    <section
      id="about"
      style={{
        paddingTop: 'clamp(28px, 3.5vw, 44px)',
        paddingBottom: 'clamp(28px, 3.5vw, 44px)',
      }}
      className="w-full bg-[#FFFFFF] relative border-b border-[#1a3d1a]/10"
    >
      <SectionContainer>
        {/* Mobile / Tablet Header (< lg): ensures natural vertical reading flow */}
        <div className="lg:hidden mb-4 sm:mb-5">
          <ScrollReveal animation="fade-in" delay={80} reverseOnScrollUp={false}>
            <div className="flex items-center gap-1.5 mb-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#E86A10] shrink-0" />
              <span className="text-[12px] sm:text-[13px] font-semibold uppercase tracking-wider text-[#6F8F72]">
                {aboutConfig?.eyebrow || 'About Sai Vet Care Clinic'}
              </span>
            </div>
          </ScrollReveal>

          <ScrollReveal animation="fade-up" delay={140} reverseOnScrollUp={false}>
            <h2 className="font-serif-display text-[#1a3d1a] text-[clamp(24px,3.5vw,36px)] font-normal leading-[1.15] tracking-tight text-balance">
              {aboutConfig?.title || 'A Journey of Compassionate Veterinary Seva'}
            </h2>
          </ScrollReveal>
        </div>

        {/* 
          Balanced 2-Column Grid on Desktop (lg+):
          - lg:items-stretch ensures both columns start and end at the exact same visual line
          - Clean rectangular visual boundary with top and bottom alignment
        */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-10 xl:gap-12 lg:items-stretch">
          
          {/* =============================================================== */}
          {/* COLUMN 1 (LEFT): Illustration & Accreditation Badge             */}
          {/* =============================================================== */}
          <div className="w-full h-full flex flex-col">
            <ScrollReveal animation="fade-up" delay={120} reverseOnScrollUp={false} className="h-full flex flex-col flex-1">
              <div className="relative rounded-2xl sm:rounded-3xl overflow-hidden border border-[#1a3d1a]/15 shadow-xs hover:shadow-md transition-shadow duration-300 bg-[#EDE4D3] group w-full h-full flex-1 flex flex-col justify-between min-h-[260px] sm:min-h-[300px]">
                
                {/* Visual Artwork Container: expands to naturally fill the available card area */}
                <div className="relative flex-1 w-full min-h-[220px] flex items-center justify-center p-3 sm:p-5 overflow-hidden bg-[#EDE4D3]">
                  <SvccArtwork
                    variant="gaushala"
                    className="w-full h-full max-h-[440px] object-contain object-center transition-transform duration-700 ease-out group-hover:scale-102"
                  />
                </div>

                {/* Overlaid Institutional Seal Badge at Bottom-Left */}
                <div className="absolute bottom-3 left-3 sm:bottom-4 sm:left-4 bg-[#1a3d1a]/95 backdrop-blur-md text-[#EFFDF0] px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl border border-white/15 flex items-center gap-2 shadow-md z-10 pointer-events-none">
                  <Heart className="w-3.5 h-3.5 text-[#E86A10] animate-pulse shrink-0" />
                  <span className="text-xs font-medium tracking-wide">
                    Established 2009 · Pure Veterinary Charity
                  </span>
                </div>
              </div>
            </ScrollReveal>
          </div>

          {/* =============================================================== */}
          {/* COLUMN 2 (RIGHT): Desktop Header + Narrative + Cards + Action   */}
          {/* =============================================================== */}
          <div className="w-full h-full flex flex-col justify-between">
            
            {/* Top Block: Desktop Header + Description Paragraphs */}
            <div className="space-y-3 sm:space-y-3.5">
              
              {/* Desktop Header: shown only on lg+ to maintain unified column flex flow */}
              <div className="hidden lg:block">
                <ScrollReveal animation="fade-in" delay={80} reverseOnScrollUp={false}>
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#E86A10] shrink-0" />
                    <span className="text-[12px] sm:text-[13px] font-semibold uppercase tracking-wider text-[#6F8F72]">
                      {aboutConfig?.eyebrow || 'About Sai Vet Care Clinic'}
                    </span>
                  </div>
                </ScrollReveal>

                <ScrollReveal animation="fade-up" delay={140} reverseOnScrollUp={false}>
                  <h2 className="font-serif-display text-[#1a3d1a] text-[clamp(26px,2.6vw,38px)] font-normal leading-[1.14] tracking-tight text-balance">
                    {aboutConfig?.title || 'A Journey of Compassionate Veterinary Seva'}
                  </h2>
                </ScrollReveal>
              </div>

              {/* Lead Paragraph */}
              <ScrollReveal animation="fade-up" delay={200} reverseOnScrollUp={false}>
                <p className="text-[15px] sm:text-[16px] text-[#1a3d1a] font-medium leading-[1.6] opacity-100">
                  {aboutConfig?.description ||
                    'Established in 2009 under the inspiration and initiative of Dr. Chandra Bhanu Satpathy Ji, whose deep compassion for animals led to the creation of a dedicated centre rooted in the belief that every living being deserves care and dignity.'}
                </p>
              </ScrollReveal>

              {/* Secondary Narrative Paragraph */}
              <ScrollReveal animation="fade-up" delay={240} reverseOnScrollUp={false}>
                {aboutConfig?.content ? (
                  <div
                    dangerouslySetInnerHTML={{ __html: aboutConfig.content }}
                    className="text-[14px] sm:text-[15px] text-[#1a3d1a]/80 font-normal leading-[1.6] opacity-100 prose prose-sm max-w-none"
                  />
                ) : (
                  <p className="text-[14px] sm:text-[15px] text-[#1a3d1a]/80 font-normal leading-[1.6] opacity-100">
                    What began as a small veterinary centre operating from rented premises has grown into a well-recognised institution with dedicated OPD, examination room, and operation theatre within temple premises. Operating under the aegis of Shri Shirdi Sai Global Foundation through Shri Sai Karuna Sansthan, we provide structured veterinary care, surgery, and free medicines across Moradabad.
                  </p>
                )}
              </ScrollReveal>
            </div>

            {/* Bottom Block: 4 Feature Cards (2x2) + Foundation Story Link */}
            <div className="space-y-3 sm:space-y-3.5 pt-3 sm:pt-4">
              
              {/* 4 Feature Cards in a Clean 2x2 Grid */}
              <ScrollReveal animation="fade-up" delay={280} reverseOnScrollUp={false}>
                <div className="grid grid-cols-2 gap-2.5 sm:gap-3 items-stretch">
                  <div className="flex items-center gap-2.5 sm:gap-3 p-2.5 sm:p-3 rounded-xl sm:rounded-2xl bg-[#EFFDF0] border border-[#1a3d1a]/10 hover:border-[#6F8F72]/50 transition-colors h-full">
                    <CheckCircle2 className="w-4.5 h-4.5 text-[#6F8F72] shrink-0" />
                    <span className="text-xs sm:text-sm font-medium text-[#1a3d1a] leading-snug">
                      100% Free Treatment for Needy Animals
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5 sm:gap-3 p-2.5 sm:p-3 rounded-xl sm:rounded-2xl bg-[#EFFDF0] border border-[#1a3d1a]/10 hover:border-[#6F8F72]/50 transition-colors h-full">
                    <CheckCircle2 className="w-4.5 h-4.5 text-[#6F8F72] shrink-0" />
                    <span className="text-xs sm:text-sm font-medium text-[#1a3d1a] leading-snug">
                      Dedicated OPD & Operation Theatre
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5 sm:gap-3 p-2.5 sm:p-3 rounded-xl sm:rounded-2xl bg-[#EFFDF0] border border-[#1a3d1a]/10 hover:border-[#6F8F72]/50 transition-colors h-full">
                    <CheckCircle2 className="w-4.5 h-4.5 text-[#6F8F72] shrink-0" />
                    <span className="text-xs sm:text-sm font-medium text-[#1a3d1a] leading-snug">
                      7 Partner Gaushalas (2,000+ Cattle)
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5 sm:gap-3 p-2.5 sm:p-3 rounded-xl sm:rounded-2xl bg-[#EFFDF0] border border-[#1a3d1a]/10 hover:border-[#6F8F72]/50 transition-colors h-full">
                    <CheckCircle2 className="w-4.5 h-4.5 text-[#6F8F72] shrink-0" />
                    <span className="text-xs sm:text-sm font-medium text-[#1a3d1a] leading-snug">
                      5 Moradabad Regional Centres
                    </span>
                  </div>
                </div>
              </ScrollReveal>

              {/* Read Our Full Foundation Story Link */}
              <ScrollReveal animation="fade-up" delay={320} reverseOnScrollUp={false}>
                <div className="pt-0.5">
                  <button
                    onClick={handleLearnMore}
                    className="group inline-flex items-center gap-2 text-[14px] sm:text-[15px] font-semibold text-[#1a3d1a] hover:text-[#E86A10] transition-colors cursor-pointer pb-0.5 border-b border-[#1a3d1a]/25 hover:border-[#E86A10]"
                    aria-label="Read our full foundation story"
                  >
                    <span>Read Our Full Foundation Story</span>
                    <ArrowRight className="w-4 h-4 text-[#E86A10] transition-transform duration-300 group-hover:translate-x-1" />
                  </button>
                </div>
              </ScrollReveal>

            </div>

          </div>

        </div>
      </SectionContainer>
    </section>
  );
};
