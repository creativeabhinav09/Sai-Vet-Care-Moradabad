import React, { useState } from 'react';
import { ArrowUpRight, Play, Star, ArrowRight, Plus, ChevronDown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { ImageParallax } from './ImageParallax';

import { useCms } from '../cms/CmsContext';

interface HeroSectionProps {
  onNavigateToSeva?: () => void;
  onNavigateToContact?: () => void;
  onNavigateToAbout?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onNavigateToSeva,
  onNavigateToContact,
  onNavigateToAbout,
}) => {
  const navigate = useNavigate();
  const [isPlayingVideo, setIsPlayingVideo] = useState(false);
  const { getSection } = useCms();
  const heroConfig = getSection('home', 'hero');

  if (heroConfig?.enabled === false) {
    return null;
  }

  const handleExplore = () => {
    const sevaElement = document.getElementById('seva');
    if (sevaElement) {
      sevaElement.scrollIntoView({ behavior: 'smooth' });
    } else if (onNavigateToSeva) {
      onNavigateToSeva();
    } else {
      navigate('/seva');
    }
  };

  const ASSETS = {
    avatar: 'https://polo-pecan-73837341.figma.site/_assets/v11/e62173d41f91350a59628e8a9a55ae078a886fb9.png?w=128',
    productCard: 'https://polo-pecan-73837341.figma.site/_assets/v11/3e5158dad63d392ade022e81890edc9f54d750bc.png',
    videoCard: 'https://polo-pecan-73837341.figma.site/_assets/v11/76be6ec3a93a703b15e9cc01e764a4e3f9d7d2c0.png',
    bottomLeft: 'https://polo-pecan-73837341.figma.site/_assets/v11/8d44b25186ef45a5789c74668fb781cea4e1ff49.png',
    bottomCenter: 'https://polo-pecan-73837341.figma.site/_assets/v11/96745c4e72ad5c5208e53a885df797fd82cd854a.png?h=1024',
    bottomRight: 'https://polo-pecan-73837341.figma.site/_assets/v11/81bd2e7a66b58f3d8f3ad78fd1ebf01af8dfdee1.png',
  };

  return (
    <section className="relative w-full h-[clamp(480px,70vh,660px)] min-h-[480px] max-h-[660px] flex flex-col overflow-hidden bg-[#EFFDF0] select-none border-b border-[#1a3d1a]/10">
      
      {/* ========================================================================= */}
      {/* DESKTOP LAYOUT (lg+)                                                      */}
      {/* ========================================================================= */}
      <div className="hidden lg:block relative w-full h-full">
        
        {/* Text Layer (z-5): Centered, px-12 pt-[1.2rem] xl:pt-[1.8rem] */}
        <div className="relative z-5 text-center px-12 pt-[1.2rem] xl:pt-[1.8rem]">
          {heroConfig?.eyebrow && (
            <div className="text-xs font-semibold tracking-wider uppercase text-[#E86A10] mb-1.5 animate-fade-in">
              {heroConfig.eyebrow}
            </div>
          )}
          <h1 className="font-serif-display text-[#1a3d1a] text-[clamp(44px,5vw,76px)] leading-[0.96] tracking-tight">
            {heroConfig?.title && heroConfig.title !== 'Everything Your Pets Love' ? (
              <span className="block animate-word-pop delay-200">{heroConfig.title}</span>
            ) : (
              <>
                <span className="block">
                  <span className="inline-block animate-word-pop delay-200">
                    Everything
                  </span>
                </span>
                <span className="block mt-1">
                  <span className="inline-block mr-3 animate-word-pop delay-350">
                    Your
                  </span>
                  <span className="inline-block mr-3 animate-word-pop delay-500">
                    Pets
                  </span>
                  <span className="inline-block animate-word-pop delay-650">
                    Love
                  </span>
                </span>
              </>
            )}
          </h1>
          {heroConfig?.subtitle && (
            <p className="text-xs sm:text-sm font-medium text-[#1a3d1a]/80 max-w-lg mx-auto mt-2 animate-fade-up">
              {heroConfig.subtitle}
            </p>
          )}
        </div>

        {/* Left Product Card: Absolutely positioned top-[16px] left-8 with gentle floating animation */}
        <div
          className="absolute top-[16px] xl:top-[22px] left-8 xl:left-12 z-20 animate-slide-in-left delay-600 animate-float-gentle"
          style={{ width: 'clamp(140px,11vw,210px)' }}
        >
          <div className="relative aspect-[260/257] rounded-2xl overflow-hidden shadow-lg group cursor-pointer bg-[#e4f7e5] border border-white/60">
            <img
              src={ASSETS.productCard}
              alt="Sai Vet Care & Pet House"
              className="w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-108"
            />
            {/* Arrow button bottom-right corner */}
            <button
              onClick={() => navigate('/seva')}
              className="absolute bottom-2.5 right-2.5 w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-[#1a3d1a] hover:bg-[#2a5a2a] text-white flex items-center justify-center shadow-md transition-all duration-300 group-hover:scale-115 group-hover:bg-[#E86A10] cursor-pointer"
              aria-label="View Cat House & Care Seva"
            >
              <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
          </div>
          <div className="mt-1.5">
            <div className="text-gray-700 text-[clamp(11px,0.9vw,13px)] font-medium">
              Cozy Cat House · SVCC
            </div>
            <div className="text-[#1a3d1a] font-bold text-[clamp(13px,1.1vw,16px)]">
              $49.99
            </div>
          </div>
        </div>

        {/* Right Video Card: Absolutely positioned top-[16px] right-8 with gentle floating animation */}
        <div
          className="absolute top-[16px] xl:top-[22px] right-8 xl:right-12 z-20 animate-slide-in-right delay-700 animate-float-gentle-rev"
          style={{ width: 'clamp(105px,8vw,150px)' }}
        >
          <div className="relative aspect-[177/287] rounded-2xl overflow-hidden shadow-lg group cursor-pointer bg-[#e4f7e5] border border-white/60">
            <img
              src={ASSETS.videoCard}
              alt="Watch Product Reviews & Rescue Chronicles"
              className="w-full h-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-108"
            />
            {/* Play button with continuous beacon pulse */}
            <button
              onClick={() => setIsPlayingVideo(true)}
              className="absolute bottom-8 left-1/2 -translate-x-1/2 w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-[#1a3d1a] hover:bg-[#E86A10] text-white flex items-center justify-center shadow-lg transition-all duration-300 group-hover:scale-115 cursor-pointer animate-pulse-beacon"
              aria-label="Play video reviews"
            >
              <Play className="w-3.5 h-3.5 fill-white translate-x-0.5" />
            </button>
          </div>
          <div className="mt-1.5">
            <p className="text-[#1a3d1a] text-[clamp(9.5px,0.75vw,11px)] font-medium leading-tight text-center">
              Watch Product Reviews on TikTok and YouTube
            </p>
          </div>
        </div>

        {/* Bottom 3 Images: Grouped naturally as a cohesive, prominent pet trio with close proximity */}
        <div className="absolute bottom-0 left-0 right-0 z-10 flex items-end justify-center pointer-events-none overflow-visible">
          <div className="flex items-end justify-center -space-x-8 sm:-space-x-12 lg:-space-x-14 xl:-space-x-18 w-full max-w-[960px] lg:max-w-[1080px] xl:max-w-[1220px] px-2 sm:px-4">
            
            {/* Left Image (Dachshund) */}
            <div className="flex-1 flex items-end justify-end overflow-visible animate-photo-reveal delay-700 pointer-events-auto group relative z-1">
              <ImageParallax speed={0.012} maxOffset={8} origin="bottom" scale="scale-100" overflowHidden={false}>
                <img
                  src={ASSETS.bottomLeft}
                  alt="Happy pet companion — Dachshund"
                  className="w-auto h-[clamp(240px,36vh,350px)] lg:h-[clamp(270px,39vh,380px)] xl:h-[clamp(300px,43vh,410px)] max-w-none block object-contain object-bottom transition-transform duration-700 ease-out group-hover:scale-102 origin-bottom drop-shadow-sm"
                />
              </ImageParallax>
            </div>

            {/* Center Image (Golden Retriever) - Complete head, ears, and face prominent, bold and majestic */}
            <div className="flex-[1.3] flex items-end justify-center overflow-visible animate-photo-reveal delay-600 pointer-events-auto relative z-10 group">
              <ImageParallax speed={0.012} maxOffset={8} origin="bottom" scale="scale-100" overflowHidden={false}>
                <img
                  src={ASSETS.bottomCenter}
                  alt="Best pet care and products — Golden Retriever"
                  className="w-auto h-[clamp(310px,46vh,440px)] lg:h-[clamp(340px,50vh,480px)] xl:h-[clamp(380px,55vh,520px)] max-w-none block object-contain object-bottom transition-transform duration-700 ease-out group-hover:scale-102 origin-bottom drop-shadow-md"
                />
              </ImageParallax>
            </div>

            {/* Right Image (Tabby Cat) */}
            <div className="flex-1 flex items-end justify-start overflow-visible animate-photo-reveal delay-800 pointer-events-auto group relative z-1">
              <ImageParallax speed={0.012} maxOffset={8} origin="bottom" scale="scale-100" overflowHidden={false}>
                <img
                  src={ASSETS.bottomRight}
                  alt="Veterinary rescued companion — Tabby Cat"
                  className="w-auto h-[clamp(240px,36vh,350px)] lg:h-[clamp(270px,39vh,380px)] xl:h-[clamp(300px,43vh,410px)] max-w-none block object-contain object-bottom transition-transform duration-700 ease-out group-hover:scale-102 origin-bottom drop-shadow-sm"
                />
              </ImageParallax>
            </div>

          </div>
        </div>

        {/* Overlays on Bottom Images (Positioned with bottom: clamp(16px, 3.5vh, 44px)) */}
        <div
          className="absolute left-0 right-0 z-20 px-8 xl:px-12 flex items-end justify-between pointer-events-none"
          style={{ bottom: 'clamp(16px, 3.5vh, 44px)' }}
        >
          {/* Left Overlay */}
          <div className="flex items-center gap-3 bg-white/95 backdrop-blur-md px-4 py-2.5 rounded-full shadow-xl border border-[#1a3d1a]/10 pointer-events-auto animate-scale-in delay-1000 transition-transform duration-300 hover:scale-105">
            <div className="flex -space-x-2">
              <img
                src={ASSETS.avatar}
                alt="Happy pet owner"
                className="w-8 h-8 rounded-full border-2 border-white object-cover"
              />
              <div className="w-8 h-8 rounded-full bg-[#1a3d1a] border-2 border-white text-white flex items-center justify-center">
                <Plus className="w-3.5 h-3.5" />
              </div>
            </div>
            <div>
              <div className="text-sm font-bold text-[#1a3d1a] leading-none">98K+</div>
              <div className="text-[10px] text-gray-500 font-medium">Happy Pets Treated</div>
            </div>
          </div>

          {/* Center Overlay */}
          <div className="text-center pointer-events-auto animate-fade-up delay-1100">
            <h2 className="text-white text-xl xl:text-2xl font-serif-display drop-shadow-md mb-2.5">
              Best Products for Your Pet
            </h2>
            <button
              onClick={handleExplore}
              className="btn-micro inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#E86A10] hover:bg-[#d45e0d] text-white text-sm font-semibold shadow-2xl cursor-pointer"
            >
              <span>Explore Products</span>
              <ArrowRight className="w-4 h-4 btn-icon-move" />
            </button>
            <div
              onClick={handleExplore}
              className="mt-2 text-[11px] text-white/90 drop-shadow-sm font-medium flex items-center justify-center gap-1 cursor-pointer transition-opacity hover:opacity-100"
            >
              <span>Scroll to explore full clinic</span>
              <ChevronDown className="w-3.5 h-3.5 animate-bounce" />
            </div>
          </div>

          {/* Right Overlay */}
          <div className="flex items-center gap-2 bg-white/95 backdrop-blur-md px-4 py-2.5 rounded-full shadow-xl border border-[#1a3d1a]/10 pointer-events-auto animate-scale-in delay-1200 transition-transform duration-300 hover:scale-105">
            <Star className="w-5 h-5 fill-[#E86A10] text-[#E86A10]" />
            <div>
              <div className="text-sm font-bold text-[#1a3d1a] leading-none">4.6</div>
              <div className="text-[10px] text-gray-500 font-medium">Customer Rating</div>
            </div>
          </div>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* TABLET LAYOUT (md to lg)                                                 */}
      {/* ========================================================================= */}
      <div className="hidden md:flex lg:hidden flex-col justify-between relative w-full h-full">
        <div className="text-center pt-8 px-6 z-5">
          <h1 className="font-serif-display text-[#1a3d1a] text-6xl sm:text-7xl leading-[0.98] tracking-tight">
            <span className="inline-block animate-word-pop delay-200">Everything</span>{' '}
            <span className="inline-block animate-word-pop delay-400">Your</span>{' '}
            <span className="inline-block animate-word-pop delay-550">Pets</span>{' '}
            <span className="inline-block animate-word-pop delay-700">Love</span>
          </h1>
        </div>

        <div className="absolute top-[80px] left-4 z-20 w-[150px] animate-slide-in-left delay-600 animate-float-gentle">
          <div className="aspect-square rounded-xl overflow-hidden shadow-md bg-white">
            <img src={ASSETS.productCard} alt="Cat House" className="w-full h-full object-cover object-center" />
          </div>
          <div className="text-xs font-semibold text-[#1a3d1a] mt-1">Cozy Cat House</div>
          <div className="text-xs font-bold text-[#1a3d1a]">$49.99</div>
        </div>

        <div className="absolute top-[80px] right-4 z-20 w-[110px] animate-slide-in-right delay-700 animate-float-gentle-rev">
          <div className="aspect-[3/4] rounded-xl overflow-hidden shadow-md bg-white relative">
            <img src={ASSETS.videoCard} alt="Reviews" className="w-full h-full object-cover object-top" />
            <button
              onClick={() => setIsPlayingVideo(true)}
              className="absolute bottom-2 left-1/2 -translate-x-1/2 w-7 h-7 rounded-full bg-[#1a3d1a] text-white flex items-center justify-center shadow-xs animate-pulse-beacon"
            >
              <Play className="w-3 h-3 fill-white" />
            </button>
          </div>
          <div className="text-[10px] font-medium text-center text-gray-700 mt-1">TikTok Reviews</div>
        </div>

        <div className="relative z-10 flex items-end justify-center pointer-events-none mt-auto overflow-visible">
          <div className="flex items-end justify-center -space-x-8 sm:-space-x-12 w-full max-w-[760px] mx-auto px-4">
            <div className="flex-1 flex items-end justify-end overflow-visible">
              <ImageParallax speed={0.012} maxOffset={8} origin="bottom" scale="scale-100" overflowHidden={false}>
                <img
                  src={ASSETS.bottomLeft}
                  alt="Pet left — Dachshund"
                  className="w-auto h-[clamp(210px,33vh,290px)] max-w-none block object-contain object-bottom origin-bottom drop-shadow-sm"
                />
              </ImageParallax>
            </div>
            <div className="flex-[1.3] flex items-end justify-center overflow-visible relative z-10">
              <ImageParallax speed={0.012} maxOffset={8} origin="bottom" scale="scale-100" overflowHidden={false}>
                <img
                  src={ASSETS.bottomCenter}
                  alt="Pet center — Golden Retriever"
                  className="w-auto h-[clamp(270px,42vh,370px)] max-w-none block object-contain object-bottom origin-bottom drop-shadow-md"
                />
              </ImageParallax>
            </div>
            <div className="flex-1 flex items-end justify-start overflow-visible">
              <ImageParallax speed={0.012} maxOffset={8} origin="bottom" scale="scale-100" overflowHidden={false}>
                <img
                  src={ASSETS.bottomRight}
                  alt="Pet right — Tabby Cat"
                  className="w-auto h-[clamp(210px,33vh,290px)] max-w-none block object-contain object-bottom origin-bottom drop-shadow-sm"
                />
              </ImageParallax>
            </div>
          </div>
        </div>

        <div className="absolute bottom-6 left-4 right-4 z-20 flex items-end justify-between pointer-events-none">
          <div className="bg-white/95 px-3 py-1.5 rounded-full shadow-md flex items-center gap-2 pointer-events-auto">
            <span className="text-xs font-bold text-[#1a3d1a]">98K+</span>
            <span className="text-[10px] text-gray-500">Pets</span>
          </div>

          <div className="pointer-events-auto text-center">
            <button
              onClick={handleExplore}
              className="px-5 py-2.5 rounded-full bg-[#E86A10] text-white text-xs font-semibold shadow-lg flex items-center gap-1.5"
            >
              <span>Explore Products</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="bg-white/95 px-3 py-1.5 rounded-full shadow-md flex items-center gap-1.5 pointer-events-auto">
            <Star className="w-4 h-4 fill-[#E86A10] text-[#E86A10]" />
            <span className="text-xs font-bold text-[#1a3d1a]">4.6</span>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MOBILE LAYOUT (below md)                                                 */}
      {/* ========================================================================= */}
      <div className="flex md:hidden flex-col justify-between h-full overflow-hidden pt-2 pb-3 px-4">
        <div className="text-center pt-1">
          <h1 className="font-serif-display text-[#1a3d1a] text-[34px] leading-[1.02] tracking-tight">
            Everything Your Pets Love
          </h1>
          <p className="text-[11px] text-gray-600 mt-1 max-w-xs mx-auto">
            Compassionate Veterinary Seva & Premium Pet Essentials by Sai Vet Care Clinic.
          </p>
          <div className="mt-2.5">
            <button
              onClick={handleExplore}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-[#E86A10] text-white text-xs font-semibold shadow-md"
            >
              <span>Explore Products</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="flex gap-2.5 my-2">
          <div className="flex-1 bg-white p-2 rounded-xl shadow-xs border border-[#1a3d1a]/10">
            <div className="aspect-square rounded-lg overflow-hidden bg-[#EFFDF0] relative mb-1">
              <img src={ASSETS.productCard} alt="Cat house" className="w-full h-full object-cover object-center" />
              <button
                onClick={() => navigate('/seva')}
                className="absolute bottom-1 right-1 w-5 h-5 rounded-full bg-[#1a3d1a] text-white flex items-center justify-center text-[10px]"
              >
                <ArrowUpRight className="w-2.5 h-2.5" />
              </button>
            </div>
            <div className="text-[10px] font-medium text-gray-800 truncate">Cozy Cat House</div>
            <div className="text-xs font-bold text-[#1a3d1a]">$49.99</div>
          </div>

          <div className="flex-1 bg-white p-2 rounded-xl shadow-xs border border-[#1a3d1a]/10">
            <div className="aspect-[3/4] rounded-lg overflow-hidden bg-[#EFFDF0] relative mb-1">
              <img src={ASSETS.videoCard} alt="Video" className="w-full h-full object-cover object-top" />
              <button
                onClick={() => setIsPlayingVideo(true)}
                className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-5 h-5 rounded-full bg-[#1a3d1a] text-white flex items-center justify-center"
              >
                <Play className="w-2 h-2 fill-white" />
              </button>
            </div>
            <div className="text-[9px] font-medium text-gray-700 leading-tight">TikTok Reviews</div>
          </div>
        </div>

        <div className="flex items-center justify-around bg-white/90 backdrop-blur-xs py-1.5 px-3 rounded-lg border border-[#1a3d1a]/10 my-1">
          <div className="flex items-center gap-1.5">
            <img src={ASSETS.avatar} alt="Avatar" className="w-5 h-5 rounded-full object-cover object-center" />
            <span className="text-[11px] font-bold text-[#1a3d1a]">98K+ Pets</span>
          </div>
          <div className="h-3 w-px bg-gray-200" />
          <div className="flex items-center gap-1">
            <Star className="w-3.5 h-3.5 fill-[#E86A10] text-[#E86A10]" />
            <span className="text-[11px] font-bold text-[#1a3d1a]">4.6 Rating</span>
          </div>
        </div>

        <div className="flex items-end justify-between -mx-2 -mb-2 pt-1 overflow-visible">
          <div className="flex-1 flex items-end justify-center overflow-visible">
            <img
              src={ASSETS.bottomLeft}
              alt="Pet left — Dachshund"
              className="w-auto h-auto max-w-full max-h-[min(26vh,165px)] block object-contain object-bottom"
            />
          </div>
          <div className="flex-[1.265] flex items-end justify-center overflow-visible">
            <img
              src={ASSETS.bottomCenter}
              alt="Pet center — Golden Retriever"
              className="w-auto h-auto max-w-full max-h-[min(32vh,205px)] block object-contain object-bottom"
            />
          </div>
          <div className="flex-1 flex items-end justify-center overflow-visible">
            <img
              src={ASSETS.bottomRight}
              alt="Pet right — Tabby Cat"
              className="w-auto h-auto max-w-full max-h-[min(26vh,165px)] block object-contain object-bottom"
            />
          </div>
        </div>

      </div>

      {/* Video Modal if clicked */}
      {isPlayingVideo && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-fade-in"
          onClick={() => setIsPlayingVideo(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-[#1a3d1a]/20 animate-scale-in"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <span className="text-xs font-bold uppercase tracking-wider text-[#E86A10]">
                SVCC Video Showcase
              </span>
              <button
                onClick={() => setIsPlayingVideo(false)}
                className="text-xs font-bold text-gray-500 hover:text-gray-900"
              >
                ✕ Close
              </button>
            </div>
            <div className="aspect-[9/16] max-h-[60vh] w-full rounded-xl overflow-hidden my-4 bg-gray-900 relative flex items-center justify-center">
              <img
                src={ASSETS.videoCard}
                alt="Video poster"
                className="w-full h-full object-contain object-center opacity-90"
              />
              <div className="absolute text-center text-white px-4">
                <Play className="w-12 h-12 fill-white text-white mx-auto mb-2 opacity-90" />
                <p className="text-xs font-medium">Customer Pet Reviews & Rescued Stories</p>
              </div>
            </div>
            <p className="text-xs text-gray-600 text-center">
              Featured on YouTube & TikTok community animal welfare channels.
            </p>
          </div>
        </div>
      )}

    </section>
  );
};
