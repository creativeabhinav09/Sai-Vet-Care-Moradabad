import React, { useState } from 'react';
import {
  Phone,
  MapPin,
  Clock,
  Mail,
  Send,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  ShieldCheck,
  Radio,
} from 'lucide-react';
import { ScrollReveal } from './ScrollReveal';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from './SectionContainer';
import { useCms } from '../cms/CmsContext';

export const ContactSection: React.FC = () => {
  const { data } = useCms();
  const settings = data?.settings;

  const { ref: sectionRef, isIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    location: '',
    animalType: 'Stray Canine',
    emergencyNature: 'Accident Trauma',
    message: '',
  });

  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.phone.trim() || !formData.location.trim()) {
      setStatus('error');
      setErrorMessage('Please provide your name, phone number, and animal location so our ambulance unit can dispatch immediately.');
      return;
    }

    setStatus('submitting');

    setTimeout(() => {
      setStatus('success');
      setFormData({
        name: '',
        phone: '',
        location: '',
        animalType: 'Stray Canine',
        emergencyNature: 'Accident Trauma',
        message: '',
      });
    }, 600);
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      style={{
        paddingTop: 'clamp(28px, 3.5vw, 44px)',
        paddingBottom: 'clamp(28px, 3.5vw, 44px)',
      }}
      className="w-full bg-[#EFFDF0] relative"
    >
      <SectionContainer>
        {/* Section Heading & Subtitle */}
        <div className="text-center max-w-3xl mx-auto mb-8 sm:mb-10">
          <ScrollReveal animation="fade-in" delay={100} reverseOnScrollUp={false}>
            <span className="label-eyebrow text-[#6F8F72]">
              Immediate Emergency Response & Seva Inquiries
            </span>
          </ScrollReveal>

          <ScrollReveal animation="text-reveal" delay={180} reverseOnScrollUp={false}>
            <h2 className="section-h2 text-[#1a3d1a] mt-2">
              Contact Sai Vet Care Clinic
            </h2>
          </ScrollReveal>

          <ScrollReveal animation="fade-up" delay={260} reverseOnScrollUp={false}>
            <p className="body-lead mt-3 text-[#1a3d1a]/85 mx-auto">
              If you encounter an injured animal, critical case, or require gaushala clinical support, reach our 24/7 emergency dispatch immediately.
            </p>
          </ScrollReveal>

          {/* Live Fleet Status Beacon */}
          <ScrollReveal animation="fade-up" delay={320} reverseOnScrollUp={false}>
            <div className="mt-3.5 inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-[#1a3d1a]/15 shadow-2xs">
              <span className="w-2.5 h-2.5 rounded-full bg-[#6F8F72] animate-pulse-beacon-green" />
              <span className="text-xs sm:text-sm font-semibold text-[#1a3d1a]">
                Ambulance Fleet Status: Active & On Standby 24/7
              </span>
            </div>
          </ScrollReveal>
        </div>

        {/* 
          REBUILT TWO-COLUMN RESPONSIVE LAYOUT
          LEFT COLUMN              RIGHT COLUMN
          [ Content Block 1 ]      [ Form Block 1 ]
          [ Content Block 2 ]      [ SLA Block 2 ]
          - align-items: start ensures identical top alignment
          - Controlled gap-8 between columns, gap-6 between blocks
          - Natural height on all content blocks (no fixed min-heights or artificial stretching)
          - Symmetrical bottom baseline without empty space
        */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT COLUMN: Emergency Helpline Card + Respectful Seva Statement */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            
            {/* Left Content Block 1: Emergency 24/7 Helpline Card */}
            <ScrollReveal animation="fade-up" delay={350} reverseOnScrollUp={false}>
              <div className="bg-white rounded-3xl p-6 sm:p-7 border border-[#1a3d1a]/15 shadow-sm">
                <div className="flex items-center justify-between pb-3.5 border-b border-[#1a3d1a]/10 mb-5">
                  <h3 className="sub-h3 text-[#1a3d1a]">
                    Emergency 24/7 Helpline
                  </h3>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-[#EFFDF0] text-[#1a3d1a] border border-[#1a3d1a]/15">
                    Live Duty Desk
                  </span>
                </div>

                <p className="card-body-text text-[#1a3d1a]/85 mb-5">
                  Our round-the-clock emergency team and mobile ambulance fleet respond swiftly across Shirdi and adjoining rural tehsils.
                </p>

                <div className="space-y-4">
                  {/* Hotline */}
                  <div className="flex items-start gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-[#1a3d1a] text-[#EFFDF0] flex items-center justify-center shrink-0 shadow-xs">
                      <Phone className="w-5 h-5 text-[#E86A10]" />
                    </div>
                    <div>
                      <div className="label-eyebrow text-[#1a3d1a]">Emergency Hotline</div>
                      <div className="text-base sm:text-lg font-bold text-[#1a3d1a] font-mono mt-0.5">
                        {settings?.emergencyPhone || '+91 94220 89108 / +91 2423 255 108'}
                      </div>
                      <div className="text-xs text-gray-600 font-medium">Direct line to trauma surgical duty room</div>
                    </div>
                  </div>

                  {/* Address */}
                  <div className="flex items-start gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-[#6F8F72]/20 text-[#1a3d1a] flex items-center justify-center shrink-0">
                      <MapPin className="w-5 h-5 text-[#1a3d1a]" />
                    </div>
                    <div>
                      <div className="label-eyebrow text-[#1a3d1a]">Hospital Address</div>
                      <div className="text-sm font-medium text-[#1a3d1a] mt-0.5 leading-snug">
                        {settings?.address || 'Sai Vet Care Clinic, Shirdi-Kopargaon Road, Near Shrine Perimeter, Maharashtra 423109'}
                      </div>
                    </div>
                  </div>

                  {/* Hours */}
                  <div className="flex items-start gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-[#EDE4D3] text-[#1a3d1a] flex items-center justify-center shrink-0">
                      <Clock className="w-5 h-5 text-[#1a3d1a]" />
                    </div>
                    <div>
                      <div className="label-eyebrow text-[#1a3d1a]">Operational Hours</div>
                      <div className="text-sm font-medium text-[#1a3d1a] mt-0.5">
                        Emergency Ward: Open 24 Hours, 365 Days
                      </div>
                      <div className="text-xs text-gray-600 font-medium">Outpatient & Gaushala Camps: 8:00 AM – 8:00 PM</div>
                    </div>
                  </div>

                  {/* Email */}
                  <div className="flex items-start gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-[#E86A10]/20 text-[#E86A10] flex items-center justify-center shrink-0">
                      <Mail className="w-5 h-5 text-[#E86A10]" />
                    </div>
                    <div>
                      <div className="label-eyebrow text-[#1a3d1a]">Seva Office Email</div>
                      <div className="text-sm font-medium text-[#1a3d1a] mt-0.5 font-mono">
                        {settings?.contactEmail || 'seva@saivetcareclinic.org'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </ScrollReveal>

            {/* Left Content Block 2: Dignity of Seva & Assurance Statement */}
            <ScrollReveal animation="fade-up" delay={420} reverseOnScrollUp={false}>
              <div className="p-5 rounded-3xl bg-white border border-[#1a3d1a]/15 shadow-xs flex flex-col gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#6F8F72]/20 flex items-center justify-center shrink-0 text-[#1a3d1a]">
                    <Sparkles className="w-4 h-4 text-[#6F8F72]" />
                  </div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#1a3d1a]">
                    Pure Charitable Undertaking
                  </h4>
                </div>
                <p className="text-xs sm:text-sm text-[#1a3d1a]/85 leading-relaxed font-medium">
                  Every animal received is accorded prompt, dignified treatment without any expectation of monetary remuneration. Zero billing or triage fee for strays.
                </p>
                <div className="pt-2 border-t border-[#1a3d1a]/10 flex items-center gap-2 text-xs text-[#1a3d1a] font-semibold">
                  <ShieldCheck className="w-4 h-4 text-[#6F8F72]" />
                  <span>Licensed Veterinarians on duty 24/7</span>
                </div>
              </div>
            </ScrollReveal>

          </div>

          {/* RIGHT COLUMN: Rapid Emergency Dispatch Form + Dispatch Coordination SLA */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            
            {/* Right Content Block 1: Rapid Emergency Dispatch Form Card */}
            <ScrollReveal animation="fade-up" delay={380} reverseOnScrollUp={false}>
              <div className="bg-white rounded-3xl p-6 sm:p-7 border border-[#1a3d1a]/15 shadow-sm">
                <div className="flex items-center justify-between pb-3.5 border-b border-gray-100 mb-5">
                  <h3 className="sub-h3 text-[#1a3d1a]">
                    24/7 Roadside Rescue Alert
                  </h3>
                  <span className="text-xs font-semibold px-3 py-1 rounded-full bg-[#E86A10]/15 text-[#E86A10] border border-[#E86A10]/30">
                    Priority Dispatch
                  </span>
                </div>

                {status === 'success' ? (
                  <div className="p-6 rounded-2xl bg-[#EFFDF0] border border-[#6F8F72] text-center space-y-3 animate-scale-in">
                    <div className="w-12 h-12 rounded-full bg-[#6F8F72] text-white flex items-center justify-center mx-auto shadow-sm">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <h4 className="text-lg font-serif font-bold text-[#1a3d1a]">
                      Distress Alert Broadcasted Successfully
                    </h4>
                    <p className="text-sm text-[#1a3d1a]/85 leading-relaxed max-w-md mx-auto">
                      Our on-duty veterinary ambulance dispatcher has received your alert. If critical, our team will phone you within 2–5 minutes for live GPS guidance.
                    </p>
                    <button
                      type="button"
                      onClick={() => setStatus('idle')}
                      className="mt-2 btn-text min-h-[44px] px-6 py-2.5 rounded-xl bg-[#1a3d1a] text-white text-xs font-semibold hover:bg-[#2a5a2a] cursor-pointer"
                    >
                      Report Another Incident
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    {status === 'error' && (
                      <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>{errorMessage}</span>
                      </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-[#1a3d1a] mb-1.5">
                          Your Full Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          placeholder="e.g. Ramesh Kulkarni"
                          className="w-full px-4 py-2.5 text-sm rounded-xl border border-gray-300 focus:outline-hidden focus:border-[#1a3d1a] focus:ring-1 focus:ring-[#1a3d1a] transition-all bg-[#EFFDF0]/30"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-[#1a3d1a] mb-1.5">
                          Contact Phone Number *
                        </label>
                        <input
                          type="tel"
                          required
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          placeholder="e.g. +91 98220 12345"
                          className="w-full px-4 py-2.5 text-sm rounded-xl border border-gray-300 focus:outline-hidden focus:border-[#1a3d1a] focus:ring-1 focus:ring-[#1a3d1a] transition-all bg-[#EFFDF0]/30 font-mono"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#1a3d1a] mb-1.5">
                        Animal Location / Landmark *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.location}
                        onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                        placeholder="e.g. Near Shirdi Temple Outer Gate 2 / Nimgaon Toll Plaza"
                        className="w-full px-4 py-2.5 text-sm rounded-xl border border-gray-300 focus:outline-hidden focus:border-[#1a3d1a] focus:ring-1 focus:ring-[#1a3d1a] transition-all bg-[#EFFDF0]/30"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-[#1a3d1a] mb-1.5">
                          Species / Animal Type
                        </label>
                        <select
                          value={formData.animalType}
                          onChange={(e) => setFormData({ ...formData, animalType: e.target.value })}
                          className="w-full px-4 py-2.5 text-sm rounded-xl border border-gray-300 focus:outline-hidden focus:border-[#1a3d1a] focus:ring-1 focus:ring-[#1a3d1a] transition-all bg-[#EFFDF0]/30 cursor-pointer"
                        >
                          <option value="Stray Canine">Stray Canine (Street Dog / Pup)</option>
                          <option value="Injured Cattle">Injured Cow / Bull / Calf</option>
                          <option value="Working Bullock">Working Bullock / Draft Animal</option>
                          <option value="Community Cat">Community Cat / Feline</option>
                          <option value="Avian / Bird">Avian / Wild Bird</option>
                          <option value="Other Creature">Other Distressed Creature</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-[#1a3d1a] mb-1.5">
                          Nature of Emergency
                        </label>
                        <select
                          value={formData.emergencyNature}
                          onChange={(e) => setFormData({ ...formData, emergencyNature: e.target.value })}
                          className="w-full px-4 py-2.5 text-sm rounded-xl border border-gray-300 focus:outline-hidden focus:border-[#1a3d1a] focus:ring-1 focus:ring-[#1a3d1a] transition-all bg-[#EFFDF0]/30 cursor-pointer"
                        >
                          <option value="Accident Trauma">Vehicular Accident / Severe Fracture</option>
                          <option value="Deep Maggot Wound">Severe Infection / Maggot Wound</option>
                          <option value="Exhaustion / Bloat">Acute Dehydration / Heatstroke / Colic</option>
                          <option value="Poisoning / Toxins">Suspected Poisoning / Seizure</option>
                          <option value="Cruelty / Abandonment">Cruelty Intervention / Tied Abandonment</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#1a3d1a] mb-1.5">
                        Additional Condition Notes (Optional)
                      </label>
                      <textarea
                        rows={2}
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        placeholder="Describe visible wounds, consciousness, whether animal is trapped or near traffic..."
                        className="w-full px-4 py-2.5 text-sm rounded-xl border border-gray-300 focus:outline-hidden focus:border-[#1a3d1a] focus:ring-1 focus:ring-[#1a3d1a] transition-all bg-[#EFFDF0]/30 resize-none"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={status === 'submitting'}
                      className="w-full btn-text min-h-[46px] py-3 px-6 rounded-xl bg-[#1a3d1a] hover:bg-[#2a5a2a] text-white font-semibold flex items-center justify-center gap-2 cursor-pointer transition-all duration-300 shadow-md"
                    >
                      {status === 'submitting' ? (
                        <span>Broadcasting Dispatch Alert...</span>
                      ) : (
                        <>
                          <Send className="w-4 h-4 btn-icon-move text-[#E86A10]" />
                          <span>Dispatch Emergency Animal Ambulance</span>
                        </>
                      )}
                    </button>
                  </form>
                )}
              </div>
            </ScrollReveal>

            {/* Right Content Block 2: Live Dispatch SLA & Tracking Coordination */}
            <ScrollReveal animation="fade-up" delay={440} reverseOnScrollUp={false}>
              <div className="p-4 sm:p-5 rounded-3xl bg-white border border-[#1a3d1a]/15 shadow-xs flex items-center justify-between gap-3 text-xs text-[#1a3d1a]">
                <div className="flex items-center gap-2.5">
                  <Radio className="w-4 h-4 text-[#E86A10] shrink-0" />
                  <span className="font-medium">
                    Dispatcher calls your number within 2–5 minutes for live landmark or WhatsApp GPS pin coordination.
                  </span>
                </div>
                <span className="font-bold text-[#1a3d1a] shrink-0 hidden sm:inline">
                  Avg Response: &lt;15 Mins
                </span>
              </div>
            </ScrollReveal>

          </div>

        </div>
      </SectionContainer>
    </section>
  );
};
