import React from 'react';
import { Stethoscope, Scissors, Check } from 'lucide-react';
import { MEDICAL_SURGICAL_DATA } from '../data/svccData';
import { SvccArtwork } from './SvccArtwork';
import { ScrollReveal } from './ScrollReveal';
import { ImageParallax } from './ImageParallax';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from './SectionContainer';

export const MedicalSurgicalSection: React.FC = () => {
  const { ref: sectionRef, isIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  const medicalData = MEDICAL_SURGICAL_DATA.find((d) => d.type === 'medical')!;
  const surgicalData = MEDICAL_SURGICAL_DATA.find((d) => d.type === 'surgical')!;

  return (
    <section
      id="clinical"
      ref={sectionRef}
      style={{
        paddingTop: 'clamp(28px, 3.5vw, 44px)',
        paddingBottom: 'clamp(28px, 3.5vw, 44px)',
      }}
      className="w-full bg-[#EDE4D3]/30 border-y border-[#1a3d1a]/10 relative overflow-hidden"
    >
      <SectionContainer>
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-6 sm:mb-7">
          <ScrollReveal animation="fade-in" delay={80} reverseOnScrollUp={false}>
            <span className="label-eyebrow text-[#6F8F72]">
              Specialized Hospital Divisions
            </span>
          </ScrollReveal>

          <ScrollReveal animation="text-reveal" delay={140} reverseOnScrollUp={false}>
            <h2 className="section-h2 text-[#1a3d1a] mt-1.5">
              Medical & Surgical Care
            </h2>
          </ScrollReveal>

          <ScrollReveal animation="fade-up" delay={200} reverseOnScrollUp={false}>
            <p className="body-lead mt-2 text-[#1a3d1a]/85 mx-auto text-sm sm:text-base">
              Operating under rigorous clinical standards, combining pathology diagnostics with sterile operative theaters to guarantee voiceless patients the highest degree of medical care.
            </p>
          </ScrollReveal>
        </div>

        {/* Opposite Slide-in Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 lg:gap-7 items-stretch">
          
          {/* Card 1: Medical Care with ImageParallax */}
          <ScrollReveal animation="fade-up" delay={220} reverseOnScrollUp={false} className="h-full">
            <div className="svcc-card bg-white rounded-2xl p-5 sm:p-6 border border-[#1a3d1a]/15 shadow-2xs flex flex-col justify-between h-full relative overflow-hidden">
              <div className="card-accent-line" />
              <div>
                <div className="flex items-center gap-3 mb-3.5">
                  <div className="card-icon-float w-10 h-10 rounded-xl bg-[#6F8F72]/15 text-[#1a3d1a] flex items-center justify-center shrink-0">
                    <Stethoscope className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="label-eyebrow text-[#6F8F72] text-[11px]">
                      Division 01 · Clinical Pathology
                    </span>
                    <h3 className="sub-h3 text-[#1a3d1a] text-base sm:text-lg">
                      {medicalData.title}
                    </h3>
                  </div>
                </div>

                {/* Artwork with Scroll Parallax */}
                <div className="mb-4 rounded-xl overflow-hidden border border-[#1a3d1a]/10 aspect-[21/9] sm:aspect-[16/7] max-h-[160px] bg-[#F7F3EA] shadow-2xs">
                  <ImageParallax speed={0.04} maxOffset={18}>
                    <SvccArtwork variant="medical" className="w-full h-full" />
                  </ImageParallax>
                </div>

                <p className="card-body-text text-[#1a3d1a]/85 mb-3.5 text-xs sm:text-sm">
                  {medicalData.description}
                </p>

                <div className="space-y-1.5 mb-3.5">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-[#1a3d1a]">
                    Diagnostic & Therapeutic Capabilities:
                  </h4>
                  {medicalData.procedures.map((proc, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-[#1a3d1a]/90 font-medium group/item hover:text-[#6F8F72] transition-colors">
                      <div className="w-3.5 h-3.5 rounded-full bg-[#EFFDF0] border border-[#6F8F72] flex items-center justify-center shrink-0 mt-0.5">
                        <Check className="w-2.5 h-2.5 text-[#6F8F72]" />
                      </div>
                      <span>{proc}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-gray-100 text-xs text-[#1a3d1a]/80 flex flex-wrap items-center gap-1.5">
                <span className="font-semibold text-[#1a3d1a]">Clinical Equipment:</span>
                {medicalData.equipment.map((eq, eIdx) => (
                  <span key={eIdx} className="bg-[#EFFDF0] px-2 py-0.5 rounded-md border border-[#1a3d1a]/10 text-[11px] font-medium">
                    {eq}
                  </span>
                ))}
              </div>
            </div>
          </ScrollReveal>

          {/* Card 2: Surgical Care with ImageParallax */}
          <ScrollReveal animation="fade-up" delay={260} reverseOnScrollUp={false} className="h-full">
            <div className="svcc-card bg-white rounded-2xl p-5 sm:p-6 border border-[#1a3d1a]/15 shadow-2xs flex flex-col justify-between h-full relative overflow-hidden">
              <div className="card-accent-line" />
              <div>
                <div className="flex items-center gap-3 mb-3.5">
                  <div className="card-icon-float w-10 h-10 rounded-xl bg-[#E86A10]/15 text-[#E86A10] flex items-center justify-center shrink-0">
                    <Scissors className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="label-eyebrow text-[#E86A10] text-[11px]">
                      Division 02 · Operative Theater
                    </span>
                    <h3 className="sub-h3 text-[#1a3d1a] text-base sm:text-lg">
                      {surgicalData.title}
                    </h3>
                  </div>
                </div>

                {/* Artwork with Scroll Parallax */}
                <div className="mb-4 rounded-xl overflow-hidden border border-[#1a3d1a]/10 aspect-[21/9] sm:aspect-[16/7] max-h-[160px] bg-[#F7F3EA] shadow-2xs">
                  <ImageParallax speed={-0.04} maxOffset={18}>
                    <SvccArtwork variant="surgical" className="w-full h-full" />
                  </ImageParallax>
                </div>

                <p className="card-body-text text-[#1a3d1a]/85 mb-3.5 text-xs sm:text-sm">
                  {surgicalData.description}
                </p>

                <div className="space-y-1.5 mb-3.5">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-[#1a3d1a]">
                    Aseptic Operative Procedures:
                  </h4>
                  {surgicalData.procedures.map((proc, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-[#1a3d1a]/90 font-medium group/item hover:text-[#E86A10] transition-colors">
                      <div className="w-3.5 h-3.5 rounded-full bg-[#EFFDF0] border border-[#6F8F72] flex items-center justify-center shrink-0 mt-0.5">
                        <Check className="w-2.5 h-2.5 text-[#6F8F72]" />
                      </div>
                      <span>{proc}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-gray-100 text-xs text-[#1a3d1a]/80 flex flex-wrap items-center gap-1.5">
                <span className="font-semibold text-[#1a3d1a]">Surgical Gear:</span>
                {surgicalData.equipment.map((eq, eIdx) => (
                  <span key={eIdx} className="bg-[#EFFDF0] px-2 py-0.5 rounded-md border border-[#1a3d1a]/10 text-[11px] font-medium">
                    {eq}
                  </span>
                ))}
              </div>
            </div>
          </ScrollReveal>

        </div>
      </SectionContainer>
    </section>
  );
};
