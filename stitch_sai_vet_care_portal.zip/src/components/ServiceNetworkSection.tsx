import React, { useState } from 'react';
import {
  MapPin,
  Navigation,
  Phone,
  Clock,
  ArrowRight,
  Truck,
  CheckCircle2,
  Building2,
  Radio,
  ShieldCheck,
  Heart,
  Warehouse,
} from 'lucide-react';
import { NETWORK_LOCATIONS, GAUSHALA_PARTNERSHIPS } from '../data/svccData';
import { ScrollReveal } from './ScrollReveal';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from './SectionContainer';
import { useCms } from '../cms/CmsContext';

export const ServiceNetworkSection: React.FC = () => {
  const { data } = useCms();
  const networkLocations = data?.collections?.networkLocations?.length
    ? data.collections.networkLocations
    : NETWORK_LOCATIONS;
  const gaushalaPartnerships =
    data?.collections?.gaushalaPartnerships ||
    data?.collections?.gaushalaPartners ||
    GAUSHALA_PARTNERSHIPS;

  const { ref: sectionRef, isIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  const [activeTab, setActiveTab] = useState<'centres' | 'gaushalas'>('centres');
  const [activeLocationId, setActiveLocationId] = useState<string>(networkLocations[0]?.id || 'loc-shirdi');
  const [activeGaushalaId, setActiveGaushalaId] = useState<string>(gaushalaPartnerships[0]?.id || 'g-1');

  const activeLocation =
    networkLocations.find((l) => l.id === activeLocationId) || networkLocations[0] || NETWORK_LOCATIONS[0];
  const activeGaushala =
    gaushalaPartnerships.find((g: any) => g.id === activeGaushalaId) || gaushalaPartnerships[0] || GAUSHALA_PARTNERSHIPS[0];

  return (
    <section
      id="network"
      ref={sectionRef}
      style={{
        paddingTop: 'clamp(28px, 3.5vw, 44px)',
        paddingBottom: 'clamp(28px, 3.5vw, 44px)',
      }}
      className="w-full bg-[#EFFDF0] relative"
    >
      <SectionContainer>
        {/* Section Heading & Context */}
        <div className="text-center max-w-3xl mx-auto mb-8 sm:mb-10">
          <ScrollReveal animation="fade-in" delay={100} reverseOnScrollUp={false}>
            <span className="label-eyebrow text-[#6F8F72]">
              Moradabad Regional Operations & Shelter Partnerships
            </span>
          </ScrollReveal>

          <ScrollReveal animation="text-reveal" delay={180} reverseOnScrollUp={false}>
            <h2 className="section-h2 text-[#1a3d1a] mt-2">
              Service Locations & Gaushala Partnerships
            </h2>
          </ScrollReveal>

          <ScrollReveal animation="fade-up" delay={260} reverseOnScrollUp={false}>
            <p className="body-lead mt-3 text-[#1a3d1a]/85 mx-auto">
              Operating across 5 dedicated centres in Moradabad, Bilari, and Ramganga Paar, and extending regular monthly health camps and veterinary care to over 2,000 animals across 7 partner gaushalas.
            </p>
          </ScrollReveal>

          {/* Interactive Toggle between Service Centres & Partner Gaushalas */}
          <div className="mt-5 inline-flex p-1 rounded-2xl bg-white border border-[#1a3d1a]/15 shadow-2xs">
            <button
              onClick={() => setActiveTab('centres')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'centres'
                  ? 'bg-[#1a3d1a] text-white shadow-xs'
                  : 'text-[#1a3d1a] hover:bg-[#EFFDF0]'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>5 Service Centres</span>
            </button>
            <button
              onClick={() => setActiveTab('gaushalas')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'gaushalas'
                  ? 'bg-[#1a3d1a] text-white shadow-xs'
                  : 'text-[#1a3d1a] hover:bg-[#EFFDF0]'
              }`}
            >
              <Warehouse className="w-4 h-4" />
              <span>7 Partner Gaushalas (1,670+ Cattle)</span>
            </button>
          </div>
        </div>

        {/* 
          REBUILT TWO-COLUMN RESPONSIVE GRID
          - items-start ensures identical top alignment
          - Natural content heights without artificial flex stretching
          - Controlled gap-8 between columns, gap-6 between blocks
        */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT COLUMN: Regional Radar Map & Selected Facility Lock */}
          <div className="lg:col-span-6 flex flex-col gap-6">
            
            {/* Left Block 1: Regional Radar Map Card */}
            <ScrollReveal animation="fade-up" delay={300} reverseOnScrollUp={false}>
              <div className="bg-[#EDE4D3] rounded-3xl p-5 sm:p-6 border border-[#1a3d1a]/15 shadow-sm">
                
                {/* Header */}
                <div className="flex items-center justify-between pb-3.5 border-b border-[#1a3d1a]/10">
                  <div className="flex items-center gap-2">
                    <Navigation className="w-4 h-4 text-[#1a3d1a]" />
                    <span className="text-xs font-bold uppercase tracking-wider text-[#1a3d1a]">
                      Moradabad Veterinary Care Corridor
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-white/95 px-2.5 py-1 rounded-full border border-[#1a3d1a]/10 text-xs text-[#1a3d1a] font-semibold shadow-2xs">
                    <span className="w-2 h-2 rounded-full bg-[#1a3d1a] animate-ping" />
                    <span>Ramganga River Belt Grid</span>
                  </div>
                </div>

                {/* Radar Canvas with Responsive Aspect Ratio */}
                <div className="relative w-full aspect-16/10 sm:aspect-16/11 bg-[#EFFDF0] rounded-2xl border border-[#1a3d1a]/10 my-3.5 overflow-hidden shadow-inner flex items-center justify-center">
                  {/* Subtle radar range rings */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-35">
                    <div className="w-[120px] h-[120px] rounded-full border border-[#1a3d1a]/20 animate-ping duration-1000" />
                    <div className="w-[220px] h-[220px] rounded-full border border-[#1a3d1a]/15" />
                    <div className="w-[320px] h-[320px] rounded-full border border-[#1a3d1a]/10" />
                    <div className="absolute w-full h-[1px] bg-[#1a3d1a]/10" />
                    <div className="absolute h-full w-[1px] bg-[#1a3d1a]/10" />
                  </div>

                  {/* Route Lines */}
                  <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
                    <line x1="42%" y1="46%" x2="55%" y2="35%" stroke="#6F8F72" strokeWidth="2.5" className="animate-route-flow" />
                    <line x1="42%" y1="46%" x2="30%" y2="68%" stroke="#6F8F72" strokeWidth="2.5" className="animate-route-flow" />
                    <line x1="42%" y1="46%" x2="38%" y2="25%" stroke="#6F8F72" strokeWidth="2.5" className="animate-route-flow" />
                    <line x1="38%" y1="25%" x2="48%" y2="20%" stroke="#E86A10" strokeWidth="2.5" className="animate-route-flow" />
                  </svg>

                  {/* Location Markers */}
                  {networkLocations.map((loc) => {
                    const isActive = activeLocationId === loc.id && activeTab === 'centres';
                    return (
                      <button
                        key={loc.id}
                        type="button"
                        onClick={() => {
                          setActiveLocationId(loc.id);
                          setActiveTab('centres');
                        }}
                        className="absolute -translate-x-1/2 -translate-y-1/2 group cursor-pointer focus:outline-hidden transition-transform duration-300 z-10"
                        style={{
                          left: `${loc.coordinates.x}%`,
                          top: `${loc.coordinates.y}%`,
                        }}
                        title={loc.name}
                      >
                        <div className="flex flex-col items-center">
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
                              isActive
                                ? 'bg-[#1a3d1a] text-white shadow-lg scale-115 ring-4 ring-[#E86A10]/30'
                                : 'bg-white text-[#1a3d1a] border border-[#1a3d1a]/30 hover:scale-110 shadow-xs'
                            }`}
                          >
                            <MapPin className={`w-4 h-4 ${isActive ? 'text-[#E86A10]' : ''}`} />
                          </div>
                          <span
                            className={`mt-1 text-[10px] font-semibold px-2 py-0.5 rounded-full whitespace-nowrap shadow-xs transition-colors ${
                              isActive
                                ? 'bg-[#1a3d1a] text-white'
                                : 'bg-white/95 text-gray-800 border border-[#1a3d1a]/10'
                            }`}
                          >
                            {loc.name.replace('Sai Vet Care — ', '').split(' ')[0]}
                          </span>
                        </div>
                      </button>
                    );
                  })}

                  {/* Legend Overlay */}
                  <div className="absolute bottom-2.5 left-2.5 bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-xl border border-[#1a3d1a]/15 text-[11px] space-y-0.5 shadow-xs z-10 font-medium">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#1a3d1a]" />
                      <span className="font-semibold text-[#1a3d1a]">Main HQ (Mahal Kapoor)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#6F8F72]" />
                      <span>Regional Service Centre</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#E86A10]" />
                      <span>Ramganga / Kanth Loop</span>
                    </div>
                  </div>
                </div>

                {/* Active Selection Details Bar */}
                <div className="p-3.5 rounded-2xl bg-white border border-[#1a3d1a]/15 shadow-xs">
                  {activeTab === 'centres' ? (
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="label-eyebrow text-[#E86A10]">
                            Active Centre:
                          </span>
                          <span className="text-xs font-serif font-bold text-[#1a3d1a]">
                            {activeLocation.name}
                          </span>
                        </div>
                        <p className="text-xs text-gray-600 mt-0.5 line-clamp-1">
                          {activeLocation.address}
                        </p>
                      </div>

                      <div className="flex items-center gap-3 shrink-0 pt-1.5 sm:pt-0 border-t sm:border-t-0 border-gray-100 text-xs">
                        <div className="flex items-center gap-1 text-[#1a3d1a] font-semibold">
                          <Clock className="w-3.5 h-3.5 text-[#6F8F72]" />
                          <span>{activeLocation.timing}</span>
                        </div>
                        <a
                          href={`tel:${activeLocation.contact}`}
                          className="flex items-center gap-1 text-[#E86A10] font-mono font-bold hover:underline"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          <span>{activeLocation.contact}</span>
                        </a>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="label-eyebrow text-[#6F8F72]">
                            Partner Gaushala:
                          </span>
                          <span className="text-xs font-serif font-bold text-[#1a3d1a]">
                            {activeGaushala.name}
                          </span>
                        </div>
                        <p className="text-xs text-gray-600 mt-0.5 line-clamp-1">
                          {activeGaushala.location} · {activeGaushala.notes}
                        </p>
                      </div>

                      <div className="flex items-center gap-3 shrink-0 pt-1.5 sm:pt-0 border-t sm:border-t-0 border-gray-100 text-xs">
                        <span className="px-2.5 py-1 rounded-full bg-[#EFFDF0] text-[#1a3d1a] font-bold border border-[#1a3d1a]/15">
                          {activeGaushala.animals} Cattle
                        </span>
                        <div className="flex items-center gap-1 text-[#1a3d1a] font-mono text-[11px] font-semibold">
                          <Phone className="w-3.5 h-3.5 text-[#E86A10]" />
                          <span>{activeGaushala.contact.split(' ')[0]}</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

              </div>
            </ScrollReveal>

            {/* Left Block 2: Impact Metrics Bar */}
            <ScrollReveal animation="fade-up" delay={380} reverseOnScrollUp={false}>
              <div className="p-4 sm:p-5 rounded-2xl bg-white border border-[#1a3d1a]/15 shadow-xs">
                <div className="grid grid-cols-3 gap-3 text-center">
                  <div className="p-2.5 rounded-xl bg-[#EFFDF0] border border-[#1a3d1a]/10">
                    <div className="text-lg sm:text-xl font-bold font-serif text-[#1a3d1a]">5</div>
                    <div className="text-[11px] text-gray-600 font-medium">Service Centres</div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#EFFDF0] border border-[#1a3d1a]/10">
                    <div className="text-lg sm:text-xl font-bold font-serif text-[#E86A10]">2,000+</div>
                    <div className="text-[11px] text-gray-600 font-medium">Gaushala Cattle</div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#EFFDF0] border border-[#1a3d1a]/10">
                    <div className="text-lg sm:text-xl font-bold font-serif text-[#6F8F72]">100%</div>
                    <div className="text-[11px] text-gray-600 font-medium">Free Needy Care</div>
                  </div>
                </div>
              </div>
            </ScrollReveal>

          </div>

          {/* RIGHT COLUMN: Directory list corresponding to selected Tab */}
          <div className="lg:col-span-6 flex flex-col gap-6">
            
            {/* Right Block 1: Directory Card */}
            <ScrollReveal animation="fade-up" delay={340} reverseOnScrollUp={false}>
              <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#1a3d1a]/15 shadow-sm">
                
                {/* Header */}
                <div className="flex items-center justify-between pb-3.5 border-b border-[#1a3d1a]/10">
                  <div className="flex items-center gap-2">
                    {activeTab === 'centres' ? (
                      <Building2 className="w-4 h-4 text-[#1a3d1a]" />
                    ) : (
                      <Warehouse className="w-4 h-4 text-[#1a3d1a]" />
                    )}
                    <span className="text-xs font-bold uppercase tracking-wider text-[#1a3d1a]">
                      {activeTab === 'centres'
                        ? 'Moradabad Service Locations'
                        : 'Gaushala & Conservation Partnerships'}
                    </span>
                  </div>
                  <span className="text-xs text-[#1a3d1a] font-semibold bg-[#EFFDF0] px-2.5 py-1 rounded-full border border-[#1a3d1a]/10">
                    {activeTab === 'centres' ? '5 Active Centres' : '7 Partner Sanctuaries'}
                  </span>
                </div>

                {/* Content List: 5 Centres or 7 Gaushalas */}
                <div className="flex flex-col gap-3 my-3.5 max-h-[380px] overflow-y-auto pr-1">
                  {activeTab === 'centres'
                    ? networkLocations.map((loc) => {
                        const isSelected = activeLocationId === loc.id;
                        return (
                          <div
                            key={loc.id}
                            onClick={() => setActiveLocationId(loc.id)}
                            className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer ${
                              isSelected
                                ? 'bg-[#EFFDF0] border-[#1a3d1a] shadow-sm ring-2 ring-[#1a3d1a]/15'
                                : 'bg-[#EDE4D3]/25 border-[#1a3d1a]/12 hover:bg-[#EDE4D3]/45 hover:border-[#6F8F72]'
                            }`}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div className="flex items-start gap-3">
                                <div
                                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                                    isSelected
                                      ? 'bg-[#1a3d1a] text-white'
                                      : 'bg-white text-[#1a3d1a] border border-[#1a3d1a]/15'
                                  }`}
                                >
                                  <MapPin className="w-4.5 h-4.5" />
                                </div>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <h4 className="text-sm sm:text-base font-serif font-bold text-[#1a3d1a] leading-snug">
                                      {loc.name}
                                    </h4>
                                    {isSelected && (
                                      <span className="text-[10px] font-bold text-[#E86A10] bg-[#E86A10]/10 px-1.5 py-0.5 rounded-sm">
                                        ACTIVE
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-xs text-gray-600 mt-0.5">
                                    {loc.address}
                                  </p>
                                </div>
                              </div>
                              <a
                                href={`tel:${loc.contact}`}
                                onClick={(e) => e.stopPropagation()}
                                className="flex items-center gap-1 text-xs font-mono font-bold text-[#1a3d1a] bg-white px-2.5 py-1 rounded-lg border border-[#1a3d1a]/10 hover:text-[#E86A10]"
                              >
                                <Phone className="w-3 h-3 text-[#E86A10]" />
                                <span>{loc.contact}</span>
                              </a>
                            </div>

                            <div className="mt-2.5 pt-2 border-t border-[#1a3d1a]/8 flex flex-wrap gap-1.5">
                              {loc.facilities.map((fac, fIdx) => (
                                <span
                                  key={fIdx}
                                  className="text-[10px] bg-white text-[#1a3d1a] px-2 py-0.5 rounded-md border border-[#1a3d1a]/10 font-medium"
                                >
                                  {fac}
                                </span>
                              ))}
                            </div>
                          </div>
                        );
                      })
                    : gaushalaPartnerships.map((gaushala: any) => {
                        const isSelected = activeGaushalaId === gaushala.id;
                        return (
                          <div
                            key={gaushala.id}
                            onClick={() => setActiveGaushalaId(gaushala.id)}
                            className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer ${
                              isSelected
                                ? 'bg-[#EFFDF0] border-[#1a3d1a] shadow-sm ring-2 ring-[#1a3d1a]/15'
                                : 'bg-[#EDE4D3]/25 border-[#1a3d1a]/12 hover:bg-[#EDE4D3]/45 hover:border-[#6F8F72]'
                            }`}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div className="flex items-start gap-3">
                                <div
                                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                                    isSelected
                                      ? 'bg-[#1a3d1a] text-white'
                                      : 'bg-white text-[#1a3d1a] border border-[#1a3d1a]/15'
                                  }`}
                                >
                                  <Warehouse className="w-4.5 h-4.5" />
                                </div>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <h4 className="text-sm sm:text-base font-serif font-bold text-[#1a3d1a] leading-snug">
                                      {gaushala.name}
                                    </h4>
                                    <span className="text-[10px] font-bold text-[#1a3d1a] bg-white px-2 py-0.5 rounded-full border border-[#1a3d1a]/15">
                                      {gaushala.animals} Cattle
                                    </span>
                                  </div>
                                  <p className="text-xs text-gray-600 mt-0.5">
                                    {gaushala.location}
                                  </p>
                                </div>
                              </div>
                              <ArrowRight
                                className={`w-4 h-4 shrink-0 mt-1 transition-transform ${
                                  isSelected ? 'text-[#E86A10] translate-x-1' : 'text-gray-400'
                                }`}
                              />
                            </div>

                            <div className="mt-2.5 pt-2 border-t border-[#1a3d1a]/8 flex items-center justify-between text-[11px] text-gray-600">
                              <span>Contact: <strong className="text-[#1a3d1a]">{gaushala.contact}</strong></span>
                              <span className="text-[#6F8F72] font-semibold">Monthly Health Camp</span>
                            </div>
                          </div>
                        );
                      })}
                </div>

                {/* Footer Note */}
                <div className="pt-3 border-t border-[#1a3d1a]/10 flex items-center justify-between text-xs text-gray-600">
                  <div className="flex items-center gap-1.5">
                    <Radio className="w-3.5 h-3.5 text-[#6F8F72]" />
                    <span>Monthly Follow-Up & Medicine Support</span>
                  </div>
                  <span className="font-semibold text-[#1a3d1a]">Under Shri Sai Karuna Sansthan</span>
                </div>

              </div>
            </ScrollReveal>

            {/* Right Block 2: Operational Dispatch Assurance */}
            <ScrollReveal animation="fade-up" delay={420} reverseOnScrollUp={false}>
              <div className="p-4 sm:p-5 rounded-2xl bg-white border border-[#1a3d1a]/15 shadow-xs flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-[#6F8F72]/15 text-[#1a3d1a] flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5 text-[#6F8F72]" />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#1a3d1a]">
                    Qualified Veterinary Surgical & OPD Team
                  </h4>
                  <p className="text-xs text-gray-600 mt-0.5 leading-relaxed">
                    Led by a senior veterinarian skilled in surgical treatment and supported by a veterinary specialist, handling medical, surgical, and emergency animal care across Moradabad.
                  </p>
                </div>
              </div>
            </ScrollReveal>

          </div>

        </div>

        {/* Clean Full-Width Bottom Anchor Bar */}
        <div className="mt-8 p-4 rounded-2xl bg-white border border-[#1a3d1a]/15 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-[#1a3d1a]">
          <div className="flex items-center gap-2.5">
            <Truck className="w-4 h-4 text-[#E86A10] shrink-0" />
            <span className="font-medium text-xs sm:text-sm">
              Headquarters: Mahal Kapoor Gram, Moradabad (8191921647) · Kafiyabad (9627169456) · Village Darni, Bilari (9675555247)
            </span>
          </div>
          <div className="flex items-center gap-2 font-semibold shrink-0 text-xs sm:text-sm">
            <CheckCircle2 className="w-4 h-4 text-[#6F8F72]" />
            <span>100% Free Treatment for Needy Animals</span>
          </div>
        </div>
      </SectionContainer>
    </section>
  );
};
