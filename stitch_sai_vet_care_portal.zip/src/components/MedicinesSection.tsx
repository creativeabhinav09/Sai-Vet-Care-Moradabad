import React from 'react';
import { Pill, PackageCheck } from 'lucide-react';
import { MEDICINES_LIST } from '../data/svccData';
import { ScrollReveal } from './ScrollReveal';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from './SectionContainer';
import { useCms } from '../cms/CmsContext';

export const MedicinesSection: React.FC = () => {
  const { data } = useCms();
  const medicinesList = data?.collections?.medicines?.length ? data.collections.medicines : MEDICINES_LIST;

  const { ref: sectionRef, isIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  return (
    <section
      id="medicines"
      ref={sectionRef}
      style={{
        paddingTop: 'clamp(28px, 3.5vw, 44px)',
        paddingBottom: 'clamp(28px, 3.5vw, 44px)',
      }}
      className="w-full bg-[#FFFFFF] relative"
    >
      <SectionContainer>
        {/* Section Heading & Intro Text */}
        <div className="max-w-3xl mx-auto text-center mb-6 sm:mb-7">
          <ScrollReveal animation="fade-in" delay={80} reverseOnScrollUp={false}>
            <span className="label-eyebrow text-[#6F8F72]">
              Humanitarian Formulary & Free Dispensary
            </span>
          </ScrollReveal>

          <ScrollReveal animation="text-reveal" delay={140} reverseOnScrollUp={false}>
            <h2 className="section-h2 text-[#1a3d1a] mt-1.5">
              Medicines & Treatment Support
            </h2>
          </ScrollReveal>

          <ScrollReveal animation="fade-up" delay={200} reverseOnScrollUp={false}>
            <p className="body-lead mt-2 text-[#1a3d1a]/85 mx-auto text-sm sm:text-base">
              Sai Vet Care utilises a comprehensive range of veterinary medicines and treatment products to address a wide variety of animal health conditions across all service locations — provided 100% free of cost to animals in need.
            </p>
          </ScrollReveal>
        </div>

        {/* Structured Grid with ScrollReveal */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 items-stretch">
          {medicinesList.map((med, idx) => (
            <ScrollReveal
              key={med.id}
              animation="fade-up"
              delay={120 + (idx % 3) * 60}
              reverseOnScrollUp={false}
              className="h-full"
            >
              <div className="bg-[#EFFDF0] rounded-2xl p-4 sm:p-4.5 border border-[#1a3d1a]/15 shadow-2xs hover:border-[#6F8F72] hover:shadow-sm transition-all duration-300 h-full flex flex-col justify-between group">
                <div>
                  <div className="flex items-start justify-between gap-3 mb-2.5">
                    <div className="w-8 h-8 rounded-lg bg-[#1a3d1a] text-white flex items-center justify-center shrink-0 shadow-2xs group-hover:bg-[#E86A10] transition-colors">
                      <Pill className="w-3.5 h-3.5 text-[#EFFDF0]" />
                    </div>
                    <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                      med.availability === '100% Free Dispensary'
                        ? 'bg-[#6F8F72]/20 text-[#1a3d1a]'
                        : 'bg-[#E86A10]/20 text-[#E86A10]'
                    }`}>
                      {med.availability}
                    </span>
                  </div>

                  <h3 className="sub-h3 text-[#1a3d1a] mb-0.5 leading-snug text-base sm:text-lg">
                    {med.name}
                  </h3>

                  <div className="text-[11px] font-mono text-[#6F8F72] mb-2 font-medium">
                    {med.type}
                  </div>

                  <p className="card-body-text text-[#1a3d1a]/85 text-xs sm:text-sm">
                    {med.usage}
                  </p>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>

        {/* Humanitarian Commitment Banner */}
        <ScrollReveal animation="fade-up" delay={300} reverseOnScrollUp={false}>
          <div className="mt-6 p-3.5 sm:p-4 rounded-xl bg-[#EDE4D3]/50 border border-[#1a3d1a]/10 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <PackageCheck className="w-4.5 h-4.5 text-[#1a3d1a] shrink-0" />
              <span className="text-xs sm:text-sm text-[#1a3d1a] font-medium">
                All medicines supplied are stored under temperature-monitored pharmaceutical refrigeration conforming to Indian Pharmacopoeia standards.
              </span>
            </div>
            <span className="text-[11px] font-semibold text-[#1a3d1a] uppercase tracking-wider bg-white px-2.5 py-1 rounded-full border border-[#1a3d1a]/15 shadow-2xs">
              Zero Billing Policy
            </span>
          </div>
        </ScrollReveal>
      </SectionContainer>
    </section>
  );
};
