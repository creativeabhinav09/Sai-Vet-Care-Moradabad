import React from 'react';
import { Calendar, ArrowRight, Clock } from 'lucide-react';
import { STORY_UPDATES } from '../data/svccData';
import { SvccArtwork } from './SvccArtwork';
import { ScrollReveal } from './ScrollReveal';
import { ImageParallax } from './ImageParallax';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from './SectionContainer';

import { useCms } from '../cms/CmsContext';

interface UpdatesSectionProps {
  onSelectStory?: (id: string) => void;
}

export const UpdatesSection: React.FC<UpdatesSectionProps> = ({ onSelectStory }) => {
  const { data } = useCms();
  const rawStories = data?.collections?.stories?.length ? data.collections.stories : STORY_UPDATES;
  // Filter for published stories if status field exists
  const storyList = rawStories.filter((s: any) => !s.status || s.status === 'published');

  const { ref: sectionRef, isIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  const getArtworkVariant = (id: string): 'hero' | 'satpathy' | 'medical' | 'surgical' | 'gaushala' | 'rehab' | 'emergency' => {
    if (id === 'story-1') return 'gaushala';
    if (id === 'story-2') return 'hero';
    return 'surgical';
  };

  return (
    <section
      id="updates"
      ref={sectionRef}
      style={{
        paddingTop: 'clamp(28px, 3.5vw, 44px)',
        paddingBottom: 'clamp(28px, 3.5vw, 44px)',
      }}
      className="w-full bg-[#FFFFFF] relative"
    >
      <SectionContainer>
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-6 sm:mb-8">
          <ScrollReveal animation="fade-in" delay={100} reverseOnScrollUp={false}>
            <span className="label-eyebrow text-[#6F8F72]">
              Field Journals & Healing Milestones
            </span>
          </ScrollReveal>

          <ScrollReveal animation="text-reveal" delay={180} reverseOnScrollUp={false}>
            <h2 className="section-h2 text-[#1a3d1a] mt-2">
              Recent Stories of Seva
            </h2>
          </ScrollReveal>

          <ScrollReveal animation="fade-up" delay={260} reverseOnScrollUp={false}>
            <p className="body-lead mt-3 text-[#1a3d1a]/85 mx-auto">
              Real testimonies of critical rescues, rural livestock health interventions, and animals regaining a pain-free life through loving care.
            </p>
          </ScrollReveal>
        </div>

        {/* 3 Staggered Editorial Cards with ImageParallax and Reversible Entrance */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 lg:gap-6 items-stretch">
          {storyList.map((story: any, index: number) => (
            <ScrollReveal
              key={story.id}
              animation="fade-up"
              delay={150 + index * 120}
              reverseOnScrollUp={false}
              className="h-full"
            >
              <article
                onClick={() => onSelectStory && onSelectStory(story.id)}
                className="svcc-card group bg-[#EFFDF0] rounded-3xl overflow-hidden border border-[#1a3d1a]/15 shadow-xs hover:border-[#6F8F72] cursor-pointer flex flex-col justify-between h-full relative"
              >
                <div className="card-accent-line" />
                <div>
                  <div className="aspect-16/10 w-full overflow-hidden bg-[#EDE4D3] relative">
                    <ImageParallax speed={0.06} maxOffset={25}>
                      {story.imageUrl ? (
                        <img
                          src={story.imageUrl}
                          alt={story.title}
                          className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-106"
                        />
                      ) : (
                        <SvccArtwork
                          variant={getArtworkVariant(story.id)}
                          className="w-full h-full transition-transform duration-700 ease-out group-hover:scale-106"
                        />
                      )}
                    </ImageParallax>
                    <div className="absolute top-3 left-3 bg-[#1a3d1a]/90 text-white text-xs font-semibold uppercase tracking-wider px-3 py-1 rounded-full shadow-xs z-10">
                      {story.category}
                    </div>
                  </div>

                  <div className="p-6">
                    <div className="flex items-center justify-between text-xs text-gray-600 mb-2.5">
                      <div className="flex items-center gap-1.5 font-medium">
                        <Calendar className="w-3.5 h-3.5 text-[#6F8F72]" />
                        <span>{story.date}</span>
                      </div>
                      <div className="flex items-center gap-1.5 font-medium">
                        <Clock className="w-3.5 h-3.5 text-[#E86A10]" />
                        <span>{story.readTime}</span>
                      </div>
                    </div>

                    <h3 className="sub-h3 text-[#1a3d1a] leading-snug mb-3 group-hover:text-[#2a5a2a] transition-colors">
                      {story.title}
                    </h3>

                    <p className="card-body-text text-[#1a3d1a]/85">
                      {story.summary}
                    </p>
                  </div>
                </div>

                <div className="p-6 pt-0">
                  <div className="pt-4 border-t border-gray-200 flex items-center justify-between text-sm font-semibold text-[#1a3d1a] group-hover:text-[#E86A10] transition-colors">
                    <span>Read Complete Healing Report</span>
                    <ArrowRight className="w-4 h-4 card-arrow-move" />
                  </div>
                </div>
              </article>
            </ScrollReveal>
          ))}
        </div>
      </SectionContainer>
    </section>
  );
};
