import React from 'react';

interface SectionContainerProps {
  children: React.ReactNode;
  className?: string;
  as?: React.ElementType;
  style?: React.CSSProperties;
  id?: string;
}

/**
 * Standardized full-width container component:
 * - max-width 1400px
 * - Centered horizontally (mx-auto)
 * - Fluid clamp padding (scales smoothly from 16px on mobile to 56px on desktop)
 * - Wraps every section individually to eliminate trapped content and accidental columns
 */
export const SectionContainer: React.FC<SectionContainerProps> = ({
  children,
  className = '',
  as: Component = 'div',
  style,
  id,
}) => {
  return (
    <Component
      id={id}
      style={{
        paddingLeft: 'clamp(1rem, 3.5vw, 3.5rem)',
        paddingRight: 'clamp(1rem, 3.5vw, 3.5rem)',
        ...style,
      }}
      className={`w-full max-w-[1400px] mx-auto ${className}`}
    >
      {children}
    </Component>
  );
};
