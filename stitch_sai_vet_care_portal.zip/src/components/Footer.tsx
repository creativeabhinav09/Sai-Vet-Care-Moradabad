import React from 'react';
import { Link } from 'react-router-dom';
import { HeartHandshake, Phone, ArrowUp, Sparkles, ShieldCheck, MapPin, Building2 } from 'lucide-react';
import { SectionContainer } from './SectionContainer';
import { useCms } from '../cms/CmsContext';

export const Footer: React.FC = () => {
  const { data } = useCms();
  const footerData = data?.footer;
  const settingsData = data?.settings;

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer
      id="footer"
      className="bg-[#1a3d1a] text-[#EDE4D3] border-t border-[#6F8F72]/30 pt-14 sm:pt-16 pb-12 relative z-30 w-full block"
    >
      <SectionContainer>
        {/* Top Institutional Banner */}
        <div className="pb-8 mb-10 border-b border-[#EFFDF0]/15 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <span className="text-xs uppercase tracking-widest text-[#E86A10] font-bold">
              Institutional Affiliation
            </span>
            <h3 className="text-lg sm:text-xl font-serif text-[#EFFDF0] mt-0.5">
              A Unit of Shri Sai Karuna Sansthan · Under the Aegis of Shri Shirdi Sai Global Foundation
            </h3>
          </div>
          <div className="flex items-center gap-2 text-xs sm:text-sm text-[#EFFDF0]/80 bg-white/10 px-3.5 py-1.5 rounded-full border border-white/15">
            <Sparkles className="w-3.5 h-3.5 text-[#E86A10]" />
            <span>Established 2009 · Moradabad, Uttar Pradesh, India</span>
          </div>
        </div>

        {/* Main 4 Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 pb-12 border-b border-[#EFFDF0]/15">
          
          {/* Column 1: Brand & Philosophy */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-full bg-[#EFFDF0] text-[#1a3d1a] flex items-center justify-center shrink-0 shadow-xs">
                <HeartHandshake className="w-5 h-5 text-[#E86A10]" />
              </div>
              <div>
                <span className="text-2xl font-serif-display font-bold text-[#EFFDF0] block leading-none">
                  {settingsData?.siteName || 'Sai Vet Care'}
                </span>
                <span className="text-[11px] uppercase tracking-wider text-[#EDE4D3]/75 font-medium mt-0.5 block">
                  {settingsData?.tagline || 'Service to Every Living Being'}
                </span>
              </div>
            </div>

            <p className="text-sm text-[#EDE4D3]/85 leading-relaxed">
              {footerData?.aboutText ||
                'Established in 2009 under the inspiration and initiative of Dr. Chandra Bhanu Satpathy Ji, providing timely, high-quality, and 100% free medical and surgical veterinary care to accident cases, critically ill animals, and over 2,000 cattle across 7 partner gaushalas in the Moradabad region.'}
            </p>

            <div className="pt-2 flex items-center gap-2 text-xs text-[#EDE4D3]/90 italic font-serif">
              <span>"Every living being deserves care and dignity."</span>
              <span className="text-[#E86A10] font-sans font-semibold not-italic">— Dr. C.B. Satpathy Ji</span>
            </div>
          </div>

          {/* Column 2: 5 Service Centres in Moradabad */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-[#6F8F72]">
              Service Centres (Moradabad)
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm text-[#EDE4D3]/85">
              <li className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#E86A10] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-white">Main Headquarters:</span> Mahal Kapoor Gram (OPD & OT)
                </div>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#6F8F72] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-white">Ramganga Paar:</span> Kafiyabad Centre
                </div>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#6F8F72] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-white">Bilari Tehsil:</span> Village Darni Centre
                </div>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#6F8F72] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-white">Kanth Road:</span> Naya Gaon, Harthala Ind. Area
                </div>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#6F8F72] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-white">Mora ki Milak:</span> Behind Vivekanand Hospital
                </div>
              </li>
            </ul>
          </div>

          {/* Column 3: Quick Navigation */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-[#6F8F72]">
              Explore
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-[#EDE4D3]/85 font-medium">
              {(footerData?.columns?.[0]?.links || [
                { label: 'About Sai Vet Care', path: '/about' },
                { label: '9 Areas of Seva', path: '/seva' },
                { label: 'OPD, OT & Free Formulary', path: '/clinical' },
                { label: '7 Partner Gaushalas', path: '/network' },
                { label: 'Veterinary Team', path: '/team' },
                { label: 'Contact & Dispatch', path: '/contact' },
              ]).map((link, idx) => (
                <li key={idx}>
                  <Link to={link.path} className="hover:text-white hover:translate-x-1 transition-all inline-block">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Contact & Hotlines */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-[#6F8F72]">
              Emergency Contact Desk
            </h4>
            
            <div className="p-4 rounded-2xl bg-white/10 border border-white/15 space-y-2.5">
              <div className="flex items-center gap-2 text-[#E86A10]">
                <Phone className="w-4 h-4 animate-pulse" />
                <span className="text-xs font-bold uppercase tracking-wider">Main Headquarters Hotline</span>
              </div>
              <div className="text-lg font-mono font-bold text-white">
                {settingsData?.emergencyPhone || '8191921647'}
              </div>
              <div className="text-xs text-[#EDE4D3]/80 space-y-1 pt-1 border-t border-white/10">
                <div>Kafiyabad Centre: <span className="font-mono font-semibold text-white">9627169456</span></div>
                <div>Village Darni (Bilari): <span className="font-mono font-semibold text-white">9675555247</span></div>
                <div>Kanth Road (Naya Gaon): <span className="font-mono font-semibold text-white">9309330729</span></div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs text-[#EDE4D3]/80">
              <ShieldCheck className="w-4 h-4 text-[#6F8F72] shrink-0" />
              <span>100% Free Treatment for Needy Animals</span>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright, Legal & Back to Top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#EDE4D3]/75 font-medium">
          <div>
            {footerData?.copyrightText ||
              `© ${new Date().getFullYear()} Sai Vet Care · A Unit of Shri Sai Karuna Sansthan | Under the Aegis of Shri Shirdi Sai Global Foundation.`}
          </div>

          <div className="flex items-center gap-3 sm:gap-4">
            <a
              href="#/admin"
              className="text-[#EDE4D3]/70 hover:text-white transition-colors underline decoration-dotted"
            >
              CMS Admin
            </a>
            <span>·</span>
            <span>Free Veterinary Dispensary</span>
            <span>·</span>
            <button
              onClick={scrollToTop}
              className="flex items-center gap-1.5 text-white hover:text-[#E86A10] transition-colors cursor-pointer py-1 px-3 rounded-lg bg-white/10 hover:bg-white/20"
              aria-label="Scroll back to top"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </SectionContainer>
    </footer>
  );
};
