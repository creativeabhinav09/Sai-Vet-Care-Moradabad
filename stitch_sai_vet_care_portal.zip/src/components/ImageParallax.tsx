import React from 'react';
import { useParallax } from '../hooks/useParallax';

interface ImageParallaxProps {
  children: React.ReactNode;
  speed?: number; // e.g. 0.08 or -0.08
  maxOffset?: number;
  className?: string;
  overflowHidden?: boolean;
  origin?: 'center' | 'bottom' | 'top';
  scale?: string;
}

export const ImageParallax: React.FC<ImageParallaxProps> = ({
  children,
  speed = 0.08,
  maxOffset = 40,
  className = '',
  overflowHidden = true,
  origin = 'center',
  scale = 'scale-110',
}) => {
  const { ref, style } = useParallax({ speed, maxOffset });

  const getOriginClass = () => {
    switch (origin) {
      case 'bottom':
        return 'origin-bottom';
      case 'top':
        return 'origin-top';
      case 'center':
      default:
        return 'origin-center';
    }
  };

  return (
    <div
      ref={ref}
      className={`relative ${overflowHidden ? 'overflow-hidden' : 'overflow-visible'} ${className}`}
    >
      <div
        style={style}
        className={`w-full h-full ${scale} ${getOriginClass()}`}
      >
        {children}
      </div>
    </div>
  );
};
