import React, { useState } from 'react';
import { Quote, Feather, CheckCircle2 } from 'lucide-react';
import { SATPATHY_JI_TIMELINE } from '../data/svccData';
import { SvccArtwork } from './SvccArtwork';
import { ScrollReveal } from './ScrollReveal';
import { ImageParallax } from './ImageParallax';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from './SectionContainer';
import { useCms } from '../cms/CmsContext';

export const SatpathyJiSection: React.FC = () => {
  const { data } = useCms();
  const timelineList = data?.collections?.timeline?.length ? data.collections.timeline : SATPATHY_JI_TIMELINE;

  const { ref, isIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });
  const [activeMilestone, setActiveMilestone] = useState<string>('Today');

  return (
    <section
      id="patron"
      ref={ref}
      style={{
        paddingTop: 'clamp(28px, 3.5vw, 44px)',
        paddingBottom: 'clamp(28px, 3.5vw, 44px)',
      }}
      className="w-full bg-[#EDE4D3]/35 border-y border-[#1a3d1a]/10 relative overflow-hidden"
    >
      {/* Ambient background glow */}
      <div className="absolute top-1/3 left-10 w-96 h-96 bg-[#6F8F72]/10 rounded-full blur-3xl pointer-events-none -z-10" />

      <SectionContainer>
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-6 sm:mb-8">
          <ScrollReveal animation="fade-in" delay={100} reverseOnScrollUp={false}>
            <div className="flex items-center justify-center gap-2 mb-1.5">
              <Feather className="w-4 h-4 text-[#E86A10]" />
              <span className="label-eyebrow text-[#1a3d1a]/80">
                Spiritual Patron & Guiding Philosophy
              </span>
            </div>
          </ScrollReveal>

          <ScrollReveal animation="text-reveal" delay={160} reverseOnScrollUp={false}>
            <h2 className="section-h2 text-[#1a3d1a] text-balance">
              Inspired by Revered Dr. Chandra Bhanu Satpathy Ji
            </h2>
          </ScrollReveal>

          <ScrollReveal animation="fade-up" delay={220} reverseOnScrollUp={false}>
            <p className="body-lead mt-2 text-[#1a3d1a]/85 mx-auto font-serif italic text-base sm:text-lg">
              "Every living being deserves care and dignity."
            </p>
          </ScrollReveal>
        </div>

        {/* Dignified Balanced Two-Column Layout with Top & Bottom Alignment */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 lg:items-stretch">
          
          {/* Left Column: Portrait & Curatorial Quote */}
          <div className="lg:col-span-5 w-full h-full flex flex-col justify-between">
            {/* Top: Revered Patron Portrait Artwork Card */}
            <ScrollReveal animation="scale-in" delay={140} reverseOnScrollUp={false} className="flex-1 flex flex-col mb-3 sm:mb-3.5">
              <div className="rounded-2xl sm:rounded-3xl overflow-hidden border border-[#1a3d1a]/20 shadow-xs bg-[#EDE4D3] relative group flex-1 flex flex-col justify-between min-h-[220px]">
                <div className="relative flex-1 w-full min-h-[190px] flex items-center justify-center p-3 sm:p-4 overflow-hidden bg-[#EDE4D3]">
                  <SvccArtwork variant="satpathy" className="w-full h-full max-h-[300px] object-contain object-center" />
                </div>

                {/* Dignified Caption Banner */}
                <div className="px-3.5 py-2 bg-white/75 backdrop-blur-xs border-t border-[#1a3d1a]/10 flex items-center justify-between text-[11px] text-[#1a3d1a]/85 font-medium">
                  <span>Spiritual Patron & Guiding Light</span>
                  <span className="font-semibold text-[#E86A10]">Moradabad Chapter</span>
                </div>
              </div>
            </ScrollReveal>

            {/* Bottom: Curatorial Quote Card */}
            <ScrollReveal animation="fade-up" delay={200} reverseOnScrollUp={false}>
              <div className="p-4 sm:p-4.5 rounded-2xl bg-white border border-[#1a3d1a]/15 shadow-2xs relative">
                <Quote className="w-5 h-5 text-[#6F8F72]/30 absolute top-3.5 right-3.5" />
                <p className="text-xs sm:text-[13px] italic font-serif text-[#1a3d1a] leading-relaxed pr-6">
                  "Every living being deserves care and dignity. When an injured or sick animal is given medical treatment and tenderness, we fulfill our sacred duty to creation."
                </p>
                <div className="mt-2.5 pt-2 border-t border-[#1a3d1a]/10 text-[11px] font-semibold uppercase tracking-wider text-[#E86A10] flex items-center gap-1.5">
                  <span className="w-2 h-0.5 bg-[#E86A10]" />
                  <span>Dr. Chandra Bhanu Satpathy Ji — Guiding Inspiration</span>
                </div>
              </div>
            </ScrollReveal>
          </div>

          {/* Right Column: Progressive Milestone Timeline */}
          <div className="lg:col-span-7 w-full h-full flex flex-col justify-between">
            <div className="relative pl-6 sm:pl-7 border-l-2 border-[#6F8F72]/30 h-full flex flex-col justify-between gap-2.5 sm:gap-3">
              {/* Dynamic green progress line running along the timeline */}
              <div
                className="absolute left-[-2px] top-0 bottom-0 w-0.5 bg-gradient-to-b from-[#1a3d1a] via-[#6F8F72] to-[#E86A10] transition-all duration-700 ease-out"
                style={{ height: isIntersecting ? '100%' : '0%' }}
              />

              {timelineList.map((item, index) => {
                const isSelected = activeMilestone === item.year;
                const delayMs = 120 + index * 60;
                return (
                  <ScrollReveal key={item.year} animation="fade-up" delay={delayMs} reverseOnScrollUp={false} className="flex-1 flex flex-col">
                    <div
                      onMouseEnter={() => setActiveMilestone(item.year)}
                      className={`relative group rounded-xl sm:rounded-2xl p-3 sm:p-3.5 border transition-all duration-200 cursor-pointer h-full flex flex-col justify-between ${
                        isSelected
                          ? 'bg-white border-[#1a3d1a] shadow-xs'
                          : 'bg-white/85 border-[#1a3d1a]/10 hover:bg-white hover:border-[#6F8F72]'
                      }`}
                    >
                      {/* Timeline Node Dot */}
                      <div
                        className={`absolute -left-[31px] sm:-left-[35px] top-4 w-3.5 h-3.5 rounded-full border-2 transition-all duration-200 flex items-center justify-center ${
                          isSelected
                            ? 'bg-[#E86A10] border-white scale-110 shadow-xs'
                            : 'bg-[#EFFDF0] border-[#1a3d1a]'
                        }`}
                      >
                        <div className={`w-1 h-1 rounded-full ${isSelected ? 'bg-white' : 'bg-[#1a3d1a]'}`} />
                      </div>

                      <div>
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <span
                            className={`text-[11px] font-semibold uppercase tracking-wider px-2.5 py-0.5 rounded-full transition-colors ${
                              isSelected
                                ? 'bg-[#1a3d1a] text-[#EFFDF0]'
                                : 'bg-[#EFFDF0] text-[#1a3d1a] border border-[#1a3d1a]/15'
                            }`}
                          >
                            {item.year}
                          </span>
                          <span className="text-[11px] font-semibold text-[#E86A10]">
                            Milestone 0{index + 1}
                          </span>
                        </div>

                        <h3 className="text-sm sm:text-[15px] font-serif font-bold text-[#1a3d1a] mb-1 group-hover:text-[#2a5a2a] transition-colors leading-snug">
                          {item.title}
                        </h3>

                        <p className="text-xs sm:text-[13px] text-[#1a3d1a]/85 leading-relaxed">
                          {item.description}
                        </p>
                      </div>

                      <div className="mt-2 pt-2 border-t border-[#1a3d1a]/10 flex items-center gap-1.5 text-[11px] sm:text-xs font-medium text-[#1a3d1a]">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#6F8F72] shrink-0" />
                        <span className="truncate">{item.achievement || "Preserving Dr. Satpathy Ji's humanitarian legacy"}</span>
                      </div>
                    </div>
                  </ScrollReveal>
                );
              })}
            </div>
          </div>

        </div>
      </SectionContainer>
    </section>
  );
};
