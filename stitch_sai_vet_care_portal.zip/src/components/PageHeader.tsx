import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Sparkles } from 'lucide-react';
import { SectionContainer } from './SectionContainer';

interface PageHeaderProps {
  eyebrow: string;
  title: string;
  description: string;
  breadcrumbCurrent: string;
}

export const PageHeader: React.FC<PageHeaderProps> = ({
  eyebrow,
  title,
  description,
  breadcrumbCurrent,
}) => {
  return (
    <header className="relative pt-24 pb-12 sm:pb-16 bg-[#EDE4D3]/40 border-b border-[#294936]/10 overflow-hidden w-full">
      {/* Ambient background decoration */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#6F8F72]/10 rounded-full blur-3xl pointer-events-none -z-10" />

      <SectionContainer>
        {/* Breadcrumb Navigation */}
        <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-sm text-[#26332B]/70 mb-4 animate-fade-in delay-100">
          <Link to="/" className="hover:text-[#294936] transition-colors">
            Home
          </Link>
          <ChevronRight className="w-3.5 h-3.5 text-[#6F8F72]" />
          <span className="text-[#294936] font-medium">{breadcrumbCurrent}</span>
        </nav>

        {/* Eyebrow */}
        <div className="inline-flex items-center gap-1.5 label-eyebrow text-[#6F8F72] mb-3 animate-fade-in delay-150">
          <Sparkles className="w-3.5 h-3.5 text-[#C98268]" />
          <span>{eyebrow}</span>
        </div>

        {/* Heading conforming to Page H1 standard */}
        <h1 className="page-h1 text-[#294936] mb-4 animate-text-reveal delay-200">
          {title}
        </h1>

        {/* Description conforming to Body Lead & reading width standard */}
        <p className="body-lead text-[#26332B]/85 animate-fade-up delay-300">
          {description}
        </p>
      </SectionContainer>
    </header>
  );
};
