import React from 'react';
import { AlertCircle, Activity, Clock, ShieldAlert, ArrowRight } from 'lucide-react';
import { PRIORITY_CARE_ITEMS } from '../data/svccData';
import { SvccArtwork } from './SvccArtwork';
import { ScrollReveal } from './ScrollReveal';
import { ImageParallax } from './ImageParallax';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { useNavigate } from 'react-router-dom';
import { SectionContainer } from './SectionContainer';
import { useCms } from '../cms/CmsContext';

interface PriorityCareSectionProps {
  onContactEmergency?: () => void;
}

export const PriorityCareSection: React.FC<PriorityCareSectionProps> = ({ onContactEmergency }) => {
  const navigate = useNavigate();
  const { data } = useCms();
  const priorityItems = data?.collections?.priorityCare?.length ? data.collections.priorityCare : PRIORITY_CARE_ITEMS;

  const { ref: sectionRef, isIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  const getPriorityIcon = (name: string) => {
    switch (name) {
      case 'AlertCircle':
        return <AlertCircle className="w-6 h-6 text-[#E86A10]" />;
      case 'Activity':
        return <Activity className="w-6 h-6 text-[#6F8F72]" />;
      case 'Clock':
        return <Clock className="w-6 h-6 text-[#1a3d1a]" />;
      default:
        return <ShieldAlert className="w-6 h-6 text-[#E86A10]" />;
    }
  };

  const handleCardAction = (index: number) => {
    if (index === 0) {
      if (onContactEmergency) onContactEmergency();
      else navigate('/contact');
    } else if (index === 1) {
      navigate('/clinical');
    } else {
      navigate('/seva');
    }
  };

  const getActionLabel = (index: number) => {
    if (index === 0) return 'Emergency Dispatch Hotline';
    if (index === 1) return 'Explore Outpatient Clinic';
    return 'View Gaushala Care & Shelter';
  };

  return (
    <section
      id="priority-care"
      ref={sectionRef}
      style={{
        paddingTop: 'clamp(28px, 3.5vw, 44px)',
        paddingBottom: 'clamp(28px, 3.5vw, 44px)',
      }}
      className="w-full bg-[#FFFFFF] relative overflow-hidden"
    >
      <SectionContainer>
        {/* Section Heading & Subtitle */}
        <div className="text-center max-w-3xl mx-auto mb-6 sm:mb-7">
          <ScrollReveal animation="fade-in" delay={80} reverseOnScrollUp={false}>
            <span className="label-eyebrow text-[#E86A10]">
              Triage & Rapid Response Hierarchy
            </span>
          </ScrollReveal>

          <ScrollReveal animation="text-reveal" delay={140} reverseOnScrollUp={false}>
            <h2 className="section-h2 text-[#1a3d1a] mt-1.5">
              Priority Care Architecture
            </h2>
          </ScrollReveal>

          <ScrollReveal animation="fade-up" delay={200} reverseOnScrollUp={false}>
            <p className="body-lead mt-2 text-[#1a3d1a]/85 mx-auto text-sm sm:text-base">
              Structured clinical tiers ensure life-threatening emergencies receive instant resuscitation, while chronic illnesses and post-op patients undergo continuous healing oversight.
            </p>
          </ScrollReveal>
        </div>

        {/* Section Primary Image with Parallax & Photo Reveal */}
        <ScrollReveal animation="photo-reveal" delay={220} reverseOnScrollUp={false} className="mb-6 max-w-3xl mx-auto">
          <div className="rounded-2xl overflow-hidden border border-[#1a3d1a]/15 shadow-xs">
            <ImageParallax speed={0.04} maxOffset={18}>
              <div className="aspect-[24/9] max-h-[160px] w-full">
                <SvccArtwork variant="medical" className="w-full h-full" />
              </div>
            </ImageParallax>
          </div>
        </ScrollReveal>

        {/* Three Staggered Visual Blocks */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-5 items-stretch">
          {priorityItems.map((item, index) => {
            const isCritical = item.urgency === 'critical';
            return (
              <ScrollReveal
                key={item.id}
                animation="fade-up"
                delay={240 + index * 60}
                reverseOnScrollUp={false}
                className="h-full"
              >
                <div
                  className={`svcc-card relative bg-[#EFFDF0] rounded-2xl p-4.5 sm:p-5 border transition-all duration-300 flex flex-col justify-between h-full ${
                    isCritical
                      ? 'border-[#E86A10]/40 shadow-xs ring-1 ring-[#E86A10]/20'
                      : 'border-[#1a3d1a]/15 shadow-2xs'
                  }`}
                >
                  <div className="card-accent-line" />

                  <div>
                    {/* Header */}
                    <div className="flex items-center justify-between mb-3">
                      <div className="card-icon-float w-10 h-10 rounded-xl bg-white border border-[#1a3d1a]/10 flex items-center justify-center shadow-2xs">
                        {getPriorityIcon(item.iconName)}
                      </div>
                      <span className={`text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                        isCritical
                          ? 'bg-[#E86A10] text-white border-[#E86A10]'
                          : 'bg-white text-[#1a3d1a] border-[#1a3d1a]/15'
                      }`}>
                        Tier 0{index + 1}
                      </span>
                    </div>

                    <h3 className="sub-h3 text-[#1a3d1a] mb-0.5 text-base sm:text-lg">
                      {item.title}
                    </h3>
                    <div className="text-[11px] font-semibold uppercase tracking-wider text-[#E86A10] mb-2">
                      {item.subtitle}
                    </div>

                    <p className="card-body-text text-[#1a3d1a]/85 mb-3 text-xs sm:text-sm">
                      {item.description}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-[#1a3d1a]/10 flex flex-col justify-between">
                    <div className="text-xs font-medium text-[#1a3d1a]/90 bg-white/90 p-2.5 rounded-xl border border-[#1a3d1a]/10 leading-normal mb-2.5">
                      <span className="font-semibold text-[#1a3d1a] block mb-0.5">Response Protocol:</span>
                      {item.responseProtocol}
                    </div>

                    <button
                      onClick={() => handleCardAction(index)}
                      className={`w-full btn-text min-h-[40px] py-2 px-3.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs transition-colors ${
                        isCritical
                          ? 'bg-[#E86A10] hover:bg-[#d45e0d] text-white shadow-xs'
                          : 'bg-[#1a3d1a] hover:bg-[#2a5a2a] text-[#EFFDF0]'
                      }`}
                    >
                      <span>{getActionLabel(index)}</span>
                      <ArrowRight className="w-3.5 h-3.5 btn-icon-move" />
                    </button>
                  </div>
                </div>
              </ScrollReveal>
            );
          })}
        </div>
      </SectionContainer>
    </section>
  );
};
