import React, { useState } from 'react';
import { ZoomIn } from 'lucide-react';
import { GALLERY_ITEMS } from '../data/svccData';
import { GalleryItem } from '../types';
import { LightboxModal } from './LightboxModal';
import { SvccArtwork } from './SvccArtwork';
import { ScrollReveal } from './ScrollReveal';
import { ImageParallax } from './ImageParallax';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from './SectionContainer';

import { useCms } from '../cms/CmsContext';

export const GallerySection: React.FC = () => {
  const { data } = useCms();
  const galleryItems = data?.collections?.gallery?.length ? data.collections.gallery : GALLERY_ITEMS;

  const { ref: sectionRef, isIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  const [activeItem, setActiveItem] = useState<GalleryItem | null>(null);

  const handleSelectNext = () => {
    if (!activeItem) return;
    const currentIndex = galleryItems.findIndex((i) => i.id === activeItem.id);
    const nextIndex = (currentIndex + 1) % galleryItems.length;
    setActiveItem(galleryItems[nextIndex]);
  };

  const handleSelectPrev = () => {
    if (!activeItem) return;
    const currentIndex = galleryItems.findIndex((i) => i.id === activeItem.id);
    const prevIndex = (currentIndex - 1 + galleryItems.length) % galleryItems.length;
    setActiveItem(galleryItems[prevIndex]);
  };

  const getArtworkVariant = (id: string): 'hero' | 'satpathy' | 'medical' | 'surgical' | 'gaushala' | 'rehab' | 'emergency' => {
    if (id === 'gal-2') return 'gaushala';
    if (id === 'gal-3') return 'surgical';
    if (id === 'gal-4' || id === 'gal-5') return 'hero';
    if (id === 'gal-6') return 'gaushala';
    return 'medical';
  };

  return (
    <section
      id="gallery"
      ref={sectionRef}
      style={{
        paddingTop: 'clamp(28px, 3.5vw, 44px)',
        paddingBottom: 'clamp(28px, 3.5vw, 44px)',
      }}
      className="w-full bg-[#EFFDF0] relative"
    >
      <SectionContainer>
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-6 sm:mb-8">
          <ScrollReveal animation="fade-in" delay={100} reverseOnScrollUp={false}>
            <span className="label-eyebrow text-[#6F8F72]">
              Field Documentary & Treatment Records
            </span>
          </ScrollReveal>

          <ScrollReveal animation="text-reveal" delay={180} reverseOnScrollUp={false}>
            <h2 className="section-h2 text-[#1a3d1a] mt-2">
              SVCC Seva Gallery
            </h2>
          </ScrollReveal>

          <ScrollReveal animation="fade-up" delay={260} reverseOnScrollUp={false}>
            <p className="body-lead mt-3 text-[#1a3d1a]/85 mx-auto">
              Authentic visual accounts capturing emergency rescues, surgical recoveries, and rural cattle health camps across Maharashtra.
            </p>
          </ScrollReveal>
        </div>

        {/* Gallery Grid with Reversible Scroll & ImageParallax */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6 items-stretch">
          {galleryItems.map((item, index) => (
            <ScrollReveal
              key={item.id}
              animation="scale-in"
              delay={120 + (index % 3) * 100}
              reverseOnScrollUp={false}
              className="h-full"
            >
              <div
                onClick={() => setActiveItem(item)}
                className="group relative rounded-3xl overflow-hidden border border-[#1a3d1a]/15 bg-white shadow-xs hover:shadow-xl cursor-pointer transition-all duration-400 hover:-translate-y-1.5 h-full flex flex-col justify-between"
              >
                {/* Image Container with Parallax & Hover Zoom */}
                <div className="aspect-4/3 w-full bg-[#EDE4D3] overflow-hidden relative">
                  <ImageParallax speed={0.05} maxOffset={25}>
                    {item.imageUrl ? (
                      <img
                        src={item.imageUrl}
                        alt={item.title}
                        className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-108"
                      />
                    ) : (
                      <SvccArtwork
                        variant={getArtworkVariant(item.id)}
                        className="w-full h-full transition-transform duration-700 ease-out group-hover:scale-108"
                      />
                    )}
                  </ImageParallax>

                  {/* Brand Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1a3d1a]/90 via-[#1a3d1a]/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-5 text-white z-10 pointer-events-none">
                    <div className="flex items-center gap-1.5 text-xs text-[#EDE4D3] mb-1.5 translate-y-2 group-hover:translate-y-0 transition-transform duration-300 font-medium">
                      <ZoomIn className="w-4 h-4 text-[#E86A10]" />
                      <span>Click to view full photo</span>
                    </div>
                    <span className="text-base font-serif font-bold leading-snug drop-shadow-sm">
                      {item.title}
                    </span>
                  </div>
                </div>

                <div className="p-4 sm:p-5 bg-white">
                  <div className="flex items-center justify-between text-xs text-[#6F8F72] font-semibold mb-1">
                    <span>{item.category}</span>
                    <span className="text-gray-500 font-normal">{item.date}</span>
                  </div>
                  <h3 className="text-base sm:text-lg font-serif font-bold text-[#1a3d1a] line-clamp-1 group-hover:text-[#E86A10] transition-colors">
                    {item.title}
                  </h3>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </SectionContainer>

      {/* Lightbox Modal */}
      <LightboxModal
        item={activeItem}
        items={galleryItems}
        onClose={() => setActiveItem(null)}
        onSelectNext={handleSelectNext}
        onSelectPrev={handleSelectPrev}
      />
    </section>
  );
};
