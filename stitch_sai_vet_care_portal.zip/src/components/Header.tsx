import React, { useState, useEffect, useRef } from 'react';
import { NavLink, Link, useLocation, useNavigate } from 'react-router-dom';
import {
  ChevronDown,
  Search,
  PhoneCall,
  Menu,
  X,
  HeartHandshake,
  ShieldCheck,
  Stethoscope,
  Scissors,
  MapPin,
  Camera,
  BookOpen,
  Users,
  Feather,
  Sparkles,
} from 'lucide-react';

import { useCms } from '../cms/CmsContext';

interface HeaderProps {
  reducedMotion?: boolean;
  onToggleReducedMotion?: () => void;
}

interface SubMenuItem {
  label: string;
  to: string;
  description: string;
  icon: React.ReactNode;
}

interface NavGroup {
  label: string;
  to?: string;
  subItems?: SubMenuItem[];
}

export const Header: React.FC<HeaderProps> = () => {
  const { data } = useCms();
  const cmsHeader = data?.header;
  const cmsSettings = data?.settings;

  const [isScrolled, setIsScrolled] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [mobileExpandedGroup, setMobileExpandedGroup] = useState<string | null>(null);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const location = useLocation();
  const navigate = useNavigate();
  const dropdownTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const searchInputRef = useRef<HTMLInputElement | null>(null);

  // Monitor scroll for shadow enhancement
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 15);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close menus on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
    setOpenDropdown(null);
  }, [location.pathname]);

  // Focus search input when modal opens
  useEffect(() => {
    if (showSearchModal) {
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 50);
    } else {
      setSearchQuery('');
    }
  }, [showSearchModal]);

  // Handle ESC key to close search modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && showSearchModal) {
        setShowSearchModal(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showSearchModal]);

  const handleLinkNavigation = (to?: string) => {
    setOpenDropdown(null);
    setIsMobileMenuOpen(false);
    if (!to) return;
    if (to.includes('#')) {
      const parts = to.split('#');
      const targetPath = parts[0] || '/';
      const targetHash = parts[1];
      if (location.pathname !== targetPath) {
        navigate(targetPath);
      }
      setTimeout(() => {
        const el = document.getElementById(targetHash);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 150);
    } else {
      navigate(to);
    }
  };

  // Original curated 6 Navigation Groups with rich submenus
  const navGroups: NavGroup[] = [
    {
      label: 'Home',
      to: '/',
    },
    {
      label: 'About Us',
      subItems: [
        {
          label: 'About Sai Vet Care',
          to: '/about',
          description: 'Estd 2009 in Moradabad by Dr. Chandra Bhanu Satpathy Ji',
          icon: <HeartHandshake className="w-4 h-4 text-[#E86A10]" />,
        },
        {
          label: 'Dr. C.B. Satpathy Ji Vision',
          to: '/about',
          description: '"Every living being deserves care and dignity" timeline',
          icon: <Feather className="w-4 h-4 text-[#1a3d1a]" />,
        },
        {
          label: 'Governance & Trust',
          to: '/about',
          description: 'Shri Sai Karuna Sansthan & Shri Shirdi Sai Global Foundation',
          icon: <ShieldCheck className="w-4 h-4 text-[#2a5a2a]" />,
        },
      ],
    },
    {
      label: 'Veterinary Seva',
      subItems: [
        {
          label: '9 Areas of Seva',
          to: '/seva',
          description: 'Accidents, critical illness, gaushala visits & preventive care',
          icon: <Stethoscope className="w-4 h-4 text-[#E86A10]" />,
        },
        {
          label: 'Clinical OPD & Operation Theatre',
          to: '/clinical',
          description: 'Dedicated examination room, surgery & sterile procedures',
          icon: <Scissors className="w-4 h-4 text-[#1a3d1a]" />,
        },
        {
          label: 'Free Medicines & Dispensary',
          to: '/clinical',
          description: '14 essential veterinary boluses, powders, sprays & supplements',
          icon: <ShieldCheck className="w-4 h-4 text-[#2a5a2a]" />,
        },
        {
          label: 'Major Seva Projects',
          to: '/#projects',
          description: 'Catalog of continuous veterinary & shelter missions',
          icon: <Sparkles className="w-4 h-4 text-[#E86A10]" />,
        },
      ],
    },
    {
      label: 'Network & Gaushalas',
      subItems: [
        {
          label: '5 Service Locations',
          to: '/network',
          description: 'Mahal Kapoor, Ramganga Paar, Bilari, and Kanth Road centres',
          icon: <MapPin className="w-4 h-4 text-[#E86A10]" />,
        },
        {
          label: '7 Partner Gaushalas (2,000+ Cattle)',
          to: '/network',
          description: 'Vrihad, Kanha, Maa Bhagwati, and Divya Lok sanctuaries',
          icon: <ShieldCheck className="w-4 h-4 text-[#2a5a2a]" />,
        },
        {
          label: 'Our Medical Team',
          to: '/team',
          description: 'Senior veterinary surgeon, clinical specialist & caregivers',
          icon: <Users className="w-4 h-4 text-[#1a3d1a]" />,
        },
      ],
    },
    {
      label: 'Stories & Gallery',
      subItems: [
        {
          label: 'Documentary Gallery',
          to: '/gallery',
          description: 'Photographic records from clinic OPD, OT & gaushala camps',
          icon: <Camera className="w-4 h-4 text-[#E86A10]" />,
        },
        {
          label: 'Patient Recovery Stories',
          to: '/stories',
          description: 'Field chronicles of rescued cattle, bullocks & injured strays',
          icon: <BookOpen className="w-4 h-4 text-[#1a3d1a]" />,
        },
      ],
    },
    {
      label: 'Contact',
      to: '/contact',
    },
  ];

  const handleMouseEnter = (label: string) => {
    if (dropdownTimeoutRef.current) clearTimeout(dropdownTimeoutRef.current);
    setOpenDropdown(label);
  };

  const handleMouseLeave = () => {
    dropdownTimeoutRef.current = setTimeout(() => {
      setOpenDropdown(null);
    }, 180);
  };

  // Search items list for filter
  const searchableLinks = [
    { title: 'Emergency Roadside Trauma Dispatch', path: '/contact', category: 'Emergency' },
    { title: 'Hospital Directory & Footer (5 Moradabad Centres & Hotlines)', path: '/#footer', category: 'Footer' },
    { title: 'Treatment of Accident & Injury Cases', path: '/seva', category: 'Seva' },
    { title: 'Treatment of Critically & Seriously Ill Animals', path: '/seva', category: 'Seva' },
    { title: 'Free Medicines & Dispensary Formulary', path: '/clinical', category: 'Clinical' },
    { title: 'Sterile Operation Theatre & Surgery', path: '/clinical', category: 'Clinical' },
    { title: '7 Partner Gaushalas & Bovine Care', path: '/network', category: 'Gaushala' },
    { title: '5 Moradabad Service Outposts', path: '/network', category: 'Network' },
    { title: 'Emergency Dispatch Hotlines (Mahal Kapoor, Bilari, Kafiyabad)', path: '/#footer', category: 'Hotlines' },
    { title: 'Dr. Chandra Bhanu Satpathy Ji Vision', path: '/about', category: 'Foundation' },
    { title: 'Institutional Governance & Shri Sai Karuna Sansthan', path: '/about', category: 'Governance' },
    { title: 'Veterinary Doctors & Clinical Staff', path: '/team', category: 'Team' },
    { title: 'Documentary Photo Gallery', path: '/gallery', category: 'Gallery' },
    { title: 'Animal Recovery Case Chronicles', path: '/stories', category: 'Stories' },
  ];

  const filteredLinks = searchQuery.trim()
    ? searchableLinks.filter((item) =>
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : searchableLinks.slice(0, 6);

  const emergencyPhone = cmsHeader?.emergencyButtonPhone || cmsSettings?.emergencyPhone || '8191921647';
  const emergencyLabel = cmsHeader?.emergencyButtonText || 'Emergency Call';

  return (
    <header className="w-full sticky top-0 z-50 bg-[#FAF8F5] transition-shadow duration-300">
      {/* ==================================================================== */}
      {/* LAYER 1: TOP INFORMATION BAR (Dark Forest-Green)                     */}
      {/* ==================================================================== */}
      {cmsHeader?.topBarEnabled !== false && (
        <div className="w-full bg-[#1a3d1a] text-white border-b border-white/10">
          <div className="w-full max-w-[1400px] mx-auto min-h-[28px] sm:min-h-[30px] py-0.5 px-3 sm:px-6 lg:px-8 flex items-center justify-between gap-2 text-xs tracking-normal">
            {/* Left Side: Organization Affiliation */}
            <div className="flex items-center gap-1.5 sm:gap-2 min-w-0 truncate">
              <span className="font-semibold text-[#E86A10] whitespace-nowrap text-[10px] sm:text-xs">
                A Unit of Shri Sai Karuna Sansthan
              </span>
              <span className="hidden sm:inline text-white/40">·</span>
              <span className="hidden md:inline text-white/90 whitespace-nowrap font-normal text-[11px] sm:text-xs truncate">
                Under the Aegis of Shri Shirdi Sai Global Foundation
              </span>
            </div>

            {/* Right Side: Location & Emergency Hotline */}
            <div className="flex items-center shrink-0 text-white/85 whitespace-nowrap gap-1.5 sm:gap-2.5">
              <button
                onClick={() => handleLinkNavigation('/#footer')}
                className="hidden md:inline text-white/75 hover:text-white font-normal transition-colors cursor-pointer text-[11px] sm:text-xs"
                title="Jump to 5 Moradabad Service Centres in Footer"
              >
                Moradabad, UP
              </button>
              <span className="hidden md:inline text-white/30">|</span>
              <a
                href={`tel:${emergencyPhone.replace(/\s+/g, '')}`}
                className="flex items-center gap-1 sm:gap-1.5 font-bold text-[#E86A10] hover:text-white transition-colors cursor-pointer group"
                title={`Call Emergency Hotline: ${emergencyPhone}`}
              >
                <PhoneCall className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-[#E86A10] group-hover:text-white transition-colors shrink-0" />
                <span className="font-mono tracking-tight text-[10.5px] sm:text-xs">
                  {emergencyPhone}
                </span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* LAYER 2: MAIN NAVIGATION BAR (Warm Off-White)                        */}
      {/* ==================================================================== */}
      <div
        className={`w-full bg-[#FAF8F5] border-b border-[#1a3d1a]/10 transition-shadow duration-300 ${
          isScrolled ? 'shadow-xs' : ''
        }`}
      >
        <div className="w-full max-w-[1400px] mx-auto min-h-[56px] sm:min-h-[62px] lg:h-[70px] px-3 sm:px-6 lg:px-8 flex items-center justify-between gap-2 sm:gap-4">
          {/* ---------------------------------------------------------------- */}
          {/* GROUP 1: LOGO & BRANDING                                        */}
          {/* ---------------------------------------------------------------- */}
          <div className="flex items-center shrink-0 min-w-0">
            <Link
              to="/"
              className="flex items-center gap-2 sm:gap-3 text-left group focus:outline-hidden"
              aria-label="Sai Vet Care — Return to Home"
            >
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl bg-[#1a3d1a] text-[#EFFDF0] flex items-center justify-center shrink-0 shadow-xs transition-transform duration-300 group-hover:scale-105">
                <HeartHandshake className="w-4 h-4 sm:w-5 sm:h-5 text-[#E86A10]" />
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-serif text-[17px] sm:text-[21px] lg:text-[23px] font-normal tracking-tight text-[#1a3d1a] leading-none whitespace-nowrap">
                  Sai Vet Care
                </span>
                <span className="text-[7.5px] sm:text-[9px] lg:text-[9.5px] uppercase tracking-wider text-[#1a3d1a]/70 font-semibold mt-0.5 sm:mt-1 leading-none whitespace-nowrap">
                  SERVICE TO EVERY LIVING BEING
                </span>
                <span className="hidden sm:inline text-[8px] sm:text-[9px] uppercase tracking-widest text-[#6F8F72] font-semibold mt-0.5 leading-none">
                  ESTD 2009
                </span>
              </div>
            </Link>

            {/* Subtle Vertical Divider */}
            <div className="hidden 2xl:block h-8 w-px bg-[#1a3d1a]/15 ml-4 mr-4 shrink-0" />
            <div className="hidden lg:block 2xl:hidden h-7 w-px bg-[#1a3d1a]/15 ml-3 mr-3 shrink-0" />
          </div>

          {/* ---------------------------------------------------------------- */}
          {/* GROUP 2: PRIMARY NAVIGATION (Single-Line Desktop Links: lg & up) */}
          {/* ---------------------------------------------------------------- */}
          <nav
            className="hidden lg:flex items-center gap-2 xl:gap-4 2xl:gap-6 shrink-0"
            aria-label="Primary Navigation"
          >
            {navGroups.map((group) => {
              const hasSubItems = !!group.subItems && group.subItems.length > 0;
              const isGroupActive = group.to
                ? location.pathname === group.to
                : group.subItems?.some((sub) => location.pathname === sub.to);

              // Single Link without dropdown (Home, Contact)
              if (!hasSubItems && group.to) {
                return (
                  <NavLink
                    key={group.label}
                    to={group.to}
                    className={({ isActive }) =>
                      `relative py-1.5 px-1 text-[13.5px] xl:text-[14.5px] 2xl:text-[15px] font-medium tracking-normal whitespace-nowrap transition-colors group ${
                        isActive
                          ? 'text-[#1a3d1a] font-semibold'
                          : 'text-[#1a3d1a]/80 hover:text-[#1a3d1a]'
                      }`
                    }
                  >
                    {({ isActive }) => (
                      <>
                        <span>{group.label}</span>
                        {/* 2px dark-green underline for active/hover state */}
                        <span
                          className={`absolute bottom-0 left-0 h-[2px] bg-[#1a3d1a] transition-all duration-300 ease-out rounded-full ${
                            isActive ? 'w-full' : 'w-0 group-hover:w-full'
                          }`}
                        />
                      </>
                    )}
                  </NavLink>
                );
              }

              // Menu with dropdown
              return (
                <div
                  key={group.label}
                  className="relative"
                  onMouseEnter={() => handleMouseEnter(group.label)}
                  onMouseLeave={handleMouseLeave}
                >
                  <button
                    className={`flex items-center gap-1 py-1.5 px-1 text-[13.5px] xl:text-[14.5px] 2xl:text-[15px] font-medium tracking-normal whitespace-nowrap transition-colors cursor-pointer focus:outline-hidden ${
                      isGroupActive || openDropdown === group.label
                        ? 'text-[#1a3d1a] font-semibold'
                        : 'text-[#1a3d1a]/80 hover:text-[#1a3d1a]'
                    }`}
                    aria-expanded={openDropdown === group.label}
                    aria-haspopup="true"
                  >
                    <span>{group.label}</span>
                    <ChevronDown
                      className={`w-3 h-3 transition-transform duration-200 shrink-0 ${
                        openDropdown === group.label
                          ? 'rotate-180 text-[#E86A10]'
                          : 'text-[#1a3d1a]/50'
                      }`}
                    />
                  </button>

                  {/* Dropdown Menu */}
                  {openDropdown === group.label && group.subItems && (
                    <div
                      className="dropdown-menu absolute top-full left-0 pt-2 w-72 rounded-2xl bg-white p-2.5 shadow-xl border border-[#1a3d1a]/15 z-50 animate-fade-in"
                      onMouseEnter={() => handleMouseEnter(group.label)}
                      onMouseLeave={handleMouseLeave}
                    >
                      <div className="space-y-1">
                        {group.subItems.map((subItem) => (
                          <Link
                            key={subItem.label}
                            to={subItem.to}
                            onClick={() => handleLinkNavigation(subItem.to)}
                            className="flex items-start gap-2.5 p-2 rounded-xl hover:bg-[#FAF8F5] transition-colors group/sub"
                          >
                            <div className="w-7 h-7 rounded-lg bg-[#FAF8F5] border border-[#1a3d1a]/10 flex items-center justify-center shrink-0 mt-0.5 group-hover/sub:bg-white group-hover/sub:scale-105 transition-all">
                              {subItem.icon}
                            </div>
                            <div>
                              <div className="text-xs font-semibold text-[#1a3d1a] group-hover/sub:text-[#E86A10] transition-colors">
                                {subItem.label}
                              </div>
                              <p className="text-[10.5px] text-gray-500 leading-tight mt-0.5">
                                {subItem.description}
                              </p>
                            </div>
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </nav>

          {/* ---------------------------------------------------------------- */}
          {/* GROUP 3: ACTIONS (Search + Emergency Call + Mobile Menu Toggle)  */}
          {/* ---------------------------------------------------------------- */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 lg:gap-3 shrink-0">
            {/* Search Button (Circular, compact, white bg, subtle border) */}
            <button
              onClick={() => setShowSearchModal(true)}
              className="w-8 h-8 sm:w-9.5 sm:h-9.5 rounded-full border border-[#1a3d1a]/20 bg-white hover:border-[#1a3d1a] flex items-center justify-center text-[#1a3d1a] hover:bg-[#FAF8F5] transition-all cursor-pointer shadow-xs focus:outline-hidden focus:ring-2 focus:ring-[#1a3d1a]/30 shrink-0"
              aria-label="Search"
              title="Search clinic services & resources"
            >
              <Search className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#1a3d1a]" />
            </button>

            {/* Emergency Call Button (Primary Action, Clean Orange Background) */}
            {cmsHeader?.showEmergencyButton !== false && (
              <a
                href={`tel:${emergencyPhone.replace(/\s+/g, '')}`}
                className="h-8 sm:h-auto px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-xl bg-[#E86A10] hover:bg-[#d45e0d] text-white flex items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer shadow-xs focus:outline-hidden focus:ring-2 focus:ring-[#E86A10]/40 group shrink-0"
                aria-label={`Emergency Call ${emergencyPhone}`}
                title={`24/7 Roadside Animal Emergency Dispatch: ${emergencyPhone}`}
              >
                <PhoneCall className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white shrink-0 group-hover:scale-105 transition-transform" />
                <div className="hidden xs:flex flex-col text-left leading-none">
                  <span className="text-[9px] sm:text-[10px] uppercase tracking-wider font-semibold text-white/95 leading-tight whitespace-nowrap">
                    {emergencyLabel}
                  </span>
                  <span className="hidden sm:inline text-xs sm:text-[13px] font-bold font-mono tracking-tight text-white leading-tight mt-0.5 whitespace-nowrap">
                    {emergencyPhone}
                  </span>
                </div>
              </a>
            )}

            {/* Mobile / Tablet Hamburger Button (< lg) */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden w-8.5 h-8.5 sm:w-10 sm:h-10 rounded-xl text-[#1a3d1a] hover:bg-[#1a3d1a]/10 flex items-center justify-center focus:outline-hidden transition-colors shrink-0 cursor-pointer"
              aria-label="Toggle navigation menu"
              aria-expanded={isMobileMenuOpen}
            >
              {isMobileMenuOpen ? <X className="w-5 h-5 sm:w-6 sm:h-6" /> : <Menu className="w-5 h-5 sm:w-6 sm:h-6" />}
            </button>
          </div>
        </div>

        {/* ------------------------------------------------------------------ */}
        {/* MOBILE MENU ACCORDION DRAWER (< lg)                                */}
        {/* ------------------------------------------------------------------ */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-[#1a3d1a]/10 bg-white p-4 sm:p-6 shadow-xl animate-fade-in max-h-[85vh] overflow-y-auto">
            <div className="space-y-2 max-w-md mx-auto">
              {navGroups.map((group) => {
                const hasSubItems = !!group.subItems && group.subItems.length > 0;
                const isExpanded = mobileExpandedGroup === group.label;

                if (!hasSubItems && group.to) {
                  return (
                    <NavLink
                      key={group.label}
                      to={group.to}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={({ isActive }) =>
                        `block px-4 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                          isActive
                            ? 'bg-[#1a3d1a] text-white'
                            : 'text-[#1a3d1a] hover:bg-[#FAF8F5]'
                        }`
                      }
                    >
                      {group.label}
                    </NavLink>
                  );
                }

                return (
                  <div key={group.label} className="border-b border-gray-100 pb-1">
                    <button
                      onClick={() =>
                        setMobileExpandedGroup(isExpanded ? null : group.label)
                      }
                      className="w-full flex items-center justify-between px-4 py-2.5 text-sm font-semibold text-[#1a3d1a] hover:bg-[#FAF8F5] rounded-xl cursor-pointer"
                    >
                      <span>{group.label}</span>
                      <ChevronDown
                        className={`w-4 h-4 transition-transform duration-200 ${
                          isExpanded ? 'rotate-180 text-[#E86A10]' : 'text-gray-400'
                        }`}
                      />
                    </button>

                    {isExpanded && group.subItems && (
                      <div className="pl-4 pr-2 py-2 space-y-1 bg-[#FAF8F5] rounded-xl my-1 animate-fade-in">
                        {group.subItems.map((sub) => (
                          <Link
                            key={sub.label}
                            to={sub.to}
                            onClick={() => handleLinkNavigation(sub.to)}
                            className="flex items-start gap-2.5 py-2 px-3 text-xs font-medium text-gray-700 hover:text-[#E86A10] rounded-lg transition-colors"
                          >
                            <div className="mt-0.5 shrink-0">{sub.icon}</div>
                            <div>
                              <div className="font-semibold text-[#1a3d1a]">{sub.label}</div>
                              <p className="text-[11px] text-gray-500 mt-0.5">{sub.description}</p>
                            </div>
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Mobile Quick Action Links */}
              <div className="pt-3 space-y-2">
                <a
                  href={`tel:${emergencyPhone.replace(/\s+/g, '')}`}
                  className="w-full py-3 px-4 rounded-xl bg-[#E86A10] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-xs hover:bg-[#d45e0d] transition-colors"
                >
                  <PhoneCall className="w-4 h-4 text-white" />
                  <span>Call Emergency Rescue: {emergencyPhone}</span>
                </a>
                <button
                  onClick={() => handleLinkNavigation('/#footer')}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#1a3d1a]/5 text-[#1a3d1a] hover:bg-[#1a3d1a]/10 text-xs font-semibold flex items-center justify-center gap-2 border border-[#1a3d1a]/10 transition-colors cursor-pointer"
                >
                  <span>View Hospital Directory & 5 Service Centres</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ==================================================================== */}
      {/* QUICK SEARCH MODAL (Interactive & Accessible)                        */}
      {/* ==================================================================== */}
      {showSearchModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Search Sai Vet Care services"
          className="fixed inset-0 z-50 flex items-start justify-center pt-24 px-4 bg-black/50 backdrop-blur-xs animate-fade-in"
          onClick={() => setShowSearchModal(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-lg w-full p-5 shadow-2xl border border-[#1a3d1a]/20 animate-scale-in"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Search Input Bar */}
            <div className="flex items-center gap-2 pb-3 border-b border-gray-100">
              <Search className="w-4 h-4 text-[#1a3d1a] shrink-0" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search services, surgery, gaushalas, outpatient..."
                className="w-full text-sm outline-hidden text-[#1a3d1a] placeholder:text-gray-400"
              />
              <button
                onClick={() => setShowSearchModal(false)}
                className="text-xs font-semibold px-2 py-1 rounded bg-gray-100 text-gray-500 hover:bg-gray-200 cursor-pointer"
                aria-label="Close search"
              >
                ESC
              </button>
            </div>

            {/* Search Results / Quick Links */}
            <div className="pt-3 space-y-1 text-xs">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-gray-400 mb-2">
                {searchQuery.trim() ? 'Matching Results:' : 'Recommended Quick Links:'}
              </div>

              {filteredLinks.length > 0 ? (
                filteredLinks.map((item, idx) => (
                  <Link
                    key={idx}
                    to={item.path}
                    onClick={() => setShowSearchModal(false)}
                    className="flex items-center justify-between p-2 rounded-lg hover:bg-[#FAF8F5] text-[#1a3d1a] font-medium transition-colors"
                  >
                    <span>{item.title}</span>
                    <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded bg-[#1a3d1a]/10 text-[#1a3d1a]">
                      {item.category}
                    </span>
                  </Link>
                ))
              ) : (
                <div className="p-4 text-center text-gray-500">
                  No services found matching "{searchQuery}".
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
