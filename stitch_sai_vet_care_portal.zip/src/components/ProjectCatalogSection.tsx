import React, { useRef, useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { ArrowUpRight, ShieldCheck, HeartHandshake, MapPin, Activity, Check, Sparkles } from 'lucide-react';
import { SvccArtwork } from './SvccArtwork';
import { ProjectModal, ProjectData } from './ProjectModal';
import { useNavigate } from 'react-router-dom';

const PROJECTS: ProjectData[] = [
  {
    id: 'proj-1',
    number: '01',
    category: 'Emergency Rapid Response',
    title: 'Mobile Rescue & Highway Corridor Fleet',
    subtitle: 'Three dedicated veterinary ambulances providing on-call trauma resuscitation, oxygenation, and rapid triage across 45+ agrarian hamlets.',
    description: 'When large cattle, injured strays, or non-ambulatory animals collapse on highways or in remote fields, transportation to the base hospital is often impossible. The SVCC Mobile Ambulance Fleet brings hospital-grade trauma resuscitation directly to the road with zero toll or fuel charges levied.',
    stats: [
      { label: 'Roadside Rescues', value: '3,420+' },
      { label: 'Average Dispatch', value: '18 Mins' },
      { label: 'Coverage Area', value: '60 Km' },
      { label: 'Toll/Fuel Cost', value: 'Free' },
    ],
    protocols: [
      'Onboard hydraulic ramp lift for non-ambulatory bovine traction',
      'Continuous medical oxygen inhalation & respiratory triage',
      'Emergency splinting & multi-trauma stabilization before transit',
      'Radio dispatch linking field paramedics to the chief hospital surgeon',
    ],
    equipment: ['Hydraulic Cow Lift', 'Portable Ultrasound', 'Oxygen Cylinders', 'Vacuum Trauma Splints'],
    impactBadge: '3,420+ Roadside Rescues',
    artworkVariant: 'emergency',
    location: 'Shirdi — Rahata — Kopargaon Belt',
    leadSurgeonOrOfficer: 'Dr. Anand Deshmukh, B.V.Sc & A.H (Chief Emergency Dispatcher)',
  },
  {
    id: 'proj-2',
    number: '02',
    category: 'Surgical Seva Mission',
    title: 'Aseptic Surgical Theater & Fracture Center',
    subtitle: 'Sterile orthopaedic pinning, soft tissue trauma reconstruction, and internal wound repair executed with positive-pressure HEPA filtration and vital telemetry.',
    description: 'Our central operating suite in Shirdi combines human-hospital sterility standards with dedicated veterinary surgical gear. Every stray animal brought to our table receives aseptic scrubbing, autoclaved titanium pins, and gas anesthesia at zero cost to the compassionate rescuer.',
    stats: [
      { label: 'Major Surgeries', value: '1,840+' },
      { label: 'Healing Success', value: '94.6%' },
      { label: 'Sterile Theaters', value: '2 Suites' },
      { label: 'Commercial Fees', value: 'Rs. 0' },
    ],
    protocols: [
      'UV-C terminal decontamination between every surgical procedure',
      'Continuous isoflurane gas anesthesia & pulse oximetry monitoring',
      'Intramedullary bone pinning and external fixation for fractures',
      'Multimodal opioid-sparing analgesia for humane recovery',
    ],
    equipment: ['Autoclave Sterilizer', 'Isoflurane Vaporizer', 'Cautery Unit', 'Orthopaedic Drill & Pins'],
    impactBadge: '1,840+ Major Procedures',
    artworkVariant: 'surgical',
    location: 'Shirdi Hospital Surgical Complex',
    leadSurgeonOrOfficer: 'Dr. Rameshwar Patil, M.V.Sc (Surgery & Radiology)',
  },
  {
    id: 'proj-3',
    number: '03',
    category: 'Bovine Sanctuary Welfare',
    title: 'Gaushala Sanctuary Medical Network',
    subtitle: 'Comprehensive prophylactic healthcare, geriatric palliative support, and biosecurity across 48 regional cattle sanctuaries housing 12,000+ native cows.',
    description: 'Thousands of elderly, non-milking, or blind indigenous cows reside in pastoral gaushalas throughout Maharashtra. SVCC provides dedicated veterinary rounds, prophylactic herd vaccination against Foot-and-Mouth Disease, and nutritional mineral subsidies to ensure peaceful lifelong sanctuary.',
    stats: [
      { label: 'Sanctuaries Adopted', value: '48 Sites' },
      { label: 'Protected Cattle', value: '12,000+' },
      { label: 'Annual Fodder Subsidy', value: '450 Tons' },
      { label: 'Prophylaxis Rounds', value: 'Weekly' },
    ],
    protocols: [
      'Bi-annual herd deworming & Foot-and-Mouth (FMD) mass vaccination',
      'Geriatric arthritis management using herbal analgesic liniments & soft straw bedding',
      'Emergency bloat decompression & rumenotomy clinical assistance',
      'Clean water trough sanitation & mineral-lick block distribution',
    ],
    equipment: ['Field Rumen Trocar', 'Hoof Trimming Chute', 'Mastitis Rapid Test Kit', 'Mineral Dispensary'],
    impactBadge: '12,000+ Cattle Protected',
    artworkVariant: 'gaushala',
    location: '48 Sanctuaries Across Ahmednagar District',
    leadSurgeonOrOfficer: 'Dr. Sunita Kulkarni, B.V.Sc & A.H (Livestock & Sanctuary Director)',
  },
  {
    id: 'proj-4',
    number: '04',
    category: 'Community Welfare Mission',
    title: 'Rabies-Free Shirdi & Humane ABC Initiative',
    subtitle: 'Humane population stabilization, mass rabies vaccination, and microchipped post-operative foster monitoring safeguarding street packs and pilgrims.',
    description: 'Operating strictly under Animal Welfare Board of India (AWBI) guidelines, our CNVR (Catch-Neuter-Vaccinate-Return) project has established a 100% rabies-vaccinated protective ring around the Shirdi shrine and surrounding towns without ever harming or displacing local street dogs.',
    stats: [
      { label: 'Dogs Vaccinated', value: '8,200+' },
      { label: 'Rabies In Core Belt', value: '0 Cases' },
      { label: 'Post-Op Stay', value: '5-7 Days' },
      { label: 'AWBI Compliance', value: '100%' },
    ],
    protocols: [
      'Humane butterfly-net catching avoiding trauma or fright',
      'Flank and midline keyhole sterilization with internal absorbable sutures',
      'Anti-Rabies Vaccination (ARV) and ear-notch identification',
      'Individual recovery kennels with supervised feeding before return',
    ],
    equipment: ['Microchip Scanners', 'Individual Recovery Kennels', 'Cryosurgical Unit', 'Cold-Chain Vaccine Chest'],
    impactBadge: '8,200+ Vaccinated',
    artworkVariant: 'hero',
    location: 'Shirdi Urban & Rural Municipal Limits',
    leadSurgeonOrOfficer: 'Dr. Priya Sharma, M.V.Sc (Preventive Medicine)',
  },
];

import { ScrollReveal } from './ScrollReveal';
import { SectionContainer } from './SectionContainer';

interface ProjectCardProps {
  project: ProjectData;
  index: number;
  totalCards: number;
  onOpenModal: (project: ProjectData) => void;
}

const ProjectCard: React.FC<ProjectCardProps> = ({
  project,
  index,
  totalCards,
  onOpenModal,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1], delay: index * 0.08 }}
      style={{
        top: `calc(72px + ${index * 26}px)`,
        zIndex: 10 + index,
      }}
      className="sticky w-full max-w-5xl mx-auto mb-10 sm:mb-14 will-change-transform"
    >
      <div className="w-full rounded-2xl sm:rounded-3xl border-2 border-[#6F8F72]/50 bg-[#16291b] p-4.5 sm:p-6 md:p-7 shadow-[0_-10px_35px_rgba(0,0,0,0.55)] hover:border-[#6F8F72] transition-all duration-300 relative overflow-hidden flex flex-col justify-between">
        {/* Ambient Top Glow Line */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#6F8F72] via-[#E86A10] to-[#6F8F72] opacity-80" />

        {/* TOP ROW: Number, Category, Title, and "Live Project" Button */}
        <div>
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3.5 sm:pb-4 border-b border-white/10">
            
            {/* Left: Number + Category + Title */}
            <div className="flex items-center gap-3 sm:gap-4">
              <span className="font-serif-display font-black text-3xl sm:text-5xl text-[#6F8F72] leading-none select-none">
                {project.number}
              </span>

              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#E86A10] bg-[#E86A10]/15 px-2.5 py-0.5 rounded-full border border-[#E86A10]/30 inline-block mb-0.5">
                  {project.category}
                </span>
                <h3 className="text-lg sm:text-xl md:text-2xl font-serif-display font-bold text-[#EFFDF0] leading-snug">
                  {project.title}
                </h3>
              </div>
            </div>

            {/* Right: "Inspect Initiative" Ghost Pill Button */}
            <button
              onClick={() => onOpenModal(project)}
              className="group inline-flex items-center gap-1.5 px-4 sm:px-5 py-2 sm:py-2.5 rounded-full border border-[#D7E2EA]/60 hover:border-[#E86A10] hover:bg-[#E86A10] text-[#EFFDF0] text-xs font-semibold tracking-wider uppercase transition-all duration-200 cursor-pointer shadow-sm"
            >
              <span>Inspect Initiative</span>
              <ArrowUpRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
          </div>

          <p className="mt-2.5 text-xs sm:text-sm text-[#EDE4D3]/85 line-clamp-2 max-w-4xl leading-relaxed">
            {project.subtitle}
          </p>
        </div>

        {/* BOTTOM ROW: Two-Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5 sm:gap-4 pt-3.5 sm:pt-4 items-stretch">
          
          {/* Left Column (40%): Two Stacked Highlight Cards */}
          <div className="lg:col-span-5 flex flex-col gap-2.5 sm:gap-3 justify-between">
            
            {/* Stacked Card 1 */}
            <div className="rounded-xl sm:rounded-2xl bg-[#1c3522] border border-[#6F8F72]/30 p-3 sm:p-3.5 flex flex-col justify-between shadow-2xs">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#6F8F72]">
                  Clinical Standard
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#E86A10]" />
              </div>
              <p className="text-xs text-[#EFFDF0] font-medium leading-relaxed">
                {project.protocols[0]}
              </p>
            </div>

            {/* Stacked Card 2 */}
            <div className="rounded-xl sm:rounded-2xl bg-[#1c3522] border border-[#6F8F72]/30 p-3 sm:p-3.5 flex flex-col justify-between shadow-2xs">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#E86A10]">
                  Field Equipment
                </span>
                <span className="text-[10px] text-gray-300 font-mono">100% Free</span>
              </div>
              <p className="text-xs text-[#EFFDF0] font-medium leading-relaxed">
                {project.protocols[1]}
              </p>
            </div>

            {/* Metrics Ribbon */}
            <div className="grid grid-cols-2 gap-2 pt-0.5">
              <div className="p-2 sm:p-2.5 rounded-xl bg-white/5 border border-white/10 text-center">
                <div className="text-base sm:text-lg font-serif-display font-bold text-[#E86A10]">
                  {project.stats[0].value}
                </div>
                <div className="text-[10px] uppercase text-[#EDE4D3]/70 truncate">
                  {project.stats[0].label}
                </div>
              </div>
              <div className="p-2 sm:p-2.5 rounded-xl bg-white/5 border border-white/10 text-center">
                <div className="text-base sm:text-lg font-serif-display font-bold text-[#6F8F72]">
                  {project.stats[1].value}
                </div>
                <div className="text-[10px] uppercase text-[#EDE4D3]/70 truncate">
                  {project.stats[1].label}
                </div>
              </div>
            </div>

          </div>

          {/* Right Column (60%): Visual Showcase */}
          <div className="lg:col-span-7 rounded-xl sm:rounded-2xl overflow-hidden border border-[#6F8F72]/30 bg-[#1c3522] relative group min-h-[160px] sm:min-h-[180px] md:min-h-[200px] max-h-[220px]">
            <SvccArtwork
              variant={project.artworkVariant}
              className="w-full h-full object-contain transition-transform duration-700 ease-out group-hover:scale-104"
            />

            {/* Bottom Overlay Pill */}
            <div className="absolute bottom-2.5 left-2.5 right-2.5 sm:left-3 sm:right-3 flex items-center justify-between bg-[#142618]/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/15">
              <div className="flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-[#E86A10] animate-pulse" />
                <span className="text-xs font-semibold text-[#EFFDF0]">
                  {project.impactBadge}
                </span>
              </div>
              <span className="text-[10px] text-[#EDE4D3]/70 hidden sm:inline">
                {project.location}
              </span>
            </div>
          </div>

        </div>

      </div>
    </motion.div>
  );
};

export const ProjectCatalogSection: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<ProjectData | null>(null);
  const navigate = useNavigate();

  return (
    <section
      id="projects"
      className="relative w-full bg-[#0e1a11] text-[#EFFDF0] rounded-t-[32px] sm:rounded-t-[44px] -mt-8 sm:-mt-10 z-20 pt-8 sm:pt-10 md:pt-12 pb-16 sm:pb-24 border-t border-[#6F8F72]/30 shadow-2xl"
    >
      <SectionContainer>
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-8 sm:mb-10">
          <ScrollReveal animation="fade-in" delay={80}>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#16291b] border border-[#6F8F72]/30 text-[11px] font-semibold text-[#EDE4D3] mb-2 shadow-2xs">
              <Sparkles className="w-3 h-3 text-[#E86A10]" />
              <span>Flagship Seva Catalog</span>
            </div>
          </ScrollReveal>

          <ScrollReveal animation="text-reveal" delay={140}>
            <h2 className="text-2xl sm:text-4xl md:text-5xl font-serif-display font-bold text-[#EFFDF0] tracking-tight uppercase">
              Major Seva Projects
            </h2>
          </ScrollReveal>

          <ScrollReveal animation="fade-up" delay={200}>
            <p className="mt-2 text-xs sm:text-sm text-[#EDE4D3]/80 leading-relaxed max-w-2xl mx-auto">
              Explore our four core institutional missions. Comprehensive clinical specifications and community welfare coverage.
            </p>
          </ScrollReveal>
        </div>

        {/* Project Cards Stacking Container */}
        <div className="relative pb-8 sm:pb-12">
          {PROJECTS.map((proj, idx) => (
            <ProjectCard
              key={proj.id}
              project={proj}
              index={idx}
              totalCards={PROJECTS.length}
              onOpenModal={(p) => setSelectedProject(p)}
            />
          ))}
        </div>

      </SectionContainer>

      {/* Interactive Project Detail Modal */}
      {selectedProject && (
        <ProjectModal
          project={selectedProject}
          onClose={() => setSelectedProject(null)}
          onEmergencyClick={() => navigate('/contact')}
        />
      )}
    </section>
  );
};
