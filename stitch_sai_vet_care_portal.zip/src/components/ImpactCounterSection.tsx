import React, { useEffect, useState } from 'react';
import { HeartHandshake, ShieldCheck, Sparkles, Building2 } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { ScrollReveal } from './ScrollReveal';
import { SectionContainer } from './SectionContainer';

export const ImpactCounterSection: React.FC = () => {
  const { ref, isIntersecting } = useIntersectionObserver({
    threshold: 0.1,
    triggerOnce: true,
  });

  const [animalCount, setAnimalCount] = useState(0);
  const [treatmentCount, setTreatmentCount] = useState(0);
  const [gaushalaCount, setGaushalaCount] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);

  useEffect(() => {
    if (!isIntersecting) {
      // Reset numbers when scrolled out of view so it recounts when re-entering
      setAnimalCount(0);
      setTreatmentCount(0);
      setGaushalaCount(0);
      setIsCompleted(false);
      return;
    }

    const duration = 1600;
    const startTime = performance.now();

    const targetAnimals = 1670;
    const targetTreatments = 14200;
    const targetGaushalas = 48;

    const easeOutCubic = (t: number): number => 1 - Math.pow(1 - t, 3);

    let animationFrameId: number;

    const updateCounter = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easedProgress = easeOutCubic(progress);

      setAnimalCount(Math.floor(easedProgress * targetAnimals));
      setTreatmentCount(Math.floor(easedProgress * targetTreatments));
      setGaushalaCount(Math.floor(easedProgress * targetGaushalas));

      if (progress < 1) {
        animationFrameId = requestAnimationFrame(updateCounter);
      } else {
        setAnimalCount(targetAnimals);
        setTreatmentCount(targetTreatments);
        setGaushalaCount(targetGaushalas);
        setIsCompleted(true);
      }
    };

    animationFrameId = requestAnimationFrame(updateCounter);

    return () => {
      if (animationFrameId) cancelAnimationFrame(animationFrameId);
    };
  }, [isIntersecting]);

  return (
    <section
      ref={ref}
      style={{
        paddingTop: 'clamp(28px, 3.5vw, 44px)',
        paddingBottom: 'clamp(28px, 3.5vw, 44px)',
      }}
      className="w-full bg-[#1a3d1a] text-[#EFFDF0] relative overflow-hidden"
    >
      {/* Subtle organic arched lines */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <circle cx="20%" cy="10%" r="300" fill="none" stroke="#EFFDF0" strokeWidth="1.5" />
          <circle cx="80%" cy="90%" r="350" fill="none" stroke="#EFFDF0" strokeWidth="1.5" />
        </svg>
      </div>

      <SectionContainer className="relative z-10">
        {/* Section Lead */}
        <div className="text-center max-w-2xl mx-auto mb-6 sm:mb-7">
          <ScrollReveal animation="fade-in" delay={80} reverseOnScrollUp={false}>
            <span className="label-eyebrow text-[#EDE4D3]/80">
              Dedicated Seva Impact Since 2009
            </span>
          </ScrollReveal>

          <ScrollReveal animation="text-reveal" delay={140} reverseOnScrollUp={false}>
            <h2 className="section-h2 text-[#EFFDF0] mt-1.5">
              Quantifiable Veterinary Relief
            </h2>
          </ScrollReveal>
        </div>

        {/* 4 Column Impact Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 items-stretch">
          
          {/* Main Spec Metric: 1,670 animals */}
          <ScrollReveal animation="fade-up" delay={160} reverseOnScrollUp={false} className="h-full">
            <div className={`text-center p-4.5 sm:p-5 rounded-2xl bg-white/10 border border-[#EFFDF0]/15 backdrop-blur-md h-full transition-all duration-300 flex flex-col justify-between ${
              isCompleted ? 'shadow-[0_0_20px_rgba(232,106,16,0.3)] border-[#E86A10]/50' : ''
            }`}>
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#E86A10] text-white flex items-center justify-center mx-auto mb-3 shadow-md">
                  <HeartHandshake className="w-5 h-5" />
                </div>
                <div className="stat-number text-[#EDE4D3] tabular-nums text-3xl sm:text-4xl">
                  {animalCount.toLocaleString()}
                </div>
                <div className="mt-1.5 text-xs font-semibold uppercase tracking-wider text-[#EFFDF0]">
                  Animals Healed & Rescued
                </div>
              </div>
              <p className="mt-1.5 text-xs text-[#EDE4D3]/80 leading-relaxed">
                Critical road traffic victims, calves, and strays brought back to pain-free health.
              </p>
            </div>
          </ScrollReveal>

          {/* Metric 2: 14,200+ Free Treatments */}
          <ScrollReveal animation="fade-up" delay={220} reverseOnScrollUp={false} className="h-full">
            <div className={`text-center p-4.5 sm:p-5 rounded-2xl bg-white/10 border border-[#EFFDF0]/15 backdrop-blur-md h-full transition-all duration-300 flex flex-col justify-between ${
              isCompleted ? 'shadow-[0_0_15px_rgba(111,143,114,0.3)] border-[#6F8F72]/50' : ''
            }`}>
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#6F8F72] text-[#1a3d1a] flex items-center justify-center mx-auto mb-3 shadow-md">
                  <ShieldCheck className="w-5 h-5 text-white" />
                </div>
                <div className="stat-number text-[#EDE4D3] tabular-nums text-3xl sm:text-4xl">
                  {treatmentCount.toLocaleString()}+
                </div>
                <div className="mt-1.5 text-xs font-semibold uppercase tracking-wider text-[#EFFDF0]">
                  Free Treatments Given
                </div>
              </div>
              <p className="mt-1.5 text-xs text-[#EDE4D3]/80 leading-relaxed">
                Sterile wound debridements, digital radiography, and intravenous nutritional therapy.
              </p>
            </div>
          </ScrollReveal>

          {/* Metric 3: 48 Gaushalas Supported */}
          <ScrollReveal animation="fade-up" delay={280} reverseOnScrollUp={false} className="h-full">
            <div className={`text-center p-4.5 sm:p-5 rounded-2xl bg-white/10 border border-[#EFFDF0]/15 backdrop-blur-md h-full transition-all duration-300 flex flex-col justify-between ${
              isCompleted ? 'shadow-[0_0_15px_rgba(232,106,16,0.25)] border-[#E86A10]/50' : ''
            }`}>
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#2a5a2a] text-[#EDE4D3] flex items-center justify-center mx-auto mb-3 shadow-md">
                  <Building2 className="w-5 h-5 text-[#E86A10]" />
                </div>
                <div className="stat-number text-[#EDE4D3] tabular-nums text-3xl sm:text-4xl">
                  {gaushalaCount}
                </div>
                <div className="mt-1.5 text-xs font-semibold uppercase tracking-wider text-[#EFFDF0]">
                  Gaushala Sanctuaries
                </div>
              </div>
              <p className="mt-1.5 text-xs text-[#EDE4D3]/80 leading-relaxed">
                Adopted cattle sanctuaries receiving monthly prophylactic deworming & geriatric care.
              </p>
            </div>
          </ScrollReveal>

          {/* Metric 4: 100% Free Seva Model */}
          <ScrollReveal animation="fade-up" delay={340} reverseOnScrollUp={false} className="h-full">
            <div className={`text-center p-4.5 sm:p-5 rounded-2xl bg-white/10 border border-[#EFFDF0]/15 backdrop-blur-md h-full transition-all duration-300 flex flex-col justify-between ${
              isCompleted ? 'shadow-[0_0_15px_rgba(255,255,255,0.2)] border-white/50' : ''
            }`}>
              <div>
                <div className="w-10 h-10 rounded-xl bg-white text-[#1a3d1a] flex items-center justify-center mx-auto mb-3 shadow-md">
                  <Sparkles className="w-5 h-5 text-[#E86A10]" />
                </div>
                <div className="stat-number text-[#EDE4D3] text-3xl sm:text-4xl">
                  100%
                </div>
                <div className="mt-1.5 text-xs font-semibold uppercase tracking-wider text-[#EFFDF0]">
                  Free Charitable Seva
                </div>
              </div>
              <p className="mt-1.5 text-xs text-[#EDE4D3]/80 leading-relaxed">
                Zero billing or financial gatekeeping ever charged for any distressed animal.
              </p>
            </div>
          </ScrollReveal>

        </div>
      </SectionContainer>
    </section>
  );
};
