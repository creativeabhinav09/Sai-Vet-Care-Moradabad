import React from 'react';
import { Award, GraduationCap, Stethoscope } from 'lucide-react';
import { TEAM_MEMBERS } from '../data/svccData';
import { ScrollReveal } from './ScrollReveal';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from './SectionContainer';
import { useCms } from '../cms/CmsContext';

export const TeamSection: React.FC = () => {
  const { data } = useCms();
  const teamList = data?.collections?.team?.length ? data.collections.team : TEAM_MEMBERS;

  const { ref: sectionRef, isIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  return (
    <section
      id="team"
      ref={sectionRef}
      style={{
        paddingTop: 'clamp(28px, 3.5vw, 44px)',
        paddingBottom: 'clamp(28px, 3.5vw, 44px)',
      }}
      className="w-full bg-[#FFFFFF] relative"
    >
      <SectionContainer>
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-6 sm:mb-8">
          <ScrollReveal animation="fade-in" delay={100} reverseOnScrollUp={false}>
            <span className="label-eyebrow text-[#6F8F72]">
              Veterinary Practitioners & Seva Staff
            </span>
          </ScrollReveal>

          <ScrollReveal animation="text-reveal" delay={200} reverseOnScrollUp={false}>
            <h2 className="section-h2 text-[#1a3d1a] mt-2">
              Our Dedicated Veterinary Team
            </h2>
          </ScrollReveal>

          <ScrollReveal animation="fade-up" delay={300} reverseOnScrollUp={false}>
            <p className="body-lead mt-3 text-[#1a3d1a]/85 mx-auto">
              Experienced veterinary surgeons, clinicians, and animal welfare caregivers uniting rigorous scientific training with heartfelt dedication.
            </p>
          </ScrollReveal>
        </div>

        {/* Professional Team Cards Grid with ScrollReveal & Lift Physics */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 lg:gap-6 items-stretch">
          {teamList.map((member, index) => (
            <ScrollReveal
              key={member.id}
              animation="fade-up"
              delay={200 + index * 100}
              reverseOnScrollUp={false}
              className="h-full"
            >
              <div className="svcc-card bg-[#EFFDF0] rounded-3xl p-6 border border-[#1a3d1a]/15 shadow-xs hover:border-[#6F8F72] flex flex-col justify-between h-full relative overflow-hidden">
                <div className="card-accent-line" />
                <div>
                  {/* Avatar / Portrait Frame with hover pulse */}
                  <div className="w-20 h-20 rounded-full bg-white border-2 border-[#1a3d1a]/20 mx-auto mb-4 flex items-center justify-center text-[#1a3d1a] shadow-inner overflow-hidden group-hover:scale-105 transition-transform duration-300">
                    <div className="w-16 h-16 rounded-full bg-[#1a3d1a] text-[#EFFDF0] flex items-center justify-center shadow-xs">
                      <Stethoscope className="w-8 h-8 text-[#EFFDF0]" />
                    </div>
                  </div>

                  <h3 className="text-lg sm:text-xl font-serif font-bold text-[#1a3d1a] text-center mb-1">
                    {member.name}
                  </h3>

                  <div className="text-sm font-semibold text-[#E86A10] text-center mb-3">
                    {member.role}
                  </div>

                  <div className="bg-white/90 p-3.5 rounded-2xl border border-[#1a3d1a]/10 space-y-1.5 mb-4 text-xs shadow-2xs">
                    <div className="flex items-center gap-1.5 text-[#1a3d1a] font-medium">
                      <GraduationCap className="w-4 h-4 text-[#6F8F72] shrink-0" />
                      <span>{member.qualification}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-gray-700 font-medium">
                      <Award className="w-4 h-4 text-[#E86A10] shrink-0" />
                      <span>{member.experience}</span>
                    </div>
                  </div>

                  <p className="card-body-text text-[#1a3d1a]/85 mb-4">
                    {member.bio}
                  </p>
                </div>

                <div className="pt-3 border-t border-gray-200 text-xs font-medium text-[#1a3d1a]/90 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#6F8F72] shrink-0" />
                  <span className="truncate">{member.specialization}</span>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </SectionContainer>
    </section>
  );
};
