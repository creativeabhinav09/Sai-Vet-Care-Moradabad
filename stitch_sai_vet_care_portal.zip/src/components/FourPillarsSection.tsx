import React from 'react';
import { Heart, Stethoscope, ShieldCheck, Ambulance, CheckCircle2 } from 'lucide-react';
import { ScrollReveal } from './ScrollReveal';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from './SectionContainer';
import { useCms } from '../cms/CmsContext';

export const FourPillarsSection: React.FC = () => {
  const { getSection } = useCms();
  const pillarsConfig = getSection('about', 'four-pillars');

  if (pillarsConfig?.enabled === false) {
    return null;
  }

  const { ref, isIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  const PILLARS_DATA = [
    {
      id: 'pillar-1',
      number: 'Pillar 01',
      title: 'Zero Commercialization',
      subtitle: '100% Free Humanitarian Relief',
      description:
        'No consultation fee, dressing charge, or pharmaceutical tariff is ever levied on stray animals or underprivileged rural caretakers.',
      icon: Heart,
      iconBg: 'bg-[#C98268]/15 text-[#C98268]',
      badgeColor: 'bg-[#F7F3EA] text-[#C98268] border-[#C98268]/20',
      features: [
        'Free emergency triage & surgery',
        'Free antibiotics & pain analgesia',
        'No financial eligibility testing',
      ],
    },
    {
      id: 'pillar-2',
      number: 'Pillar 02',
      title: 'Modern Clinical Rigor',
      subtitle: 'Evidence-Based Science',
      description:
        'Charitable veterinary care paired with sterile operating theaters, diagnostic radiography, hematology testing, and strict aseptic protocols.',
      icon: Stethoscope,
      iconBg: 'bg-[#6F8F72]/15 text-[#6F8F72]',
      badgeColor: 'bg-[#F7F3EA] text-[#6F8F72] border-[#6F8F72]/20',
      features: [
        'Sterile orthopedic pin fixation',
        'Balanced inhalation anesthesia',
        'In-house blood cytology testing',
      ],
    },
    {
      id: 'pillar-3',
      number: 'Pillar 03',
      title: 'Gaushala Sanctuary Welfare',
      subtitle: 'Herd Health & Geriatric Care',
      description:
        'Dedicated prophylactic veterinary camps, deworming drives, and specialized senior bovine hospice care across 48 regional cattle shelters.',
      icon: ShieldCheck,
      iconBg: 'bg-[#294936]/10 text-[#294936]',
      badgeColor: 'bg-[#F7F3EA] text-[#294936] border-[#294936]/20',
      features: [
        '48 adopted regional gaushalas',
        'Mass FMD & HS vaccination',
        'Mineral supplementation relief',
      ],
    },
    {
      id: 'pillar-4',
      number: 'Pillar 04',
      title: '24/7 Mobile Dispatch',
      subtitle: 'Rapid Highway Rescue',
      description:
        'Rapid on-call mobile veterinary ambulances equipped with hydraulic stretcher lifts, onboard oxygen, and roadside fracture splints.',
      icon: Ambulance,
      iconBg: 'bg-[#C98268]/15 text-[#C98268]',
      badgeColor: 'bg-[#F7F3EA] text-[#C98268] border-[#C98268]/20',
      features: [
        '3 dedicated mobile rescue vans',
        'Average 15–30 min arrival radius',
        'Onboard shock resuscitation',
      ],
    },
  ];

  return (
    <section
      id="four-pillars"
      ref={ref}
      style={{
        paddingTop: 'clamp(28px, 3.5vw, 44px)',
        paddingBottom: 'clamp(28px, 3.5vw, 44px)',
      }}
      className="w-full bg-[#F7F3EA] border-y border-[#294936]/10 relative"
    >
      <SectionContainer>
        {/* Centered Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-6 sm:mb-8">
          <ScrollReveal animation="fade-in" delay={100} reverseOnScrollUp={false}>
            <span className="label-eyebrow text-[#6F8F72]">
              {pillarsConfig?.eyebrow || 'Ethical & Clinical Framework'}
            </span>
          </ScrollReveal>

          <ScrollReveal animation="text-reveal" delay={180} reverseOnScrollUp={false}>
            <h2 className="section-h2 text-[#294936] mt-2">
              {pillarsConfig?.title || 'The Four Pillars of Institutional Seva'}
            </h2>
          </ScrollReveal>

          <ScrollReveal animation="fade-up" delay={260} reverseOnScrollUp={false}>
            <p className="body-lead mt-3 text-[#26332B]/80 mx-auto">
              {pillarsConfig?.description ||
                'Four foundational commitments that ensure our veterinary interventions remain uncompromising in medical excellence, completely free of commercial charge, and guided by reverent compassion.'}
            </p>
          </ScrollReveal>
        </div>

        {/* 
          Clean 2×2 Feature Cards Grid:
          [Card 1]    [Card 2]
          [Card 3]    [Card 4]
          - Exactly 2 cards on the left, 2 cards on the right
          - Equal width, equal spacing, and perfectly aligned rows & columns
        */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 lg:gap-6 items-stretch max-w-5xl mx-auto">
          {PILLARS_DATA.map((pillar, idx) => {
            const IconComponent = pillar.icon;
            return (
              <ScrollReveal
                key={pillar.id}
                animation="fade-up"
                delay={100 + idx * 80}
                reverseOnScrollUp={false}
                className="w-full h-full"
              >
                <div className="bg-white rounded-3xl p-6 sm:p-7 lg:p-8 border border-[#294936]/15 shadow-xs hover:border-[#6F8F72] hover:shadow-md transition-all duration-300 flex flex-col justify-between h-full group">
                  <div>
                    {/* Card Top Row: Icon + Pillar Pill */}
                    <div className="flex items-center justify-between mb-4">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform ${pillar.iconBg}`}>
                        <IconComponent className="w-6 h-6" />
                      </div>
                      <span className={`text-xs font-semibold uppercase tracking-wider px-3 py-1 rounded-full border ${pillar.badgeColor}`}>
                        {pillar.number}
                      </span>
                    </div>

                    <h3 className="sub-h3 text-[#294936] mb-1">
                      {pillar.title}
                    </h3>
                    <div className="text-xs font-semibold text-[#6F8F72] mb-3">
                      {pillar.subtitle}
                    </div>

                    <p className="card-body-text text-[#26332B]/80 mb-5 leading-relaxed">
                      {pillar.description}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-[#294936]/10 space-y-2 text-sm text-[#294936]/90 font-medium">
                    {pillar.features.map((feature, fIdx) => (
                      <div key={fIdx} className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#6F8F72] shrink-0" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </ScrollReveal>
            );
          })}
        </div>
      </SectionContainer>
    </section>
  );
};
