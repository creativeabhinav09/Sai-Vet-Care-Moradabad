import React from 'react';

interface ArtworkProps {
  className?: string;
  variant?: 'hero' | 'satpathy' | 'medical' | 'surgical' | 'gaushala' | 'rehab' | 'emergency';
}

export const SvccArtwork: React.FC<ArtworkProps> = ({ className = 'w-full h-full', variant = 'hero' }) => {
  if (variant === 'satpathy') {
    return (
      <div className={`relative overflow-hidden bg-[#EDE4D3] flex items-center justify-center ${className}`}>
        <svg viewBox="0 0 400 500" preserveAspectRatio="xMidYMid meet" className="w-full h-full object-contain" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="satpathyBg" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#F7F3EA" />
              <stop offset="50%" stopColor="#EDE4D3" />
              <stop offset="100%" stopColor="#DFCDB8" />
            </linearGradient>
            <radialGradient id="haloGlow" cx="50%" cy="38%" r="45%">
              <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.9" />
              <stop offset="60%" stopColor="#6F8F72" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#EDE4D3" stopOpacity="0" />
            </radialGradient>
          </defs>
          <rect width="400" height="500" fill="url(#satpathyBg)" />
          
          {/* Animated Spiritual Breathing Halo */}
          <circle cx="200" cy="180" r="140" fill="url(#haloGlow)" className="animate-halo-breathe origin-center" />
          
          {/* Subtle architectural arched frame */}
          <path d="M 50 480 L 50 180 Q 50 60 200 60 Q 350 60 350 180 L 350 480" fill="none" stroke="#6F8F72" strokeWidth="1.5" strokeOpacity="0.3" strokeDasharray="4 4" />
          
          {/* Dignified Patron Figure Silhouette & Contours */}
          <path d="M 160 170 C 160 125, 240 125, 240 170 C 240 210, 160 210, 160 170 Z" fill="#294936" />
          <ellipse cx="200" cy="175" rx="34" ry="42" fill="#F7F3EA" />
          
          <path d="M 180 165 Q 190 162 195 166" stroke="#294936" strokeWidth="2" fill="none" strokeLinecap="round" />
          <path d="M 205 166 Q 210 162 220 165" stroke="#294936" strokeWidth="2" fill="none" strokeLinecap="round" />
          
          <path d="M 182 173 Q 190 178 196 173" stroke="#26332B" strokeWidth="2.2" fill="none" strokeLinecap="round" />
          <path d="M 204 173 Q 210 178 218 173" stroke="#26332B" strokeWidth="2.2" fill="none" strokeLinecap="round" />
          
          <path d="M 200 172 L 198 185 L 204 186" stroke="#294936" strokeWidth="1.6" fill="none" strokeLinecap="round" />
          <path d="M 188 196 Q 200 203 212 196" stroke="#C98268" strokeWidth="2" fill="none" strokeLinecap="round" />
          <path d="M 180 188 Q 200 198 220 188 Q 215 224 200 228 Q 185 224 180 188 Z" fill="#FFFFFF" fillOpacity="0.95" />
          
          {/* Robe with Folds */}
          <path d="M 150 225 C 130 260, 110 330, 95 480 L 305 480 C 290 330, 270 260, 250 225 C 235 235, 215 240, 200 240 C 185 240, 165 235, 150 225 Z" fill="#FFFFFF" />
          <path d="M 120 280 C 105 340, 130 460, 140 480 L 175 480 C 160 440, 140 330, 155 250 Z" fill="#6F8F72" fillOpacity="0.25" />
          <path d="M 245 250 C 260 330, 240 440, 225 480 L 260 480 C 270 460, 295 340, 280 280 Z" fill="#C98268" fillOpacity="0.2" />

          <g transform="translate(200, 440)" opacity="0.4">
            <circle cx="0" cy="0" r="16" fill="none" stroke="#294936" strokeWidth="1" />
            <path d="M -8 0 L 8 0 M 0 -8 L 0 8" stroke="#294936" strokeWidth="1" />
          </g>

          <text x="200" y="470" textAnchor="middle" fill="#26332B" fontSize="11" fontFamily="var(--font-sans)" letterSpacing="2" opacity="0.75">
            REVERED INSPIRATION & GUIDING LIGHT
          </text>
        </svg>
      </div>
    );
  }

  if (variant === 'medical') {
    return (
      <div className={`relative overflow-hidden bg-[#F7F3EA] flex items-center justify-center ${className}`}>
        <svg viewBox="0 0 600 450" preserveAspectRatio="xMidYMid meet" className="w-full h-full object-contain" xmlns="http://www.w3.org/2000/svg">
          <rect width="600" height="450" fill="#F7F3EA" />
          <rect x="30" y="30" width="540" height="390" rx="16" fill="#FFFFFF" stroke="#EDE4D3" strokeWidth="2" />
          
          {/* Diagnostic Monitor with Animated EKG Wave */}
          <rect x="60" y="60" width="220" height="130" rx="8" fill="#1a3d1a" />
          
          {/* EKG Grid lines */}
          <line x1="60" y1="125" x2="280" y2="125" stroke="#2a5a2a" strokeWidth="1" strokeDasharray="2 4" />
          
          {/* Live Continuous Animated EKG Line */}
          <path
            d="M 60 125 L 90 125 L 100 125 L 110 95 L 120 155 L 130 110 L 140 125 L 175 125 L 185 85 L 195 160 L 205 125 L 280 125"
            fill="none"
            stroke="#6F8F72"
            strokeWidth="2.8"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="animate-ekg-flow"
          />
          <text x="75" y="85" fill="#EDE4D3" fontSize="11" fontFamily="sans-serif" letterSpacing="1">VITAL METRICS · ACTIVE</text>
          <text x="75" y="165" fill="#6F8F72" fontSize="18" fontWeight="bold" fontFamily="sans-serif">98.4°F · 74 BPM</text>

          {/* Stethoscope */}
          <circle cx="430" cy="140" r="55" fill="#EDE4D3" fillOpacity="0.4" />
          <path d="M 390 100 C 370 140, 390 220, 440 220 C 490 220, 510 150, 490 110" fill="none" stroke="#1a3d1a" strokeWidth="5" strokeLinecap="round" />
          <circle cx="440" cy="220" r="16" fill="#6F8F72" stroke="#1a3d1a" strokeWidth="3" />
          <circle cx="440" cy="220" r="6" fill="#FFFFFF" />

          {/* Microscope */}
          <g transform="translate(100, 230)">
            <rect x="20" y="140" width="120" height="15" rx="4" fill="#1a3d1a" />
            <path d="M 60 140 L 60 40 Q 60 20 85 20 L 100 20" fill="none" stroke="#1a3d1a" strokeWidth="12" strokeLinecap="round" />
            <rect x="85" y="10" width="30" height="60" rx="4" transform="rotate(30, 100, 40)" fill="#6F8F72" />
            <ellipse cx="65" cy="100" rx="35" ry="8" fill="#E86A10" fillOpacity="0.3" />
          </g>

          {/* IV Bottle with dripping indication */}
          <g transform="translate(360, 240)">
            <rect x="60" y="30" width="50" height="110" rx="8" fill="#EDE4D3" stroke="#1a3d1a" strokeWidth="2.5" />
            <rect x="75" y="10" width="20" height="20" fill="#1a3d1a" rx="2" />
            <rect x="66" y="65" width="38" height="40" fill="#6F8F72" rx="2" />
            <path d="M 85 75 L 85 95 M 75 85 L 95 85" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" />
            <path d="M 85 140 C 85 180, 50 170, 30 185" fill="none" stroke="#6F8F72" strokeWidth="2" strokeDasharray="4 3" />
          </g>

          <text x="300" y="405" textAnchor="middle" fill="#1a3d1a" fontSize="13" fontWeight="600" fontFamily="sans-serif" letterSpacing="1">
            CLINICAL MEDICINE · PATHOLOGY & SYSTEMIC TRIAGE
          </text>
        </svg>
      </div>
    );
  }

  if (variant === 'surgical') {
    return (
      <div className={`relative overflow-hidden bg-[#F7F3EA] flex items-center justify-center ${className}`}>
        <svg viewBox="0 0 600 450" preserveAspectRatio="xMidYMid meet" className="w-full h-full object-contain" xmlns="http://www.w3.org/2000/svg">
          <rect width="600" height="450" fill="#F7F3EA" />
          <rect x="30" y="30" width="540" height="390" rx="16" fill="#FFFFFF" stroke="#EDE4D3" strokeWidth="2" />
          
          {/* Sterile Surgical Operating Lamp */}
          <g transform="translate(300, 40)">
            <line x1="0" y1="0" x2="0" y2="40" stroke="#1a3d1a" strokeWidth="4" />
            <ellipse cx="0" cy="50" rx="60" ry="16" fill="#1a3d1a" />
            <ellipse cx="0" cy="52" rx="48" ry="12" fill="#EDE4D3" />
            <circle cx="-20" cy="52" r="6" fill="#FFFFFF" />
            <circle cx="0" cy="52" r="6" fill="#FFFFFF" />
            <circle cx="20" cy="52" r="6" fill="#FFFFFF" />
            {/* Animated surgical light beam */}
            <polygon points="-60,55 60,55 130,240 -130,240" fill="#6F8F72" fillOpacity="0.12" className="animate-pulse" />
          </g>

          {/* Operating Theater Table */}
          <rect x="150" y="240" width="300" height="24" rx="4" fill="#1a3d1a" />
          <rect x="285" y="264" width="30" height="100" fill="#6F8F72" />
          <rect x="230" y="360" width="140" height="15" rx="4" fill="#1a3d1a" />

          {/* Surgical Tray */}
          <rect x="60" y="220" width="70" height="90" rx="6" fill="#EDE4D3" stroke="#1a3d1a" strokeWidth="1.5" />
          <line x1="75" y1="235" x2="75" y2="295" stroke="#1a3d1a" strokeWidth="3" strokeLinecap="round" />
          <line x1="95" y1="235" x2="95" y2="295" stroke="#E86A10" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="115" y1="235" x2="115" y2="295" stroke="#6F8F72" strokeWidth="2.5" strokeLinecap="round" />

          {/* Monitoring Lead on Right */}
          <rect x="460" y="160" width="80" height="120" rx="8" fill="#1a3d1a" />
          <line x1="475" y1="200" x2="525" y2="200" stroke="#6F8F72" strokeWidth="2" />
          <line x1="475" y1="220" x2="510" y2="220" stroke="#E86A10" strokeWidth="2" />
          <circle cx="485" cy="245" r="5" fill="#6F8F72" />
          <circle cx="505" cy="245" r="5" fill="#EDE4D3" />

          <text x="300" y="405" textAnchor="middle" fill="#1a3d1a" fontSize="13" fontWeight="600" fontFamily="sans-serif" letterSpacing="1">
            ASEPTIC OPERATING SUITE · TRAUMA & ORTHOPAEDIC FIXATION
          </text>
        </svg>
      </div>
    );
  }

  if (variant === 'gaushala') {
    return (
      <div className={`relative overflow-hidden bg-[#EDE4D3] flex items-center justify-center ${className}`}>
        <svg viewBox="0 0 600 450" preserveAspectRatio="xMidYMid meet" className="w-full h-full object-contain" xmlns="http://www.w3.org/2000/svg">
          <rect width="600" height="450" fill="#EDE4D3" />
          <path d="M 0 320 Q 150 280 300 310 Q 450 340 600 290 L 600 450 L 0 450 Z" fill="#6F8F72" fillOpacity="0.25" />
          <path d="M 0 350 Q 200 320 400 350 Q 520 370 600 340 L 600 450 L 0 450 Z" fill="#6F8F72" fillOpacity="0.4" />

          <polygon points="50,210 320,130 550,210" fill="#1a3d1a" />
          <line x1="80" y1="210" x2="80" y2="330" stroke="#1a3d1a" strokeWidth="6" strokeLinecap="round" />
          <line x1="220" y1="180" x2="220" y2="330" stroke="#1a3d1a" strokeWidth="6" strokeLinecap="round" />
          <line x1="380" y1="180" x2="380" y2="330" stroke="#1a3d1a" strokeWidth="6" strokeLinecap="round" />
          <line x1="520" y1="210" x2="520" y2="330" stroke="#1a3d1a" strokeWidth="6" strokeLinecap="round" />

          {/* Gentle Cow Silhouette */}
          <g transform="translate(180, 240)">
            <ellipse cx="90" cy="55" rx="60" ry="38" fill="#F7F3EA" stroke="#1a3d1a" strokeWidth="2.5" />
            <path d="M 140 40 Q 165 25 175 40 Q 185 55 170 65 Q 145 65 135 60 Z" fill="#F7F3EA" stroke="#1a3d1a" strokeWidth="2.5" />
            <path d="M 160 30 Q 170 12 178 20" fill="none" stroke="#1a3d1a" strokeWidth="3" strokeLinecap="round" />
            <path d="M 125 22 Q 135 10 145 22" fill="#F7F3EA" stroke="#1a3d1a" strokeWidth="2.5" />
            <line x1="55" y1="88" x2="52" y2="135" stroke="#1a3d1a" strokeWidth="4" strokeLinecap="round" />
            <line x1="75" y1="92" x2="73" y2="135" stroke="#1a3d1a" strokeWidth="4" strokeLinecap="round" />
            <line x1="120" y1="92" x2="122" y2="135" stroke="#1a3d1a" strokeWidth="4" strokeLinecap="round" />
            <line x1="138" y1="88" x2="140" y2="135" stroke="#1a3d1a" strokeWidth="4" strokeLinecap="round" />
            <circle cx="165" cy="45" r="2.5" fill="#1a3d1a" />
          </g>

          {/* Caring Veterinarian */}
          <g transform="translate(380, 230)">
            <circle cx="25" cy="25" r="12" fill="#1a3d1a" />
            <path d="M 10 40 L 40 40 L 45 95 L 5 95 Z" fill="#6F8F72" />
            <path d="M 18 38 C 15 50, 20 62, 30 62 C 40 62, 45 50, 38 38" fill="none" stroke="#FFFFFF" strokeWidth="1.8" />
            <line x1="16" y1="95" x2="14" y2="145" stroke="#1a3d1a" strokeWidth="3.5" strokeLinecap="round" />
            <line x1="34" y1="95" x2="36" y2="145" stroke="#1a3d1a" strokeWidth="3.5" strokeLinecap="round" />
            <path d="M 12 50 L -25 65" stroke="#6F8F72" strokeWidth="4" strokeLinecap="round" />
          </g>

          <circle cx="100" cy="80" r="32" fill="#E86A10" fillOpacity="0.25" />
          <path d="M 520 40 Q 560 70 510 110 Q 470 60 520 40 Z" fill="#1a3d1a" fillOpacity="0.2" />

          <text x="300" y="420" textAnchor="middle" fill="#1a3d1a" fontSize="13" fontWeight="600" fontFamily="sans-serif" letterSpacing="1">
            GAUSHALA SANCTUARY OUTREACH & HERD WELFARE
          </text>
        </svg>
      </div>
    );
  }

  // Default: Hero Visual Artwork
  return (
    <div className={`relative overflow-hidden bg-[#EFFDF0] flex items-center justify-center ${className}`}>
      <svg viewBox="0 0 800 500" preserveAspectRatio="xMidYMid meet" className="w-full h-full object-contain" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="heroGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#EFFDF0" />
            <stop offset="50%" stopColor="#EDE4D3" />
            <stop offset="100%" stopColor="#DFCDB8" />
          </linearGradient>
        </defs>
        <rect width="800" height="500" fill="url(#heroGradient)" />

        <ellipse cx="400" cy="180" rx="300" ry="170" fill="#FFFFFF" fillOpacity="0.6" />
        <circle cx="680" cy="110" r="85" fill="#E86A10" fillOpacity="0.18" />

        <rect x="70" y="60" width="16" height="380" fill="#1a3d1a" fillOpacity="0.12" rx="4" />
        <rect x="710" y="60" width="16" height="380" fill="#1a3d1a" fillOpacity="0.12" rx="4" />

        <g stroke="#6F8F72" strokeWidth="2.5" fill="none" opacity="0.45">
          <path d="M 40 40 Q 140 70 200 40 Q 260 10 320 60" />
          <path d="M 80 45 C 85 20, 115 25, 110 50" fill="#6F8F72" fillOpacity="0.3" />
          <path d="M 140 55 C 145 30, 175 35, 170 60" fill="#6F8F72" fillOpacity="0.3" />
          <path d="M 210 40 C 220 15, 250 20, 245 48" fill="#6F8F72" fillOpacity="0.3" />
        </g>

        {/* Rescued Cow / Calf */}
        <g transform="translate(180, 210)">
          <ellipse cx="140" cy="90" rx="90" ry="55" fill="#1a3d1a" />
          <path d="M 210 65 Q 245 40 260 65 Q 275 90 250 105 Q 215 105 205 95 Z" fill="#1a3d1a" />
          <path d="M 185 40 Q 200 20 215 40 Z" fill="#1a3d1a" />
          <line x1="95" y1="140" x2="92" y2="220" stroke="#1a3d1a" strokeWidth="7" strokeLinecap="round" />
          <line x1="125" y1="142" x2="122" y2="220" stroke="#1a3d1a" strokeWidth="7" strokeLinecap="round" />
          <line x1="185" y1="142" x2="188" y2="220" stroke="#1a3d1a" strokeWidth="7" strokeLinecap="round" />
          <line x1="215" y1="140" x2="218" y2="220" stroke="#1a3d1a" strokeWidth="7" strokeLinecap="round" />
          <rect x="180" y="165" width="16" height="24" rx="3" fill="#FFFFFF" stroke="#E86A10" strokeWidth="1.5" />
          <line x1="180" y1="177" x2="196" y2="177" stroke="#E86A10" strokeWidth="1.5" />
          <circle cx="245" cy="72" r="3.5" fill="#EFFDF0" />
        </g>

        {/* Rescued Dog */}
        <g transform="translate(480, 260)">
          <ellipse cx="50" cy="70" rx="32" ry="40" fill="#6F8F72" />
          <circle cx="50" cy="22" r="18" fill="#6F8F72" />
          <path d="M 36 18 Q 30 35 34 42" stroke="#1a3d1a" strokeWidth="3" fill="#6F8F72" />
          <path d="M 64 18 Q 70 35 66 42" stroke="#1a3d1a" strokeWidth="3" fill="#6F8F72" />
          <line x1="38" y1="100" x2="36" y2="160" stroke="#6F8F72" strokeWidth="6" strokeLinecap="round" />
          <line x1="60" y1="100" x2="62" y2="160" stroke="#6F8F72" strokeWidth="6" strokeLinecap="round" />
          <circle cx="50" cy="42" r="4.5" fill="#E86A10" />
          <path d="M 80 85 Q 105 75 108 55" fill="none" stroke="#6F8F72" strokeWidth="5" strokeLinecap="round" />
        </g>

        {/* Caring Veterinarian */}
        <g transform="translate(380, 185)">
          <circle cx="45" cy="40" r="18" fill="#1a3d1a" />
          <path d="M 38 55 C 32 75, 45 92, 58 92 C 70 92, 78 75, 72 55" fill="none" stroke="#FFFFFF" strokeWidth="2.5" />
          <path d="M 25 60 L 68 60 L 80 145 L 15 145 Z" fill="#1a3d1a" />
          <path d="M 30 78 L -15 95" stroke="#1a3d1a" strokeWidth="6" strokeLinecap="round" />
          <circle cx="-15" cy="95" r="5" fill="#E86A10" />
        </g>

        <ellipse cx="400" cy="440" rx="340" ry="22" fill="#1a3d1a" fillOpacity="0.12" />

        <g transform="translate(400, 475)">
          <text textAnchor="middle" fill="#1a3d1a" fontSize="12" fontFamily="var(--font-sans)" letterSpacing="3" fontWeight="500" opacity="0.8">
            COMPASSION · INTEGRITY · CONTINUOUS VETERINARY SEVA
          </text>
        </g>
      </svg>
    </div>
  );
};
