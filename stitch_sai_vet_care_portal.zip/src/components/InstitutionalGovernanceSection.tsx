import React from 'react';
import { Building2, FileText, ShieldCheck, Award, CheckCircle2 } from 'lucide-react';
import { ScrollReveal } from './ScrollReveal';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from './SectionContainer';

export const InstitutionalGovernanceSection: React.FC = () => {
  const { ref, isIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  const GOVERNANCE_ITEMS = [
    {
      id: 'gov-1',
      title: 'Registered Charity Trust',
      description:
        'Formally registered and recognized under Maharashtra State Animal Welfare enactments with regular public oversight.',
      badgeText: 'Maharashtra Public Trust Reg.',
      icon: Building2,
      iconBg: 'bg-[#294936] text-[#EDE4D3]',
      iconColor: 'text-[#C98268]',
    },
    {
      id: 'gov-2',
      title: 'Chartered Annual Audits',
      description:
        'Accounts are examined yearly by independent external chartered accountants. 100% of donations go directly to medicine and fodder.',
      badgeText: 'Zero Administrative Diversion',
      icon: FileText,
      iconBg: 'bg-[#6F8F72]/20 text-[#294936]',
      iconColor: 'text-[#294936]',
    },
    {
      id: 'gov-3',
      title: 'CPCSEA Animal Ethics',
      description:
        'Compliant with Committee for the Purpose of Control and Supervision of Experiments on Animals guidelines and humane surgery standards.',
      badgeText: 'Humane Surgical Protocols',
      icon: ShieldCheck,
      iconBg: 'bg-[#294936]/10 text-[#294936]',
      iconColor: 'text-[#6F8F72]',
    },
    {
      id: 'gov-4',
      title: '80G & 12A Certified',
      description:
        'All charitable offerings and donor contributions enjoy tax exemption under Section 80G with immediate electronic certification.',
      badgeText: 'Tax Deductible Contributions',
      icon: Award,
      iconBg: 'bg-[#C98268]/20 text-[#C98268]',
      iconColor: 'text-[#C98268]',
    },
  ];

  return (
    <section
      id="institutional-governance"
      ref={ref}
      style={{
        paddingTop: 'clamp(28px, 3.5vw, 44px)',
        paddingBottom: 'clamp(28px, 3.5vw, 44px)',
      }}
      className="w-full bg-white relative"
    >
      <SectionContainer>
        {/* Centered Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-6 sm:mb-8">
          <ScrollReveal animation="fade-in" delay={100} reverseOnScrollUp={false}>
            <span className="label-eyebrow text-[#6F8F72]">
              Transparency & Compliance
            </span>
          </ScrollReveal>

          <ScrollReveal animation="text-reveal" delay={180} reverseOnScrollUp={false}>
            <h2 className="section-h2 text-[#294936] mt-2">
              Institutional Governance & Trust
            </h2>
          </ScrollReveal>

          <ScrollReveal animation="fade-up" delay={260} reverseOnScrollUp={false}>
            <p className="body-lead mt-3 text-[#26332B]/80 mx-auto">
              Sai Vet Care Clinic is governed by strict statutory animal welfare regulations, independently audited fiscal accounting, and unwavering transparency.
            </p>
          </ScrollReveal>
        </div>

        {/* 
          Clean 2×2 Feature Cards Grid:
          [Card 1]    [Card 2]
          [Card 3]    [Card 4]
          - Exactly 2 cards on the left, 2 cards on the right
          - Equal width, equal spacing, and perfectly aligned rows & columns
        */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 lg:gap-6 items-stretch max-w-5xl mx-auto">
          {GOVERNANCE_ITEMS.map((item, idx) => {
            const IconComponent = item.icon;
            return (
              <ScrollReveal
                key={item.id}
                animation="fade-up"
                delay={100 + idx * 80}
                reverseOnScrollUp={false}
                className="w-full h-full"
              >
                <div className="p-6 sm:p-7 lg:p-8 rounded-3xl bg-[#F7F3EA] border border-[#294936]/15 hover:border-[#6F8F72] hover:shadow-xs transition-all duration-300 flex flex-col justify-between h-full group">
                  <div>
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-105 transition-transform ${item.iconBg}`}>
                      <IconComponent className={`w-6 h-6 ${item.iconColor}`} />
                    </div>

                    <h3 className="card-h4 text-[#294936] mb-2 font-sans font-semibold">
                      {item.title}
                    </h3>

                    <p className="card-body-text text-[#26332B]/80 mb-5 leading-relaxed text-sm">
                      {item.description}
                    </p>
                  </div>

                  <div className="pt-3.5 border-t border-[#294936]/10 flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#294936]">
                    <CheckCircle2 className="w-4 h-4 text-[#6F8F72] shrink-0" />
                    <span>{item.badgeText}</span>
                  </div>
                </div>
              </ScrollReveal>
            );
          })}
        </div>
      </SectionContainer>
    </section>
  );
};
