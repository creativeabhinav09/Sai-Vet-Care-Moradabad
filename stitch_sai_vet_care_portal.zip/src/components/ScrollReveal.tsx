import React from 'react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

interface ScrollRevealProps {
  children: React.ReactNode;
  animation?: 'fade-up' | 'fade-in' | 'slide-up' | 'slide-in-left' | 'slide-in-right' | 'scale-in' | 'text-reveal' | 'photo-reveal';
  delay?: number;
  className?: string;
  threshold?: number;
  reverseOnScrollUp?: boolean;
}

export const ScrollReveal: React.FC<ScrollRevealProps> = ({
  children,
  animation = 'fade-up',
  delay = 0,
  className = '',
  threshold = 0.06,
  reverseOnScrollUp = false,
}) => {
  const { ref, isIntersecting, hasEntered } = useIntersectionObserver<HTMLDivElement>({
    threshold,
    triggerOnce: !reverseOnScrollUp,
  });

  const getAnimationClass = () => {
    switch (animation) {
      case 'fade-in':
        return 'animate-fade-in';
      case 'slide-up':
        return 'animate-slide-up';
      case 'slide-in-left':
        return 'animate-slide-in-left';
      case 'slide-in-right':
        return 'animate-slide-in-right';
      case 'scale-in':
        return 'animate-scale-in';
      case 'text-reveal':
        return 'animate-text-reveal';
      case 'photo-reveal':
        return 'animate-photo-reveal';
      case 'fade-up':
      default:
        return 'animate-fade-up';
    }
  };

  const isVisible = reverseOnScrollUp ? isIntersecting : (isIntersecting || hasEntered);

  return (
    <div
      ref={ref}
      className={`will-change-[opacity,transform] ${
        isVisible
          ? `${getAnimationClass()} opacity-100`
          : 'opacity-0 pointer-events-auto'
      } ${className}`}
      style={{
        animationDelay: isVisible && delay ? `${delay}ms` : '0ms',
        animationFillMode: 'both',
      }}
    >
      {children}
    </div>
  );
};

