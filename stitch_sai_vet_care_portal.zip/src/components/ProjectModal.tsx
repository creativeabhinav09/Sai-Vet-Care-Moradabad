import React, { useEffect } from 'react';
import { X, CheckCircle2, ShieldCheck, Phone, ArrowRight, Activity, MapPin, Calendar } from 'lucide-react';
import { SvccArtwork } from './SvccArtwork';

export interface ProjectData {
  id: string;
  number: string;
  category: string;
  title: string;
  subtitle: string;
  description: string;
  stats: { label: string; value: string }[];
  protocols: string[];
  equipment: string[];
  impactBadge: string;
  artworkVariant: 'hero' | 'satpathy' | 'medical' | 'surgical' | 'gaushala' | 'rehab' | 'emergency';
  location: string;
  leadSurgeonOrOfficer: string;
}

interface ProjectModalProps {
  project: ProjectData | null;
  onClose: () => void;
  onEmergencyClick: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({
  project,
  onClose,
  onEmergencyClick,
}) => {
  useEffect(() => {
    if (!project) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [project, onClose]);

  if (!project) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-fade-in overflow-y-auto"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-4xl bg-[#142618] text-[#EFFDF0] rounded-3xl sm:rounded-[36px] border border-[#6F8F72]/30 shadow-2xl p-6 sm:p-8 md:p-10 my-8 max-h-[90vh] overflow-y-auto"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-[#EFFDF0] flex items-center justify-center transition-colors cursor-pointer border border-white/10"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Header */}
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <span className="text-xs font-bold uppercase tracking-widest text-[#E86A10] bg-[#E86A10]/20 px-3 py-1 rounded-full border border-[#E86A10]/30">
            {project.category}
          </span>
          <span className="text-xs font-mono text-[#EDE4D3]/70">
            Project Ref #{project.number}
          </span>
          <span className="text-xs text-[#6F8F72] flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5" />
            {project.location}
          </span>
        </div>

        <h3 className="text-2xl sm:text-3xl md:text-4xl font-serif-display font-bold text-[#EFFDF0] mb-2 leading-tight">
          {project.title}
        </h3>
        <p className="text-sm sm:text-base text-[#EDE4D3]/85 leading-relaxed mb-6">
          {project.subtitle}
        </p>

        {/* Hero Artwork Frame */}
        <div className="aspect-21/9 w-full rounded-2xl overflow-hidden mb-8 border border-white/15 bg-[#1c3522] shadow-inner relative">
          <SvccArtwork variant={project.artworkVariant} className="w-full h-full object-contain" />
          <div className="absolute bottom-3 left-3 bg-[#142618]/90 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-white/15 text-xs font-semibold text-[#EDE4D3] flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#E86A10] animate-pulse" />
            <span>{project.impactBadge}</span>
          </div>
        </div>

        {/* Impact Numbers Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
          {project.stats.map((s, idx) => (
            <div key={idx} className="bg-white/5 p-4 rounded-2xl border border-white/10 text-center">
              <div className="text-xl sm:text-2xl font-serif-display font-bold text-[#E86A10]">
                {s.value}
              </div>
              <div className="text-[11px] uppercase tracking-wider text-[#EDE4D3]/70 mt-1">
                {s.label}
              </div>
            </div>
          ))}
        </div>

        {/* Narrative & Protocols */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div className="space-y-4 text-xs sm:text-sm text-[#EDE4D3]/90 leading-relaxed">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#6F8F72]">
              Mission Overview & Scope
            </h4>
            <p>{project.description}</p>
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-xs">
              <span className="font-bold text-[#EFFDF0] block mb-1">Supervising Veterinary Officer:</span>
              <span className="text-[#EDE4D3]/80">{project.leadSurgeonOrOfficer}</span>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#6F8F72]">
              Clinical Protocols & Equipment Standards
            </h4>
            <div className="space-y-2">
              {project.protocols.map((p, i) => (
                <div key={i} className="flex items-start gap-2.5 text-xs text-[#EDE4D3]/90 bg-white/5 p-2.5 rounded-xl border border-white/10">
                  <CheckCircle2 className="w-4 h-4 text-[#6F8F72] shrink-0 mt-0.5" />
                  <span>{p}</span>
                </div>
              ))}
            </div>

            <div className="pt-2 flex flex-wrap gap-2 text-[11px] text-[#EDE4D3]/70">
              <span className="font-semibold text-[#EFFDF0]">Key Infrastructure:</span>
              {project.equipment.map((eq, eIdx) => (
                <span key={eIdx} className="bg-white/10 px-2.5 py-0.5 rounded-md border border-white/10 text-[#EFFDF0]">
                  {eq}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-6 border-t border-white/10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-[#EDE4D3]/70">
            <ShieldCheck className="w-4 h-4 text-[#6F8F72]" />
            <span>100% Non-Profit Seva Initiative · Certified Animal Welfare Trust</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                onClose();
                onEmergencyClick();
              }}
              className="btn-micro px-5 py-2.5 rounded-full bg-[#E86A10] hover:bg-[#d45e0d] text-white text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-md"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Contact Dispatch</span>
            </button>
            <button
              onClick={onClose}
              className="btn-micro px-5 py-2.5 rounded-full bg-white/10 hover:bg-white/20 text-[#EFFDF0] text-xs font-semibold cursor-pointer border border-white/15"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
