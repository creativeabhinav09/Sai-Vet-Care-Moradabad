import React, { useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, MapPin, Calendar, HeartHandshake } from 'lucide-react';
import { GalleryItem } from '../types';
import { SvccArtwork } from './SvccArtwork';

interface LightboxModalProps {
  item: GalleryItem | null;
  items: GalleryItem[];
  onClose: () => void;
  onSelectNext: () => void;
  onSelectPrev: () => void;
}

export const LightboxModal: React.FC<LightboxModalProps> = ({
  item,
  items,
  onClose,
  onSelectNext,
  onSelectPrev,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') onSelectNext();
      if (e.key === 'ArrowLeft') onSelectPrev();
    };

    if (item) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [item, onClose, onSelectNext, onSelectPrev]);

  if (!item) return null;

  const currentIndex = items.findIndex((i) => i.id === item.id);

  const getArtworkVariant = (id: string): 'hero' | 'satpathy' | 'medical' | 'surgical' | 'gaushala' | 'rehab' | 'emergency' => {
    if (id === 'gal-2') return 'gaushala';
    if (id === 'gal-3') return 'surgical';
    if (id === 'gal-4' || id === 'gal-5') return 'hero';
    if (id === 'gal-6') return 'gaushala';
    return 'medical';
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={item.title}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 lg:p-8 animate-fade-in"
    >
      {/* Dimmed Backdrop with SVCC Deep Green & Cream Blur */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-[#26332B]/85 backdrop-blur-md transition-opacity duration-300 cursor-pointer"
      />

      {/* Lightbox Modal Content Box with 0.96 -> 1 scale */}
      <div className="relative z-10 max-w-4xl w-full bg-[#F7F3EA] rounded-2xl overflow-hidden shadow-2xl border border-[#294936]/20 animate-scale-in">
        
        {/* Top Header Bar */}
        <div className="p-4 sm:p-5 flex items-center justify-between border-b border-[#294936]/10 bg-white">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#6F8F72] px-2.5 py-0.5 rounded-md bg-[#6F8F72]/15">
              {item.category}
            </span>
            <span className="text-xs text-[#26332B]/60 font-medium">
              Photo {currentIndex + 1} of {items.length}
            </span>
          </div>

          {/* Close button with subtle fade in */}
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#26332B]/80 hover:text-[#294936] hover:bg-[#EDE4D3]/50 transition-colors cursor-pointer"
            aria-label="Close image lightbox"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Visual Content Display */}
        <div className="relative aspect-16/10 sm:aspect-16/9 w-full bg-[#EDE4D3] overflow-hidden">
          <SvccArtwork variant={getArtworkVariant(item.id)} className="w-full h-full" />

          {/* Previous / Next Navigation Arrows */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onSelectPrev();
            }}
            className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-[#294936]/80 text-[#F7F3EA] hover:bg-[#294936] flex items-center justify-center transition-transform hover:scale-105 cursor-pointer shadow-md"
            aria-label="Previous image"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onSelectNext();
            }}
            className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-[#294936]/80 text-[#F7F3EA] hover:bg-[#294936] flex items-center justify-center transition-transform hover:scale-105 cursor-pointer shadow-md"
            aria-label="Next image"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Caption & Metadata Footer */}
        <div className="p-5 sm:p-6 bg-white space-y-2">
          <h3 className="text-xl sm:text-2xl font-serif font-bold text-[#294936]">
            {item.title}
          </h3>

          <p className="text-sm text-[#26332B]/85 leading-relaxed">
            {item.caption}
          </p>

          <div className="pt-3 border-t border-[#EDE4D3] flex flex-wrap items-center justify-between gap-4 text-xs text-[#26332B]/70">
            <div className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#C98268]" />
              <span>{item.location}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#6F8F72]" />
              <span>{item.date}</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
