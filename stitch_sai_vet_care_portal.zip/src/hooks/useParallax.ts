import { useEffect, useRef, useState } from 'react';

interface UseParallaxOptions {
  speed?: number; // e.g. 0.08, negative or positive
  maxOffset?: number; // maximum pixel displacement
}

export function useParallax({ speed = 0.1, maxOffset = 60 }: UseParallaxOptions = {}) {
  const elementRef = useRef<HTMLDivElement | null>(null);
  const [offset, setOffset] = useState(0);

  useEffect(() => {
    // Check if user prefers reduced motion
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced) return;

    let ticking = false;

    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          const element = elementRef.current;
          if (element) {
            const rect = element.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            
            // Check if element is in or near viewport
            if (rect.top <= windowHeight + 100 && rect.bottom >= -100) {
              const elementCenter = rect.top + rect.height / 2;
              const viewportCenter = windowHeight / 2;
              const distanceFromCenter = elementCenter - viewportCenter;
              
              const calculatedOffset = Math.max(
                -maxOffset,
                Math.min(maxOffset, distanceFromCenter * speed)
              );
              setOffset(calculatedOffset);
            }
          }
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll(); // Initial position calculation

    return () => window.removeEventListener('scroll', handleScroll);
  }, [speed, maxOffset]);

  return {
    ref: elementRef,
    offset,
    style: {
      transform: `translate3d(0, ${offset}px, 0)`,
      willChange: 'transform',
      transition: 'transform 100ms cubic-bezier(0.16, 1, 0.3, 1)',
    },
  };
}
