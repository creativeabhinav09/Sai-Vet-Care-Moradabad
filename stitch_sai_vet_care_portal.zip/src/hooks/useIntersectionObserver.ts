import { useEffect, useRef, useState } from 'react';

export interface UseIntersectionObserverProps {
  threshold?: number | number[];
  rootMargin?: string;
  triggerOnce?: boolean;
}

export interface UseIntersectionObserverReturn<T extends HTMLElement = HTMLElement> {
  ref: React.RefObject<T | null>;
  isIntersecting: boolean;
  hasEntered: boolean;
  scrollDirection: 'down' | 'up';
}

/**
 * Custom React hook 'useIntersectionObserver' that tracks element visibility
 * and viewport intersection with support for reversible scroll-up and scroll-down effects.
 */
export function useIntersectionObserver<T extends HTMLElement = HTMLElement>({
  threshold = 0.05,
  rootMargin = '0px 0px -20px 0px',
  triggerOnce = true,
}: UseIntersectionObserverProps = {}): UseIntersectionObserverReturn<T> {
  const [isIntersecting, setIsIntersecting] = useState<boolean>(false);
  const [hasEntered, setHasEntered] = useState<boolean>(false);
  const elementRef = useRef<T | null>(null);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    // Graceful fallback for environments without IntersectionObserver
    if (!('IntersectionObserver' in window)) {
      setIsIntersecting(true);
      setHasEntered(true);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsIntersecting(true);
          setHasEntered(true);
          if (triggerOnce) {
            observer.unobserve(element);
          }
        } else if (!triggerOnce) {
          setIsIntersecting(false);
        }
      },
      { threshold, rootMargin }
    );

    observer.observe(element);

    return () => {
      observer.disconnect();
    };
  }, [threshold, rootMargin, triggerOnce]);

  return {
    ref: elementRef,
    isIntersecting,
    hasEntered,
    scrollDirection: 'down',
  };
}
