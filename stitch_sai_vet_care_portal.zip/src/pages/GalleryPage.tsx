import React, { useEffect } from 'react';
import { PageHeader } from '../components/PageHeader';
import { GallerySection } from '../components/GallerySection';
import { SectionContainer } from '../components/SectionContainer';

import { useCms } from '../cms/CmsContext';

export const GalleryPage: React.FC = () => {
  const { getPage } = useCms();
  const page = getPage('gallery');

  useEffect(() => {
    document.title = page?.seo?.metaTitle || 'Documentary Field Gallery | Sai Vet Care Clinic — SVCC';
  }, [page]);

  return (
    <div className="w-full flex flex-col animate-fade-in">
      <PageHeader
        breadcrumbCurrent="Gallery"
        eyebrow="Visual Documentary"
        title="SVCC Field Seva & Treatment Gallery"
        description="Authentic documentary photographic records capturing roadside trauma triage, sterile bone-pinning surgeries, rural gaushala health camps, and joyful recovery milestones."
      />

      {/* Main Gallery Section */}
      <GallerySection />

      {/* Institutional Photography Transparency Note */}
      <section className="w-full py-10 sm:py-12 bg-[#EDE4D3]/40 border-t border-[#294936]/10 text-center">
        <SectionContainer>
          <div className="max-w-2xl mx-auto text-sm text-[#26332B]/80 leading-relaxed font-medium">
            <p>
              All photographs represent real veterinary cases treated at Sai Vet Care Clinic and affiliated rural gaushalas in Maharashtra. We uphold patient dignity and never stage or artificially embellish veterinary interventions.
            </p>
          </div>
        </SectionContainer>
      </section>
    </div>
  );
};
