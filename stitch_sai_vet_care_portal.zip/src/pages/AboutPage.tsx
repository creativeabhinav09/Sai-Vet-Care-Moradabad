import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles, Users } from 'lucide-react';
import { PageHeader } from '../components/PageHeader';
import { FourPillarsSection } from '../components/FourPillarsSection';
import { InstitutionalGovernanceSection } from '../components/InstitutionalGovernanceSection';
import { SatpathyJiSection } from '../components/SatpathyJiSection';
import { SvccArtwork } from '../components/SvccArtwork';
import { ScrollReveal } from '../components/ScrollReveal';
import { ImageParallax } from '../components/ImageParallax';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from '../components/SectionContainer';
import { useCms } from '../cms/CmsContext';

export const AboutPage: React.FC = () => {
  // Stable Intersection Observers for independent full-width sections
  const { ref: narrativeRef, isIntersecting: isNarrativeIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  const { ref: ctaRef, isIntersecting: isCtaIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  const { getPage } = useCms();
  const page = getPage('about');

  useEffect(() => {
    document.title = page?.seo?.metaTitle || 'About SVCC — Foundation & Philosophy | Sai Vet Care Clinic';
  }, [page]);

  return (
    <div className="w-full flex flex-col animate-fade-in">
      {/* Page Header — Full Width */}
      <PageHeader
        breadcrumbCurrent="About SVCC"
        eyebrow="Foundation & Ethos"
        title="A Journey of Compassionate Veterinary Seva"
        description="The humanitarian history, spiritual inspiration, and clinical evolution of Sai Vet Care Clinic — bringing modern veterinary medicine to distressed and voiceless creatures without commercial compromise."
      />

      {/* SECTION 1 — FULL WIDTH: Foundation & Genesis Narrative */}
      <section
        ref={narrativeRef}
        style={{
          paddingTop: 'clamp(28px, 3.5vw, 44px)',
          paddingBottom: 'clamp(28px, 3.5vw, 44px)',
        }}
        className="w-full bg-white relative"
      >
        <SectionContainer>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
            
            {/* Left 7 Columns: Long-form Editorial Narrative */}
            <div className="lg:col-span-7 space-y-5 text-[#26332B]/85 leading-relaxed">
              <ScrollReveal animation="fade-in" delay={100} reverseOnScrollUp={false}>
                <div className="flex items-center gap-2 label-eyebrow text-[#6F8F72] mb-1">
                  <span>Chapter 01</span>
                  <span>·</span>
                  <span>Genesis of Care</span>
                  <span>·</span>
                  <span>Shirdi Region</span>
                </div>
              </ScrollReveal>

              <ScrollReveal animation="text-reveal" delay={180} reverseOnScrollUp={false}>
                <h2 className="section-h2 text-[#294936]">
                  An Oasis for the Injured and Voiceless
                </h2>
              </ScrollReveal>

              <ScrollReveal animation="fade-up" delay={240} reverseOnScrollUp={false}>
                <p className="body-readable first-letter:text-5xl first-letter:font-serif first-letter:font-normal first-letter:float-left first-letter:mr-3 first-letter:mt-1 first-letter:text-[#294936]">
                  Founded in 2009 in the sacred environs of Shirdi, Sai Vet Care Clinic was born from a direct observation of urgent suffering: street dogs critically injured in road accidents, working bullocks collapsing from exhaustion, and indigenous cows suffering from untreated trauma with no dedicated charitable hospital available to heal them.
                </p>
              </ScrollReveal>

              <ScrollReveal animation="fade-up" delay={300} reverseOnScrollUp={false}>
                <p className="body-readable">
                  Under the benevolent spiritual guidance of Revered Dr. Chandra Bhanu Satpathy Ji, our founders resolved that veterinary relief must not remain a luxury reserved for affluent pet owners. Compassion demands that every creature, regardless of ownership status, species, or financial standing, receives equal medical dignity.
                </p>
              </ScrollReveal>

              <ScrollReveal animation="scale-in" delay={360} reverseOnScrollUp={false}>
                <div className="my-5 p-6 rounded-2xl bg-[#EDE4D3]/50 border-l-4 border-[#6F8F72] text-[#294936]">
                  <p className="font-serif italic text-lg sm:text-xl leading-snug">
                    "When an injured animal is lifted from the dust, gently bandaged, and provided nourishment, we restore the sacred bond between humanity and the natural world."
                  </p>
                  <div className="mt-2.5 text-xs font-semibold uppercase tracking-wider text-[#C98268]">
                    — Foundation Charter of SVCC
                  </div>
                </div>
              </ScrollReveal>

              <ScrollReveal animation="fade-up" delay={420} reverseOnScrollUp={false}>
                <p className="body-readable text-[#26332B]/80">
                  Over the past decade and a half, what began as a grassroots emergency triage room has grown into a regional animal welfare network spanning Shirdi, Kopargaon, and Rahata tehsils. Every procedure is performed with scientific rigor and pure devotion.
                </p>
              </ScrollReveal>
            </div>

            {/* Right 5 Columns: Visual Asset with Parallax & Quick Foundation Metrics */}
            <div className="lg:col-span-5 space-y-6">
              <ScrollReveal animation="photo-reveal" delay={200} reverseOnScrollUp={false}>
                <div className="rounded-3xl overflow-hidden border border-[#294936]/15 shadow-md bg-[#EDE4D3] group">
                  <ImageParallax speed={0.06} maxOffset={30}>
                    <div className="aspect-4/3 w-full">
                      <SvccArtwork variant="hero" className="w-full h-full transition-transform duration-700 ease-out group-hover:scale-105" />
                    </div>
                  </ImageParallax>
                  <div className="p-5 bg-white border-t border-[#294936]/10">
                    <div className="label-eyebrow text-[#6F8F72] mb-1">
                      Central Clinic Courtyard · Shirdi
                    </div>
                    <p className="card-body-text text-[#26332B]/80 leading-relaxed">
                      Veterinary doctors and trained caregivers attending to rescued animals in a calm, stress-free clinical sanctuary.
                    </p>
                  </div>
                </div>
              </ScrollReveal>

              {/* Quick Trust Highlights Panel */}
              <ScrollReveal animation="fade-up" delay={300} reverseOnScrollUp={false}>
                <div className="p-6 rounded-3xl bg-[#F7F3EA] border border-[#294936]/15">
                  <div className="flex items-center gap-2 mb-3">
                    <Sparkles className="w-4 h-4 text-[#C98268]" />
                    <span className="label-eyebrow text-[#294936]">
                      SVCC Foundation Benchmarks
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-[#294936]">
                    <div className="p-3.5 bg-white rounded-2xl border border-[#294936]/10">
                      <div className="stat-number text-[#294936]">2009</div>
                      <div className="text-xs sm:text-sm text-[#26332B]/75 font-medium mt-0.5">Established in Shirdi</div>
                    </div>
                    <div className="p-3.5 bg-white rounded-2xl border border-[#294936]/10">
                      <div className="stat-number text-[#C98268]">1,670+</div>
                      <div className="text-xs sm:text-sm text-[#26332B]/75 font-medium mt-0.5">Lives Saved & Healed</div>
                    </div>
                    <div className="p-3.5 bg-white rounded-2xl border border-[#294936]/10">
                      <div className="stat-number text-[#6F8F72]">48+</div>
                      <div className="text-xs sm:text-sm text-[#26332B]/75 font-medium mt-0.5">Gaushalas Adopted</div>
                    </div>
                    <div className="p-3.5 bg-white rounded-2xl border border-[#294936]/10">
                      <div className="stat-number text-[#294936]">100%</div>
                      <div className="text-xs sm:text-sm text-[#26332B]/75 font-medium mt-0.5">Free Charitable Care</div>
                    </div>
                  </div>
                </div>
              </ScrollReveal>
            </div>

          </div>
        </SectionContainer>
      </section>

      {/* SECTION 2 — FULL WIDTH: The Four Pillars of Institutional Seva (Isolated section with 1fr/2fr/4fr grid) */}
      <FourPillarsSection />

      {/* SECTION 3 — FULL WIDTH: Institutional Governance & Ethical Accountability (Isolated section with 1fr/2fr/4fr grid) */}
      <InstitutionalGovernanceSection />

      {/* SECTION 4 — FULL WIDTH: Revered Dr. Chandra Bhanu Satpathy Ji Section */}
      <SatpathyJiSection />

      {/* SECTION 5 — FULL WIDTH: Bottom Call to Action */}
      <section
        ref={ctaRef}
        className="w-full py-8 sm:py-10 lg:py-12 bg-[#EDE4D3]/50 border-t border-[#294936]/10 text-center relative"
      >
        <SectionContainer>
          <div className="max-w-3xl mx-auto">
            <ScrollReveal animation="text-reveal" delay={100} reverseOnScrollUp={false}>
              <h3 className="section-h2 text-[#294936] mb-3">
                Explore How We Serve the Voiceless Every Day
              </h3>
            </ScrollReveal>
            <ScrollReveal animation="fade-up" delay={200} reverseOnScrollUp={false}>
              <p className="body-lead text-[#26332B]/80 mb-6 mx-auto">
                Review our 9 core veterinary seva disciplines, emergency triage hierarchy, and modern clinical surgical care.
              </p>
            </ScrollReveal>
            <ScrollReveal animation="fade-up" delay={300} reverseOnScrollUp={false}>
              <div className="flex flex-wrap items-center justify-center gap-4">
                <Link
                  to="/seva"
                  className="btn-text min-h-[46px] px-6 py-3 rounded-xl bg-[#294936] text-[#F7F3EA] hover:bg-[#1E3827] flex items-center gap-2 shadow-xs transition-colors"
                >
                  <span>Explore 9 Veterinary Seva Disciplines</span>
                  <ArrowRight className="w-4 h-4 btn-icon-move" />
                </Link>
                <Link
                  to="/team"
                  className="btn-text min-h-[46px] px-6 py-3 rounded-xl bg-white border border-[#294936]/20 text-[#294936] hover:bg-[#F7F3EA] flex items-center gap-2 transition-colors"
                >
                  <Users className="w-4 h-4 text-[#6F8F72]" />
                  <span>Meet Our Veterinary Team</span>
                </Link>
              </div>
            </ScrollReveal>
          </div>
        </SectionContainer>
      </section>
    </div>
  );
};
