import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle,
  X,
  ShieldAlert,
  PhoneCall,
  Sun,
  Shield,
} from 'lucide-react';
import { PageHeader } from '../components/PageHeader';
import { VeterinarySevaSection } from '../components/VeterinarySevaSection';
import { PriorityCareSection } from '../components/PriorityCareSection';
import { VETERINARY_SEVA_CARDS } from '../data/svccData';
import { SevaCard } from '../types';
import { ScrollReveal } from '../components/ScrollReveal';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from '../components/SectionContainer';
import { useCms } from '../cms/CmsContext';

export const SevaPage: React.FC = () => {
  const { data, getPage } = useCms();
  const page = getPage('seva');
  const allCards = data?.collections?.sevaCards?.length ? data.collections.sevaCards : VETERINARY_SEVA_CARDS;

  const [selectedSeva, setSelectedSeva] = useState<SevaCard | null>(null);

  const { ref: guideRef, isIntersecting: isGuideIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  useEffect(() => {
    document.title = page?.seo?.metaTitle || 'Veterinary Seva Disciplines | Sai Vet Care Clinic — SVCC';
  }, [page]);

  return (
    <div className="w-full flex flex-col animate-fade-in">
      <PageHeader
        breadcrumbCurrent="Veterinary Seva"
        eyebrow="Clinical & Humanitarian Services"
        title="Nine Disciplines of Veterinary Seva"
        description="Comprehensive veterinary care delivered across emergency wards, surgical suites, and rural pastoral sanctuaries with zero commercial charges for animals in distress."
      />

      {/* Main 9 Seva Cards with Category Filters — Full Width */}
      <VeterinarySevaSection
        onSelectSeva={(id) => {
          const card = allCards.find((c) => c.id === id);
          if (card) setSelectedSeva(card);
        }}
      />

      {/* Modal / In-Depth Protocol Drawer for Selected Seva Card */}
      {selectedSeva && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#26332B]/80 backdrop-blur-xs animate-fade-in"
        >
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 border border-[#294936]/20 shadow-2xl animate-scale-in">
            <div className="flex items-center justify-between pb-3 border-b border-[#294936]/10 mb-4">
              <span className="label-eyebrow text-[#6F8F72]">
                Detailed Treatment Protocol
              </span>
              <button
                onClick={() => setSelectedSeva(null)}
                className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-[#26332B] transition-colors cursor-pointer"
                aria-label="Close dialog"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <h3 className="section-h2 text-[#294936] mb-2">
              {selectedSeva.title}
            </h3>
            <p className="card-body-text text-[#26332B]/80 mb-4">
              {selectedSeva.description}
            </p>

            <h4 className="text-xs font-semibold uppercase tracking-wider text-[#294936] mb-2">
              Standard Clinical Highlights & Equipment:
            </h4>
            <div className="space-y-2 mb-6">
              {selectedSeva.highlights.map((h, i) => (
                <div key={i} className="flex items-center gap-2 text-sm text-[#26332B]/90 bg-[#F7F3EA] p-3 rounded-xl border border-[#294936]/10 font-medium">
                  <CheckCircle className="w-4 h-4 text-[#6F8F72] shrink-0" />
                  <span>{h}</span>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-[#EDE4D3] flex items-center justify-between gap-4">
              <span className="text-xs sm:text-sm text-[#26332B]/75 font-semibold">100% Free Seva Policy</span>
              <Link
                to="/contact"
                className="btn-text min-h-[44px] px-5 py-2.5 rounded-xl bg-[#294936] text-[#F7F3EA] text-sm font-semibold hover:bg-[#1E3827] flex items-center justify-center"
              >
                Request Service Admission
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* Priority Care Hierarchy Section — Full Width */}
      <PriorityCareSection />

      {/* SECTION — FULL WIDTH: Public Action Emergency Roadside Protocol */}
      <section
        ref={guideRef}
        className="w-full py-8 sm:py-10 lg:py-12 bg-[#EDE4D3]/40 border-t border-[#294936]/10 relative"
      >
        <SectionContainer>
          {/* Centered Section Header */}
          <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-12">
            <ScrollReveal animation="fade-in" delay={100} reverseOnScrollUp={false}>
              <span className="label-eyebrow text-[#C98268]">
                Public Response Guidelines
              </span>
            </ScrollReveal>

            <ScrollReveal animation="text-reveal" delay={180} reverseOnScrollUp={false}>
              <h2 className="section-h2 text-[#294936] mt-2">
                Immediate Roadside Rescue Protocol
              </h2>
            </ScrollReveal>

            <ScrollReveal animation="fade-up" delay={260} reverseOnScrollUp={false}>
              <p className="body-lead mt-3 text-[#26332B]/80 mx-auto">
                Follow these critical four steps when finding an injured or collapsed animal in the Shirdi and Ahmednagar regional corridor before mobile veterinary dispatch arrives.
              </p>
            </ScrollReveal>
          </div>

          {/* Full-Width 4-Step Grid Spanning 100% of Container */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
            
            {/* Step 1 */}
            <ScrollReveal animation="fade-up" delay={100} reverseOnScrollUp={false} className="h-full">
              <div className="bg-white rounded-3xl p-6 sm:p-7 border border-[#294936]/15 shadow-xs hover:border-[#6F8F72] hover:shadow-md transition-all duration-300 flex flex-col justify-between h-full">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-[#294936] text-[#EDE4D3] flex items-center justify-center font-serif text-xl">
                      01
                    </div>
                    <Shield className="w-5 h-5 text-[#6F8F72]" />
                  </div>
                  <h3 className="card-h4 text-[#294936] mb-2">
                    Ensure Road Safety First
                  </h3>
                  <p className="card-body-text text-[#26332B]/80">
                    Park your vehicle safely and place a visible hazard triangle or stones to prevent passing vehicles from causing a secondary collision.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#294936]/10 text-xs font-semibold text-[#6F8F72]">
                  Keep human rescuers secure
                </div>
              </div>
            </ScrollReveal>

            {/* Step 2 */}
            <ScrollReveal animation="fade-up" delay={200} reverseOnScrollUp={false} className="h-full">
              <div className="bg-white rounded-3xl p-6 sm:p-7 border border-[#294936]/15 shadow-xs hover:border-[#6F8F72] hover:shadow-md transition-all duration-300 flex flex-col justify-between h-full">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-[#294936] text-[#EDE4D3] flex items-center justify-center font-serif text-xl">
                      02
                    </div>
                    <Sun className="w-5 h-5 text-[#C98268]" />
                  </div>
                  <h3 className="card-h4 text-[#294936] mb-2">
                    Provide Shade & Calm
                  </h3>
                  <p className="card-body-text text-[#26332B]/80">
                    Approach slowly without sudden gestures. Shield the animal from extreme sun with cloth or cardboard. Do not forcibly force-feed cold water to unconscious animals.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#294936]/10 text-xs font-semibold text-[#C98268]">
                  Prevent heatstroke & shock
                </div>
              </div>
            </ScrollReveal>

            {/* Step 3 */}
            <ScrollReveal animation="fade-up" delay={300} reverseOnScrollUp={false} className="h-full">
              <div className="bg-white rounded-3xl p-6 sm:p-7 border border-[#C98268]/30 shadow-xs hover:border-[#C98268] hover:shadow-md transition-all duration-300 flex flex-col justify-between h-full bg-gradient-to-b from-white to-[#F7F3EA]">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-[#C98268] text-white flex items-center justify-center font-serif text-xl">
                      03
                    </div>
                    <ShieldAlert className="w-5 h-5 text-[#C98268]" />
                  </div>
                  <h3 className="card-h4 text-[#C98268] mb-2">
                    Zero Human Painkillers
                  </h3>
                  <p className="card-body-text text-[#26332B]/80">
                    Paracetamol, Ibuprofen, Diclofenac, and Aspirin cause irreversible acute renal failure in dogs, cats, and cows. Never administer any human drugs.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#C98268]/20 text-xs font-semibold text-[#C98268]">
                  Extremely lethal toxicity risk
                </div>
              </div>
            </ScrollReveal>

            {/* Step 4 */}
            <ScrollReveal animation="fade-up" delay={400} reverseOnScrollUp={false} className="h-full">
              <div className="bg-white rounded-3xl p-6 sm:p-7 border border-[#294936]/15 shadow-xs hover:border-[#6F8F72] hover:shadow-md transition-all duration-300 flex flex-col justify-between h-full">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-[#6F8F72] text-white flex items-center justify-center font-serif text-xl">
                      04
                    </div>
                    <PhoneCall className="w-5 h-5 text-[#294936]" />
                  </div>
                  <h3 className="card-h4 text-[#294936] mb-2">
                    Call 24/7 Mobile Van
                  </h3>
                  <p className="card-body-text text-[#26332B]/80">
                    Call <span className="font-mono font-bold text-[#294936]">+91 94220 89108</span> or submit the emergency form with your live GPS location for immediate mobile van dispatch.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#294936]/10 text-xs font-semibold text-[#6F8F72]">
                  15–30 min average response
                </div>
              </div>
            </ScrollReveal>

          </div>

          {/* Full Width Bottom Callout */}
          <div className="mt-10 p-6 rounded-2xl bg-white border border-[#294936]/15 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#294936] text-[#EDE4D3] flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-[#C98268]" />
              </div>
              <p className="card-body-text text-[#26332B]/85">
                <strong className="text-[#294936]">Need roadside assistance right now?</strong> Our mobile ambulances are stationed on standby across Shirdi and Kopargaon corridors.
              </p>
            </div>
            <Link
              to="/contact"
              className="btn-text min-h-[46px] inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#294936] text-[#F7F3EA] text-sm font-semibold hover:bg-[#1E3827] shrink-0 transition-colors shadow-xs"
            >
              <span>Emergency Dispatch Center</span>
              <ArrowRight className="w-4 h-4 btn-icon-move" />
            </Link>
          </div>
        </SectionContainer>
      </section>
    </div>
  );
};
