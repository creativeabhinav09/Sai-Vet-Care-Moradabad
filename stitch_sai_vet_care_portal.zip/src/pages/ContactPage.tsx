import React, { useEffect } from 'react';
import { PageHeader } from '../components/PageHeader';
import { ContactSection } from '../components/ContactSection';
import { Navigation, Car, Bus } from 'lucide-react';
import { ScrollReveal } from '../components/ScrollReveal';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from '../components/SectionContainer';

import { useCms } from '../cms/CmsContext';

export const ContactPage: React.FC = () => {
  const { getPage } = useCms();
  const page = getPage('contact');

  const { ref: directionsRef, isIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  useEffect(() => {
    document.title = page?.seo?.metaTitle || 'Contact & 24/7 Emergency Triage | Sai Vet Care Clinic — SVCC';
  }, [page]);

  return (
    <div className="w-full flex flex-col animate-fade-in">
      <PageHeader
        breadcrumbCurrent="Contact"
        eyebrow="Emergency & Seva Inquiries"
        title="24/7 Emergency Trauma & Contact"
        description="Immediate reporting for roadside trauma rescues, gaushala medical consultations, and hospital directions in Shirdi, Maharashtra."
      />

      {/* Main Contact & Form Section */}
      <ContactSection />

      {/* Transit & Hospital Directions Guide */}
      <section
        ref={directionsRef}
        className="w-full py-8 sm:py-10 lg:py-12 bg-white border-t border-[#294936]/10 relative"
      >
        <SectionContainer>
          <div className="text-center max-w-2xl mx-auto mb-6 sm:mb-8">
            <ScrollReveal animation="fade-in" delay={100} reverseOnScrollUp={false}>
              <span className="label-eyebrow text-[#6F8F72]">
                Transit Directions
              </span>
            </ScrollReveal>
            <ScrollReveal animation="text-reveal" delay={180} reverseOnScrollUp={false}>
              <h3 className="section-h2 text-[#294936] mt-2">
                How to Reach Sai Vet Care Clinic
              </h3>
            </ScrollReveal>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 lg:gap-6 items-stretch">
            <ScrollReveal animation="fade-up" delay={200} reverseOnScrollUp={false} className="h-full">
              <div className="p-6 sm:p-7 rounded-3xl bg-[#F7F3EA] border border-[#294936]/15 h-full flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2.5 text-xs font-semibold text-[#294936] uppercase tracking-wider mb-2">
                    <Navigation className="w-4 h-4 text-[#C98268]" />
                    <span>From Shirdi Shrine Belt</span>
                  </div>
                  <p className="card-body-text text-[#26332B]/85">
                    Head north on Shirdi-Kopargaon State Highway towards Kopargaon. The clinic entrance is located 2.4 km from the temple outer perimeter on the right hand side, demarcated by green botanical signage.
                  </p>
                </div>
              </div>
            </ScrollReveal>

            <ScrollReveal animation="fade-up" delay={300} reverseOnScrollUp={false} className="h-full">
              <div className="p-6 sm:p-7 rounded-3xl bg-[#F7F3EA] border border-[#294936]/15 h-full flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2.5 text-xs font-semibold text-[#294936] uppercase tracking-wider mb-2">
                    <Car className="w-4 h-4 text-[#6F8F72]" />
                    <span>From Kopargaon Station</span>
                  </div>
                  <p className="card-body-text text-[#26332B]/85">
                    Take the main Shirdi road south for approximately 11 km. Our emergency veterinary ambulance bay is equipped with a dedicated drive-in unloading ramp for injured animals.
                  </p>
                </div>
              </div>
            </ScrollReveal>

            <ScrollReveal animation="fade-up" delay={400} reverseOnScrollUp={false} className="h-full">
              <div className="p-6 sm:p-7 rounded-3xl bg-[#F7F3EA] border border-[#294936]/15 h-full flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2.5 text-xs font-semibold text-[#294936] uppercase tracking-wider mb-2">
                    <Bus className="w-4 h-4 text-[#294936]" />
                    <span>From Pune / Nashik Highways</span>
                  </div>
                  <p className="card-body-text text-[#26332B]/85">
                    Connect via Sangamner or Kopargaon bypass. For large animal transport (cattle trucks / horse floats), please alert our reception in advance so our yard crush can be cleared.
                  </p>
                </div>
              </div>
            </ScrollReveal>
          </div>
        </SectionContainer>
      </section>
    </div>
  );
};
