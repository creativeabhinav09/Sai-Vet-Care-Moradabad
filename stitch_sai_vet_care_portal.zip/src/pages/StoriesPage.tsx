import React, { useEffect, useState } from 'react';
import { Calendar, Clock, ArrowRight, X } from 'lucide-react';
import { PageHeader } from '../components/PageHeader';
import { STORY_UPDATES } from '../data/svccData';
import { StoryUpdate } from '../types';
import { SvccArtwork } from '../components/SvccArtwork';
import { ScrollReveal } from '../components/ScrollReveal';
import { ImageParallax } from '../components/ImageParallax';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from '../components/SectionContainer';

import { useCms } from '../cms/CmsContext';

export const StoriesPage: React.FC = () => {
  const { data, getPage } = useCms();
  const page = getPage('stories');
  const rawStories = data?.collections?.stories?.length ? data.collections.stories : STORY_UPDATES;
  const storyList = rawStories.filter((s: any) => !s.status || s.status === 'published');

  const [activeStory, setActiveStory] = useState<any | null>(null);

  const { ref: sectionRef, isIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  useEffect(() => {
    document.title = page?.seo?.metaTitle || 'Stories of Healing & Updates | Sai Vet Care Clinic — SVCC';
  }, [page]);

  const getArtworkVariant = (id: string): 'hero' | 'satpathy' | 'medical' | 'surgical' | 'gaushala' | 'rehab' | 'emergency' => {
    if (id === 'story-1') return 'gaushala';
    if (id === 'story-2') return 'hero';
    return 'surgical';
  };

  return (
    <div className="w-full flex flex-col animate-fade-in">
      <PageHeader
        breadcrumbCurrent="Stories & Updates"
        eyebrow="Clinical Journals"
        title="Stories of Healing & Seva Updates"
        description="First-hand accounts from our veterinary wards and mobile units, chronicling patient recoveries, rural livestock missions, and life-saving interventions."
      />

      {/* Main Stories Grid */}
      <section
        ref={sectionRef}
        className="w-full py-8 sm:py-10 lg:py-12 bg-white relative"
      >
        <SectionContainer>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 items-stretch">
            {storyList.map((story: any, index: number) => (
              <ScrollReveal
                key={story.id}
                animation="fade-up"
                delay={150 + index * 120}
                reverseOnScrollUp={false}
                className="h-full"
              >
                <article
                  onClick={() => setActiveStory(story)}
                  className="svcc-card bg-[#F7F3EA] rounded-3xl overflow-hidden border border-[#294936]/15 shadow-xs hover:border-[#6F8F72] hover:shadow-md cursor-pointer flex flex-col justify-between group h-full relative"
                >
                  <div className="card-accent-line" />
                  <div>
                    <div className="aspect-16/10 w-full overflow-hidden bg-[#EDE4D3] relative">
                      <ImageParallax speed={0.06} maxOffset={25}>
                        {story.imageUrl ? (
                          <img
                            src={story.imageUrl}
                            alt={story.title}
                            className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
                          />
                        ) : (
                          <SvccArtwork
                            variant={getArtworkVariant(story.id)}
                            className="w-full h-full transition-transform duration-500 ease-out group-hover:scale-105"
                          />
                        )}
                      </ImageParallax>
                      <div className="absolute top-3 left-3 bg-[#294936]/90 text-[#F7F3EA] text-xs font-semibold uppercase tracking-wider px-3 py-1 rounded-full z-10 shadow-xs">
                        {story.category}
                      </div>
                    </div>

                    <div className="p-6">
                      <div className="flex items-center justify-between text-xs text-[#26332B]/75 mb-2.5 font-medium">
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-[#6F8F72]" />
                          <span>{story.date}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-[#C98268]" />
                          <span>{story.readTime}</span>
                        </div>
                      </div>

                      <h3 className="sub-h3 text-[#294936] leading-snug mb-3 group-hover:text-[#1E3827] transition-colors">
                        {story.title}
                      </h3>

                      <p className="card-body-text text-[#26332B]/85">
                        {story.summary}
                      </p>
                    </div>
                  </div>

                  <div className="p-6 pt-0">
                    <div className="pt-4 border-t border-[#EDE4D3] flex items-center justify-between text-sm font-semibold text-[#294936] group-hover:text-[#C98268] transition-colors">
                      <span>Read Full Chronicle</span>
                      <ArrowRight className="w-4 h-4 card-arrow-move" />
                    </div>
                  </div>
                </article>
              </ScrollReveal>
            ))}
          </div>
        </SectionContainer>
      </section>

      {/* Expanded Story Reading Modal */}
      {activeStory && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#26332B]/80 backdrop-blur-xs animate-fade-in"
        >
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 border border-[#294936]/20 shadow-2xl animate-scale-in max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-[#294936]/10 mb-4">
              <span className="label-eyebrow text-[#6F8F72]">
                {activeStory.category} · {activeStory.date}
              </span>
              <button
                onClick={() => setActiveStory(null)}
                className="p-1 rounded-md text-[#26332B]/70 hover:text-[#294936] cursor-pointer"
                aria-label="Close story reader"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="aspect-16/9 w-full rounded-2xl overflow-hidden mb-6 bg-[#EDE4D3]">
              {activeStory.imageUrl ? (
                <img
                  src={activeStory.imageUrl}
                  alt={activeStory.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <SvccArtwork variant={getArtworkVariant(activeStory.id)} className="w-full h-full" />
              )}
            </div>

            <h3 className="section-h2 text-[#294936] leading-tight mb-4">
              {activeStory.title}
            </h3>

            {activeStory.content ? (
              <div
                className="space-y-4 body-readable text-[#26332B]/85 prose prose-emerald max-w-none"
                dangerouslySetInnerHTML={{ __html: activeStory.content }}
              />
            ) : (
              <div className="space-y-4 body-readable text-[#26332B]/85">
                <p>{activeStory.summary}</p>
                <p>
                  Our veterinary team deployed emergency radiographic imaging upon admission to ascertain the extent of internal injury. Immediate antibiotic coverage and continuous IV infusion therapy stabilized the patient's vitals before surgical wound debridement.
                </p>
                <p>
                  Through daily therapeutic dressing changes and loving supervision by our nursing staff, complete cellular granulation was achieved. Today, the animal has fully regained independent vitality — a testament to what compassionate community seva can accomplish.
                </p>
              </div>
            )}

            <div className="mt-8 pt-4 border-t border-[#EDE4D3] flex items-center justify-between">
              <span className="text-xs text-[#26332B]/70 font-medium">Sai Vet Care Clinic Case Archive</span>
              <button
                onClick={() => setActiveStory(null)}
                className="btn-text min-h-[44px] px-5 py-2.5 rounded-xl bg-[#294936] text-[#F7F3EA] text-sm font-semibold hover:bg-[#1E3827] cursor-pointer"
              >
                Close Article
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
