import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Stethoscope, ShieldCheck, HeartPulse, ArrowRight } from 'lucide-react';
import { PageHeader } from '../components/PageHeader';
import { MedicalSurgicalSection } from '../components/MedicalSurgicalSection';
import { MedicinesSection } from '../components/MedicinesSection';
import { ScrollReveal } from '../components/ScrollReveal';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from '../components/SectionContainer';
import { useCms } from '../cms/CmsContext';

export const ClinicalPage: React.FC = () => {
  const { ref: protocolRef, isIntersecting: isProtocolIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  const { getPage } = useCms();
  const page = getPage('clinical');

  useEffect(() => {
    document.title = page?.seo?.metaTitle || 'Medical & Surgical Care | Sai Vet Care Clinic — SVCC';
  }, [page]);

  return (
    <div className="w-full flex flex-col animate-fade-in">
      <PageHeader
        breadcrumbCurrent="Medical & Surgery"
        eyebrow="Clinical Infrastructure"
        title="Clinical Medical & Surgical Care"
        description="Combining diagnostic pathology, evidence-based pharmacology, and a sterile operating theater to deliver life-saving interventions to distressed animals."
      />

      {/* Main Dual Division Section */}
      <MedicalSurgicalSection />

      {/* Comprehensive Medicines Formulary Section */}
      <MedicinesSection />

      {/* Aseptic Protocol & Quality Control Standards */}
      <section
        ref={protocolRef}
        className="w-full py-8 sm:py-10 lg:py-12 bg-[#EDE4D3]/40 border-t border-[#294936]/10 relative"
      >
        <SectionContainer>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
            <ScrollReveal animation="fade-up" delay={100} reverseOnScrollUp={false} className="h-full">
              <div className="p-6 sm:p-7 rounded-3xl bg-white border border-[#294936]/15 shadow-xs h-full flex flex-col justify-between">
                <div>
                  <div className="w-12 h-12 rounded-2xl bg-[#6F8F72]/20 text-[#294936] flex items-center justify-center mb-4">
                    <ShieldCheck className="w-6 h-6 text-[#294936]" />
                  </div>
                  <h3 className="sub-h3 text-[#294936] mb-2">
                    Aseptic Theater Protocol
                  </h3>
                  <p className="card-body-text text-[#26332B]/80">
                    Operating suites undergo UV-C air sterilization cycles, multi-stage autoclave sterilization of surgical tools, and strict non-cross contamination barriers.
                  </p>
                </div>
              </div>
            </ScrollReveal>

            <ScrollReveal animation="fade-up" delay={200} reverseOnScrollUp={false} className="h-full">
              <div className="p-6 sm:p-7 rounded-3xl bg-white border border-[#294936]/15 shadow-xs h-full flex flex-col justify-between">
                <div>
                  <div className="w-12 h-12 rounded-2xl bg-[#294936] text-[#EDE4D3] flex items-center justify-center mb-4">
                    <HeartPulse className="w-6 h-6 text-[#C98268]" />
                  </div>
                  <h3 className="sub-h3 text-[#294936] mb-2">
                    Multimodal Anesthesia & Pain Control
                  </h3>
                  <p className="card-body-text text-[#26332B]/80">
                    Animal pain management follows the highest humane standards using balanced injectable analgesia, local nerve blocks, and continuous vital monitoring during procedures.
                  </p>
                </div>
              </div>
            </ScrollReveal>

            <ScrollReveal animation="fade-up" delay={300} reverseOnScrollUp={false} className="h-full">
              <div className="p-6 sm:p-7 rounded-3xl bg-white border border-[#294936]/15 shadow-xs h-full flex flex-col justify-between">
                <div>
                  <div className="w-12 h-12 rounded-2xl bg-[#C98268]/20 text-[#C98268] flex items-center justify-center mb-4">
                    <Stethoscope className="w-6 h-6 text-[#C98268]" />
                  </div>
                  <h3 className="sub-h3 text-[#294936] mb-2">
                    Rehabilitation & Physiotherapy
                  </h3>
                  <p className="card-body-text text-[#26332B]/80">
                    Post-operative patients are accommodated in climate-controlled recovery suites with padded bedding, assisted mobility slings, and supervised daily dressing changes.
                  </p>
                </div>
              </div>
            </ScrollReveal>
          </div>

          <div className="mt-10 text-center">
            <ScrollReveal animation="fade-up" delay={400} reverseOnScrollUp={false}>
              <Link
                to="/team"
                className="btn-text min-h-[46px] inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#294936] text-[#F7F3EA] hover:bg-[#1E3827] shadow-xs transition-colors"
              >
                <span>Meet Our Veterinary Surgeons</span>
                <ArrowRight className="w-4 h-4 btn-icon-move" />
              </Link>
            </ScrollReveal>
          </div>
        </SectionContainer>
      </section>
    </div>
  );
};
