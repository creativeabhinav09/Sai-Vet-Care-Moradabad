import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Truck } from 'lucide-react';
import { PageHeader } from '../components/PageHeader';
import { ServiceNetworkSection } from '../components/ServiceNetworkSection';
import { ScrollReveal } from '../components/ScrollReveal';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from '../components/SectionContainer';
import { useCms } from '../cms/CmsContext';

export const NetworkPage: React.FC = () => {
  const { ref: ambulanceRef, isIntersecting: isAmbulanceIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  const { getPage } = useCms();
  const page = getPage('network');

  useEffect(() => {
    document.title = page?.seo?.metaTitle || 'Service Network & Coverage Map | Sai Vet Care Clinic — SVCC';
  }, [page]);

  return (
    <div className="w-full flex flex-col animate-fade-in">
      <PageHeader
        breadcrumbCurrent="Service Network"
        eyebrow="Regional Footprint"
        title="Service Network & Rural Outreach"
        description="Connecting central hospital trauma care with remote agricultural villages, gaushala shelters, and a dedicated mobile emergency ambulance fleet."
      />

      {/* Main Interactive Map & Network Hub Section */}
      <ServiceNetworkSection />

      {/* Mobile Ambulance Dispatch Information */}
      <section
        ref={ambulanceRef}
        className="w-full py-8 sm:py-10 lg:py-12 bg-white border-t border-[#294936]/10 relative"
      >
        <SectionContainer>
          <ScrollReveal animation="fade-up" delay={100} reverseOnScrollUp={false}>
            <div className="bg-[#F7F3EA] rounded-3xl p-6 sm:p-8 md:p-10 border border-[#294936]/15 relative overflow-hidden">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                
                <div className="lg:col-span-8 space-y-4">
                  <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#294936] text-[#EDE4D3] text-xs font-semibold">
                    <Truck className="w-4 h-4 text-[#C98268]" />
                    <span>Fleet of 3 Dedicated Rapid Mobile Ambulances</span>
                  </div>

                  <h3 className="section-h2 text-[#294936]">
                    24/7 Mobile Animal Rescue & Doorstep Seva
                  </h3>

                  <p className="card-body-text text-[#26332B]/85">
                    When large cattle, injured strays, or non-ambulatory animals cannot be transported to the hospital, our fully-equipped Mobile Seva Ambulance brings the clinic directly to the field. Fitted with hydraulic stretcher lifts, onboard oxygen, and emergency surgical kits.
                  </p>

                  <div className="grid grid-cols-2 gap-3 pt-2 text-sm font-medium text-[#294936]">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#6F8F72]" />
                      <span>Coverage Across 45+ Farming Hamlets</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#6F8F72]" />
                      <span>Zero Toll or Fuel Surcharge for Strays</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#6F8F72]" />
                      <span>Emergency Roadside Trauma Stabilization</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#6F8F72]" />
                      <span>Equipped with Portable Ultrasound Scanner</span>
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-4 bg-white p-6 sm:p-7 rounded-3xl border border-[#294936]/15 text-center space-y-3.5 shadow-xs">
                  <span className="label-eyebrow text-[#C98268]">
                    Direct Dispatch Hotline
                  </span>
                  <div className="text-2xl sm:text-3xl font-serif text-[#294936] font-mono">
                    +91 94220 89108
                  </div>
                  <p className="text-xs sm:text-sm text-[#26332B]/75 leading-relaxed font-medium">
                    Duty officer on call 24 hours daily. Mobile unit dispatched within minutes.
                  </p>
                  <Link
                    to="/contact"
                    className="btn-text min-h-[46px] w-full py-3 px-4 rounded-xl bg-[#294936] text-[#F7F3EA] hover:bg-[#1E3827] flex items-center justify-center gap-2 shadow-xs transition-colors"
                  >
                    <span>Dispatch Request Form</span>
                    <ArrowRight className="w-4 h-4 btn-icon-move" />
                  </Link>
                </div>

              </div>
            </div>
          </ScrollReveal>
        </SectionContainer>
      </section>
    </div>
  );
};
