import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { HeroSection } from '../components/HeroSection';
import { AboutSection } from '../components/AboutSection';
import { SatpathyJiSection } from '../components/SatpathyJiSection';
import { VeterinarySevaSection } from '../components/VeterinarySevaSection';
import { PriorityCareSection } from '../components/PriorityCareSection';
import { MedicalSurgicalSection } from '../components/MedicalSurgicalSection';
import { MedicinesSection } from '../components/MedicinesSection';
import { ProjectCatalogSection } from '../components/ProjectCatalogSection';
import { ImpactCounterSection } from '../components/ImpactCounterSection';
import { ServiceNetworkSection } from '../components/ServiceNetworkSection';
import { TeamSection } from '../components/TeamSection';
import { GallerySection } from '../components/GallerySection';
import { UpdatesSection } from '../components/UpdatesSection';
import { ContactSection } from '../components/ContactSection';

import { useCms } from '../cms/CmsContext';

export const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const { getPage } = useCms();
  const page = getPage('home');

  useEffect(() => {
    document.title = page?.seo?.metaTitle || 'Sai Vet Care Clinic — SVCC | Compassionate Veterinary Seva & Pet Care';
  }, [page]);

  const renderSection = (sectionId: string) => {
    switch (sectionId) {
      case 'hero':
        return (
          <HeroSection
            key="hero"
            onNavigateToSeva={() => {
              const el = document.getElementById('seva');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
              else navigate('/seva');
            }}
            onNavigateToContact={() => navigate('/contact')}
            onNavigateToAbout={() => navigate('/about')}
          />
        );
      case 'about':
        return <AboutSection key="about" onLearnMore={() => navigate('/about')} />;
      case 'satpathy':
        return <SatpathyJiSection key="satpathy" />;
      case 'seva':
        return (
          <div id="seva" key="seva">
            <VeterinarySevaSection onSelectSeva={() => navigate('/seva')} />
          </div>
        );
      case 'priority-care':
        return <PriorityCareSection key="priority-care" onContactEmergency={() => navigate('/contact')} />;
      case 'medical-surgical':
        return <MedicalSurgicalSection key="medical-surgical" />;
      case 'medicines':
        return <MedicinesSection key="medicines" />;
      case 'projects':
        return (
          <div id="projects" key="projects">
            <ProjectCatalogSection />
          </div>
        );
      case 'impact':
        return <ImpactCounterSection key="impact" />;
      case 'network':
        return <ServiceNetworkSection key="network" />;
      case 'team':
        return <TeamSection key="team" />;
      case 'gallery':
        return <GallerySection key="gallery" />;
      case 'updates':
        return <UpdatesSection key="updates" onSelectStory={() => navigate('/stories')} />;
      case 'contact':
        return <ContactSection key="contact" />;
      default:
        return null;
    }
  };

  const defaultOrder = [
    { id: 'hero' },
    { id: 'about' },
    { id: 'satpathy' },
    { id: 'seva' },
    { id: 'priority-care' },
    { id: 'medical-surgical' },
    { id: 'medicines' },
    { id: 'projects' },
    { id: 'impact' },
    { id: 'network' },
    { id: 'team' },
    { id: 'gallery' },
    { id: 'updates' },
    { id: 'contact' },
  ];

  const sectionsToRender = page?.sections && page.sections.length > 0
    ? page.sections.filter((s) => s.enabled !== false)
    : defaultOrder;

  return (
    <div className="w-full flex flex-col">
      {sectionsToRender.map((s) => renderSection(s.id))}
    </div>
  );
};

