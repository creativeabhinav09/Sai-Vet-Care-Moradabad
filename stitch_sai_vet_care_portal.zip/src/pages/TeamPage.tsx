import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { HeartHandshake } from 'lucide-react';
import { PageHeader } from '../components/PageHeader';
import { TeamSection } from '../components/TeamSection';
import { ScrollReveal } from '../components/ScrollReveal';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionContainer } from '../components/SectionContainer';

import { useCms } from '../cms/CmsContext';

export const TeamPage: React.FC = () => {
  const { getPage } = useCms();
  const page = getPage('team');

  const { ref: pledgeRef, isIntersecting: isPledgeIntersecting } = useIntersectionObserver<HTMLElement>({
    threshold: 0.08,
    triggerOnce: true,
  });

  useEffect(() => {
    document.title = page?.seo?.metaTitle || 'Our Veterinary Team | Sai Vet Care Clinic — SVCC';
  }, [page]);

  return (
    <div className="w-full flex flex-col animate-fade-in">
      <PageHeader
        breadcrumbCurrent="Our Team"
        eyebrow="Clinical Leadership"
        title="Our Dedicated Veterinary Doctors & Staff"
        description="Combining academic veterinary credentials from premier institutions with unwavering humanitarian dedication to relieve animal suffering."
      />

      {/* Main Team Section with Professional Cards */}
      <TeamSection />

      {/* The SVCC Ethical Seva Pledge */}
      <section
        ref={pledgeRef}
        className="w-full py-8 sm:py-10 lg:py-12 bg-[#EDE4D3]/40 border-t border-[#294936]/10 relative"
      >
        <SectionContainer>
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <ScrollReveal animation="scale-in" delay={100} reverseOnScrollUp={false}>
              <div className="w-14 h-14 rounded-2xl bg-[#294936] text-[#EDE4D3] flex items-center justify-center mx-auto shadow-sm">
                <HeartHandshake className="w-7 h-7 text-[#C98268]" />
              </div>
            </ScrollReveal>

            <ScrollReveal animation="text-reveal" delay={180} reverseOnScrollUp={false}>
              <h3 className="section-h2 text-[#294936]">
                The SVCC Veterinary Seva Pledge
              </h3>
            </ScrollReveal>

            <ScrollReveal animation="fade-up" delay={260} reverseOnScrollUp={false}>
              <div className="bg-white p-6 sm:p-8 rounded-3xl border border-[#294936]/15 shadow-xs text-left space-y-4 leading-relaxed">
                <p className="font-serif italic text-base sm:text-lg text-[#294936] leading-relaxed">
                  "I solemnly pledge to dedicate my scientific veterinary knowledge and technical surgical skill to the relief of pain in all sentient creatures. In honoring the sacred seva philosophy of Dr. C.B. Satpathy Ji, I shall never refuse treatment to an animal on account of poverty, abandonment, or lack of ownership."
                </p>
                <div className="pt-3 border-t border-[#EDE4D3] flex flex-wrap items-center justify-between text-xs sm:text-sm text-[#26332B]/75 font-medium">
                  <span className="font-semibold text-[#294936]">Solemnly affirmed by every doctor and caregiver at SVCC</span>
                  <span className="text-[#C98268] font-bold">Unconditional Compassion</span>
                </div>
              </div>
            </ScrollReveal>

            <ScrollReveal animation="fade-up" delay={340} reverseOnScrollUp={false}>
              <div className="pt-2 flex flex-wrap items-center justify-center gap-4">
                <Link
                  to="/contact"
                  className="btn-text min-h-[46px] px-6 py-3 rounded-xl bg-[#294936] text-[#F7F3EA] hover:bg-[#1E3827] shadow-xs transition-colors"
                >
                  Contact Our Clinic Duty Desk
                </Link>
                <Link
                  to="/gallery"
                  className="btn-text min-h-[46px] px-6 py-3 rounded-xl bg-white border border-[#294936]/20 text-[#294936] hover:bg-[#F7F3EA] transition-colors"
                >
                  View Clinical Field Gallery
                </Link>
              </div>
            </ScrollReveal>
          </div>
        </SectionContainer>
      </section>
    </div>
  );
};
