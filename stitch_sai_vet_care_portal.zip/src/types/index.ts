export interface SevaCard {
  id: string;
  title: string;
  category: 'clinical' | 'aid' | 'community';
  description: string;
  iconName: string;
  highlights: string[];
}

export interface PriorityCareItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  responseProtocol: string;
  iconName: string;
  urgency: 'high' | 'critical' | 'scheduled';
}

export interface MedicalSurgicalDiscipline {
  id: string;
  type: 'medical' | 'surgical';
  title: string;
  eyebrow: string;
  description: string;
  procedures: string[];
  equipment: string[];
}

export interface MedicineItem {
  id: string;
  name: string;
  type: string;
  usage: string;
  availability: '100% Free Dispensary' | 'Clinical Stock' | 'Emergency Ward';
}

export interface NetworkLocation {
  id: string;
  name: string;
  role: string;
  address: string;
  timing: string;
  contact: string;
  coordinates: { x: number; y: number }; // percentage on regional map
  facilities: string[];
}

export interface GaushalaPartnership {
  id: string;
  name: string;
  location: string;
  animals: number;
  contact: string;
  contactPerson?: string;
  notes?: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  qualification: string;
  experience: string;
  bio: string;
  specialization: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  caption: string;
  date: string;
  location: string;
  imageUrl?: string;
}

export interface StoryUpdate {
  id: string;
  title: string;
  date: string;
  category: string;
  summary: string;
  readTime: string;
  imageUrl?: string;
}

export interface TimelineMilestone {
  year: string;
  title: string;
  description: string;
  achievement: string;
}
