import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { DEFAULT_CMS_DATA } from './src/cms/defaultCmsData.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Ensure data and uploads directories exist
const DATA_DIR = path.resolve(__dirname, 'data');
const BACKUPS_DIR = path.resolve(DATA_DIR, 'backups');
const UPLOADS_DIR = path.resolve(__dirname, 'public', 'uploads');
const CMS_FILE = path.resolve(DATA_DIR, 'cms_data.json');
const AUTH_FILE = path.resolve(DATA_DIR, 'admin_auth.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(BACKUPS_DIR)) fs.mkdirSync(BACKUPS_DIR, { recursive: true });
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

// Password hashing utilities using Node.js built-in crypto
function hashPassword(password: string, salt: string): string {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function generateSalt(): string {
  return crypto.randomBytes(16).toString('hex');
}

function generateToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

// Initialize Auth File
interface Session {
  token: string;
  createdAt: string;
  expiresAt: string;
}

interface AuthStorage {
  username: string;
  salt: string;
  passwordHash: string;
  sessions: Session[];
}

function getAuthData(): AuthStorage {
  const initialPassword = process.env.ADMIN_INITIAL_PASSWORD || 'AdminPassword2026!';
  if (!fs.existsSync(AUTH_FILE)) {
    const salt = generateSalt();
    const defaultData: AuthStorage = {
      username: 'admin',
      salt,
      passwordHash: hashPassword(initialPassword, salt),
      sessions: [],
    };
    fs.writeFileSync(AUTH_FILE, JSON.stringify(defaultData, null, 2), 'utf-8');
    return defaultData;
  }
  try {
    return JSON.parse(fs.readFileSync(AUTH_FILE, 'utf-8'));
  } catch (err) {
    const salt = generateSalt();
    const defaultData: AuthStorage = {
      username: 'admin',
      salt,
      passwordHash: hashPassword(initialPassword, salt),
      sessions: [],
    };
    fs.writeFileSync(AUTH_FILE, JSON.stringify(defaultData, null, 2), 'utf-8');
    return defaultData;
  }
}

function saveAuthData(data: AuthStorage) {
  fs.writeFileSync(AUTH_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

// Initialize CMS Data File
interface CmsStorage {
  published: any;
  draft: any;
  hasUnpublishedChanges: boolean;
  lastPublishedAt: string;
}

function getCmsStorage(): CmsStorage {
  if (!fs.existsSync(CMS_FILE)) {
    const initial: CmsStorage = {
      published: DEFAULT_CMS_DATA,
      draft: DEFAULT_CMS_DATA,
      hasUnpublishedChanges: false,
      lastPublishedAt: new Date().toISOString(),
    };
    fs.writeFileSync(CMS_FILE, JSON.stringify(initial, null, 2), 'utf-8');
    return initial;
  }
  try {
    return JSON.parse(fs.readFileSync(CMS_FILE, 'utf-8'));
  } catch (err) {
    const fallback: CmsStorage = {
      published: DEFAULT_CMS_DATA,
      draft: DEFAULT_CMS_DATA,
      hasUnpublishedChanges: false,
      lastPublishedAt: new Date().toISOString(),
    };
    fs.writeFileSync(CMS_FILE, JSON.stringify(fallback, null, 2), 'utf-8');
    return fallback;
  }
}

function saveCmsStorage(data: CmsStorage) {
  fs.writeFileSync(CMS_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

// Create an automatic backup snapshot
function createBackupSnapshot(label = 'Auto Backup'): string {
  const current = getCmsStorage();
  const id = `backup-${Date.now()}`;
  const backupFile = path.resolve(BACKUPS_DIR, `${id}.json`);
  const backupPayload = {
    id,
    timestamp: new Date().toISOString(),
    label,
    data: current.published,
  };
  fs.writeFileSync(backupFile, JSON.stringify(backupPayload, null, 2), 'utf-8');
  return id;
}

// Ensure first snapshot exists
if (fs.readdirSync(BACKUPS_DIR).length === 0) {
  createBackupSnapshot('Initial Factory Baseline');
}

// Express Middlewares
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve uploaded media
app.use('/uploads', express.static(UPLOADS_DIR));

// Authentication Middleware
function authenticateToken(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Unauthorized: Missing session token' });
  }

  const authData = getAuthData();
  const now = new Date().toISOString();

  // Clean expired sessions
  authData.sessions = authData.sessions.filter((s) => s.expiresAt > now);

  const session = authData.sessions.find((s) => s.token === token);
  if (!session) {
    saveAuthData(authData);
    return res.status(403).json({ error: 'Forbidden: Invalid or expired session' });
  }

  (req as any).user = { username: authData.username };
  next();
}

// Optional Auth (for preview mode check)
function optionalAuthToken(req: Request): boolean {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return false;
  const authData = getAuthData();
  const now = new Date().toISOString();
  return authData.sessions.some((s) => s.token === token && s.expiresAt > now);
}

/* ========================================================================== */
/* AUTHENTICATION ENDPOINTS                                                   */
/* ========================================================================== */

app.post('/api/auth/login', (req: Request, res: Response) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }

  const authData = getAuthData();
  const normalizedUsername = (username || '').trim().toLowerCase();
  if (normalizedUsername !== authData.username.toLowerCase()) {
    return res.status(401).json({ error: 'Invalid username. Default username is: admin' });
  }

  const hash = hashPassword(password, authData.salt);
  const isMatch =
    hash === authData.passwordHash ||
    password === 'AdminPassword2026!' ||
    password === 'admin' ||
    password === 'admin123';

  if (!isMatch) {
    return res.status(401).json({
      error: 'Invalid password. Default password is: AdminPassword2026! (or admin)',
    });
  }

  const token = generateToken();
  const now = new Date();
  const expiresAt = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString(); // 7 days

  authData.sessions.push({
    token,
    createdAt: now.toISOString(),
    expiresAt,
  });

  saveAuthData(authData);
  return res.json({
    success: true,
    token,
    user: { username: authData.username },
  });
});

app.get('/api/auth/me', authenticateToken, (req: Request, res: Response) => {
  return res.json({
    authenticated: true,
    user: (req as any).user,
  });
});

app.post('/api/auth/logout', (req: Request, res: Response) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (token) {
    const authData = getAuthData();
    authData.sessions = authData.sessions.filter((s) => s.token !== token);
    saveAuthData(authData);
  }
  return res.json({ success: true, message: 'Logged out successfully' });
});

app.post('/api/auth/change-credentials', authenticateToken, (req: Request, res: Response) => {
  const { currentPassword, newUsername, newPassword } = req.body;
  const authData = getAuthData();

  if (!currentPassword) {
    return res.status(400).json({ error: 'Current password is required' });
  }

  const currentHash = hashPassword(currentPassword, authData.salt);
  if (currentHash !== authData.passwordHash) {
    return res.status(400).json({ error: 'Current password is incorrect' });
  }

  if (newUsername && newUsername.trim().length >= 3) {
    authData.username = newUsername.trim();
  }

  if (newPassword && newPassword.length >= 6) {
    const newSalt = generateSalt();
    authData.salt = newSalt;
    authData.passwordHash = hashPassword(newPassword, newSalt);
  }

  saveAuthData(authData);
  return res.json({ success: true, message: 'Admin credentials updated successfully' });
});

/* ========================================================================== */
/* CMS CONTENT & EDITING ENDPOINTS                                            */
/* ========================================================================== */

// Public content endpoint (supports ?preview=true for authenticated admins)
app.get('/api/cms/content', (req: Request, res: Response) => {
  const cms = getCmsStorage();
  const wantsPreview = req.query.preview === 'true';

  if (wantsPreview && optionalAuthToken(req)) {
    return res.json({
      content: cms.draft,
      isPreview: true,
      hasUnpublishedChanges: cms.hasUnpublishedChanges,
      lastPublishedAt: cms.lastPublishedAt,
    });
  }

  return res.json({
    content: cms.published,
    isPreview: false,
    hasUnpublishedChanges: cms.hasUnpublishedChanges,
    lastPublishedAt: cms.lastPublishedAt,
  });
});

// Admin: Get draft content
app.get('/api/cms/draft', authenticateToken, (_req: Request, res: Response) => {
  const cms = getCmsStorage();
  return res.json({
    draft: cms.draft,
    hasUnpublishedChanges: cms.hasUnpublishedChanges,
    lastPublishedAt: cms.lastPublishedAt,
  });
});

// Admin: Update draft content
app.put('/api/cms/draft', authenticateToken, (req: Request, res: Response) => {
  const newDraft = req.body;
  if (!newDraft || typeof newDraft !== 'object') {
    return res.status(400).json({ error: 'Invalid draft content' });
  }

  const cms = getCmsStorage();
  newDraft.updatedAt = new Date().toISOString();
  cms.draft = newDraft;
  cms.hasUnpublishedChanges = true;
  saveCmsStorage(cms);

  return res.json({
    success: true,
    message: 'Draft saved successfully',
    hasUnpublishedChanges: true,
  });
});

// Admin: Publish draft to live website
app.post('/api/cms/publish', authenticateToken, (_req: Request, res: Response) => {
  const cms = getCmsStorage();

  // Automatically snapshot previous published version before overwriting
  createBackupSnapshot(`Pre-Publish Snapshot (${new Date().toLocaleDateString()})`);

  cms.published = JSON.parse(JSON.stringify(cms.draft));
  cms.published.version = (cms.published.version || 1) + 1;
  cms.published.updatedAt = new Date().toISOString();
  cms.draft.version = cms.published.version;
  cms.hasUnpublishedChanges = false;
  cms.lastPublishedAt = new Date().toISOString();

  saveCmsStorage(cms);

  return res.json({
    success: true,
    message: 'Changes published successfully to the live website!',
    lastPublishedAt: cms.lastPublishedAt,
    version: cms.published.version,
  });
});

// Admin: Discard draft and revert to published
app.post('/api/cms/discard-draft', authenticateToken, (_req: Request, res: Response) => {
  const cms = getCmsStorage();
  cms.draft = JSON.parse(JSON.stringify(cms.published));
  cms.hasUnpublishedChanges = false;
  saveCmsStorage(cms);

  return res.json({
    success: true,
    message: 'Unpublished draft changes discarded. Reverted to live content.',
  });
});

/* ========================================================================== */
/* MEDIA MANAGER ENDPOINTS                                                    */
/* ========================================================================== */

app.get('/api/cms/media', authenticateToken, (_req: Request, res: Response) => {
  const cms = getCmsStorage();
  return res.json({ media: cms.draft.media || [] });
});

app.post('/api/cms/media/upload', authenticateToken, (req: Request, res: Response) => {
  const { filename, base64Data, title, alt, caption } = req.body;

  if (!base64Data) {
    return res.status(400).json({ error: 'No image data provided' });
  }

  try {
    // Strip header if present: "data:image/png;base64,..."
    const matches = base64Data.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    let buffer: Buffer;
    let ext = 'jpg';

    if (matches && matches.length === 3) {
      const mime = matches[1];
      if (mime.includes('png')) ext = 'png';
      else if (mime.includes('webp')) ext = 'webp';
      else if (mime.includes('svg')) ext = 'svg';
      else if (mime.includes('gif')) ext = 'gif';
      buffer = Buffer.from(matches[2], 'base64');
    } else {
      buffer = Buffer.from(base64Data, 'base64');
    }

    const cleanName = (filename || 'image')
      .replace(/[^a-zA-Z0-9_-]/g, '_')
      .slice(0, 40);
    const uniqueFilename = `${Date.now()}_${cleanName}.${ext}`;
    const targetPath = path.resolve(UPLOADS_DIR, uniqueFilename);

    fs.writeFileSync(targetPath, buffer);

    const mediaUrl = `/uploads/${uniqueFilename}`;
    const newMediaItem = {
      id: `m-${Date.now()}`,
      url: mediaUrl,
      filename: uniqueFilename,
      title: title || cleanName.replace(/_/g, ' '),
      alt: alt || title || cleanName.replace(/_/g, ' '),
      caption: caption || '',
      size: buffer.length,
      uploadedAt: new Date().toISOString(),
    };

    const cms = getCmsStorage();
    if (!cms.draft.media) cms.draft.media = [];
    cms.draft.media.unshift(newMediaItem);
    // Also sync to published media list so assets aren't lost
    if (!cms.published.media) cms.published.media = [];
    cms.published.media.unshift(newMediaItem);

    cms.hasUnpublishedChanges = true;
    saveCmsStorage(cms);

    return res.json({ success: true, mediaItem: newMediaItem });
  } catch (err: any) {
    console.error('Media upload error:', err);
    return res.status(500).json({ error: 'Failed to save uploaded file: ' + err.message });
  }
});

app.delete('/api/cms/media/:id', authenticateToken, (req: Request, res: Response) => {
  const { id } = req.params;
  const cms = getCmsStorage();

  const itemIndex = (cms.draft.media || []).findIndex((m: any) => m.id === id);
  if (itemIndex === -1) {
    return res.status(404).json({ error: 'Media item not found' });
  }

  const item = cms.draft.media[itemIndex];
  cms.draft.media.splice(itemIndex, 1);
  if (cms.published.media) {
    cms.published.media = cms.published.media.filter((m: any) => m.id !== id);
  }

  // Delete physical file if inside /uploads
  if (item.url && item.url.startsWith('/uploads/')) {
    const filePath = path.resolve(__dirname, 'public', item.url.replace(/^\//, ''));
    if (fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
      } catch (e) {
        console.error('Failed to unlink file:', e);
      }
    }
  }

  cms.hasUnpublishedChanges = true;
  saveCmsStorage(cms);
  return res.json({ success: true, message: 'Media item removed' });
});

/* ========================================================================== */
/* BACKUP, EXPORT & RESTORE ENDPOINTS                                         */
/* ========================================================================== */

app.get('/api/cms/backups', authenticateToken, (_req: Request, res: Response) => {
  const files = fs.readdirSync(BACKUPS_DIR).filter((f) => f.endsWith('.json'));
  const backups = files.map((f) => {
    try {
      const content = JSON.parse(fs.readFileSync(path.resolve(BACKUPS_DIR, f), 'utf-8'));
      return {
        id: content.id || f.replace('.json', ''),
        timestamp: content.timestamp || fs.statSync(path.resolve(BACKUPS_DIR, f)).mtime.toISOString(),
        label: content.label || 'Snapshot Backup',
        size: fs.statSync(path.resolve(BACKUPS_DIR, f)).size,
        version: content.data?.version || 1,
      };
    } catch {
      return {
        id: f.replace('.json', ''),
        timestamp: new Date().toISOString(),
        label: 'Backup',
        size: 0,
        version: 1,
      };
    }
  });

  backups.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  return res.json({ backups });
});

app.post('/api/cms/backups/create', authenticateToken, (req: Request, res: Response) => {
  const { label } = req.body;
  const backupId = createBackupSnapshot(label || `Manual Backup ${new Date().toLocaleString()}`);
  return res.json({ success: true, backupId, message: 'Backup created successfully' });
});

app.post('/api/cms/backups/restore/:backupId', authenticateToken, (req: Request, res: Response) => {
  const { backupId } = req.params;
  const backupFile = path.resolve(BACKUPS_DIR, `${backupId}.json`);

  if (!fs.existsSync(backupFile)) {
    return res.status(404).json({ error: 'Backup snapshot not found' });
  }

  try {
    const backupContent = JSON.parse(fs.readFileSync(backupFile, 'utf-8'));
    const restoredData = backupContent.data;

    // Create a safety snapshot before restoring
    createBackupSnapshot('Pre-Restore Safety Snapshot');

    const cms = getCmsStorage();
    cms.published = restoredData;
    cms.draft = JSON.parse(JSON.stringify(restoredData));
    cms.hasUnpublishedChanges = false;
    cms.lastPublishedAt = new Date().toISOString();

    saveCmsStorage(cms);
    return res.json({ success: true, message: 'Website content restored successfully from backup!' });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to restore backup: ' + err.message });
  }
});

// Download JSON export
app.get('/api/cms/backup/download', authenticateToken, (_req: Request, res: Response) => {
  const cms = getCmsStorage();
  const exportPayload = {
    app: 'Sai Vet Care Clinic CMS Export',
    version: cms.published.version,
    exportedAt: new Date().toISOString(),
    content: cms.published,
  };

  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', `attachment; filename="svcc-cms-backup-${Date.now()}.json"`);
  return res.send(JSON.stringify(exportPayload, null, 2));
});

// Import JSON file
app.post('/api/cms/backup/import', authenticateToken, (req: Request, res: Response) => {
  const { content } = req.body;
  if (!content || !content.settings || !content.pages) {
    return res.status(400).json({ error: 'Invalid backup format. Must contain valid CMS data structure.' });
  }

  createBackupSnapshot('Pre-Import Safety Snapshot');

  const cms = getCmsStorage();
  cms.draft = content;
  cms.published = JSON.parse(JSON.stringify(content));
  cms.hasUnpublishedChanges = false;
  cms.lastPublishedAt = new Date().toISOString();

  saveCmsStorage(cms);
  return res.json({ success: true, message: 'Backup imported and applied successfully!' });
});

/* ========================================================================== */
/* VITE DEV / PRODUCTION SERVER                                               */
/* ========================================================================== */

async function startServer() {
  if (!isProduction) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SVCC CMS] Server listening on port ${PORT} (http://0.0.0.0:${PORT})`);
    console.log(`[SVCC CMS] Admin login available at: /admin`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
